import { cert, getApps, initializeApp } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getFirestore } from "firebase-admin/firestore";
import { appRouter } from "../server/routers.ts";
import { reportIdFor } from "../server/callPrivacy.ts";

const projectId = "water-reminder-1bca2";
const apiKey = "AIzaSyDkpHFS_vL1nST9rTTVlC9L5jDZlCfDVTc";
const a = { uid: "contact-probe-a", number: "71234567" };
const b = { uid: "contact-probe-b", number: "72345678" };
const serviceAccount = process.env.FIREBASE_ADMIN_SERVICE_ACCOUNT;
if (!serviceAccount) throw new Error("FIREBASE_ADMIN_SERVICE_ACCOUNT is unavailable to this verification task.");
const app = getApps()[0] || initializeApp({ credential: cert(JSON.parse(serviceAccount)) });
const db = getFirestore(app);

async function getIdToken(uid) {
  const token = await getAuth(app).createCustomToken(uid);
  const response = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken?key=${apiKey}`, {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token, returnSecureToken: true }),
  });
  const data = await response.json();
  if (!response.ok || !data.idToken) throw new Error(`Unable to obtain Firebase test token: ${data?.error?.message || response.status}`);
  return data.idToken;
}

function callAs(token) {
  return appRouter.createCaller({ req: { header: name => name.toLowerCase() === "authorization" ? `Bearer ${token}` : undefined }, res: {} });
}

async function expectError(operation, text) {
  try { await operation(); } catch (error) {
    if (String(error?.message || error).includes(text)) return;
    throw error;
  }
  throw new Error(`Expected operation to fail with: ${text}`);
}

const reportId = reportIdFor({ reporterUid: a.uid, reportedNumber: b.number, category: "scam", description: "Test report description" });
async function cleanup() {
  await Promise.all([
    db.collection("users").doc(a.uid).delete(), db.collection("users").doc(b.uid).delete(),
    db.collection("assigned_numbers").doc(a.number).delete(), db.collection("assigned_numbers").doc(b.number).delete(),
    db.collection("pin_attempts").doc(`${b.uid}_${a.uid}`).delete(), db.collection("reports").doc(reportId).delete(),
    db.collection("call_policies").doc(a.uid).delete(), db.collection("call_policies").doc(b.uid).delete(),
  ]);
  await Promise.all([getAuth(app).deleteUser(a.uid).catch(() => undefined), getAuth(app).deleteUser(b.uid).catch(() => undefined)]);
}

try {
  await cleanup();
  const timestamp = Date.now();
  await Promise.all([
    db.collection("users").doc(a.uid).set({ uid: a.uid, displayName: "Probe A", email: "probe-a@example.invalid", isOnboarded: true, pinHash: "probe", pinVersion: 0, dndEnabled: false, blockedUsersList: [], blockedHashes: [], virtualNumbers: [{ number: a.number, type: "primary", status: "active", createdAt: timestamp }] }),
    db.collection("users").doc(b.uid).set({ uid: b.uid, displayName: "Probe B", email: "probe-b@example.invalid", isOnboarded: true, pinHash: "probe", pinVersion: 0, dndEnabled: false, blockedUsersList: [], blockedHashes: [], virtualNumbers: [{ number: b.number, type: "primary", status: "active", createdAt: timestamp }] }),
    db.collection("assigned_numbers").doc(a.number).set({ userId: a.uid, type: "permanent", assignedAt: timestamp }),
    db.collection("assigned_numbers").doc(b.number).set({ userId: b.uid, type: "permanent", assignedAt: timestamp }),
    db.collection("pin_attempts").doc(`${b.uid}_${a.uid}`).set({ authorizedUntil: timestamp + 60_000, pinVersion: 0 }),
  ]);
  const [tokenA, tokenB] = await Promise.all([getIdToken(a.uid), getIdToken(b.uid)]);
  const callerA = callAs(tokenA);
  const callerB = callAs(tokenB);

  await callerA.privacy.block({ targetNumber: b.number, label: "Probe B" });
  const blockedProfile = await db.collection("users").doc(a.uid).get();
  if (!blockedProfile.data()?.blockedUsersList?.some(entry => entry.number === b.number)) throw new Error("Block relationship was not persisted.");
  if (!(await callerA.privacy.blockStatus({ targetNumber: b.number })).blocked) throw new Error("Block status did not reflect the persisted relationship.");
  await expectError(() => callerB.calls.start({ callerNumber: b.number, receiverNumber: a.number }), "User is unavailable.");
  const callsAfterBlock = await db.collection("calls").where("receiverUid", "==", a.uid).get();
  if (!callsAfterBlock.empty) throw new Error("Blocked call attempt created a call record.");

  await callerA.privacy.unblock({ targetNumber: b.number });
  if ((await callerA.privacy.blockStatus({ targetNumber: b.number })).blocked) throw new Error("Unblock did not remove the persisted relationship.");
  await expectError(() => callerA.calls.start({ callerNumber: a.number, receiverNumber: a.number }), "You cannot call your own number.");

  const firstReport = await callerA.privacy.report({ targetNumber: b.number, category: "scam", description: "Test report description" });
  const repeatedReport = await callerA.privacy.report({ targetNumber: b.number, category: "scam", description: "Test report description" });
  const report = await db.collection("reports").doc(reportId).get();
  if (!firstReport.created || repeatedReport.created || !report.exists || report.data()?.status !== "OPEN") throw new Error("Report idempotency or admin-compatible storage failed.");
  console.log(JSON.stringify({ verified: true, persistedBlock: true, blockedCallDenied: true, unblockRestored: true, selfCallDenied: true, reportCreatedOnce: true, reportStatus: report.data()?.status }));
} finally {
  await cleanup();
}
