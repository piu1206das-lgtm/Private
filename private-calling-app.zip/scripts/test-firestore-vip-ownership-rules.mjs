import { readFileSync } from "node:fs";
import { cert } from "firebase-admin/app";

const projectId = "water-reminder-1bca2";
const source = readFileSync(new URL("../firestore.rules", import.meta.url), "utf8");
const serviceAccountJson = process.env.FIREBASE_ADMIN_SERVICE_ACCOUNT;
if (!serviceAccountJson) throw new Error("FIREBASE_ADMIN_SERVICE_ACCOUNT is unavailable to this verification task.");

const accessToken = await cert(JSON.parse(serviceAccountJson)).getAccessToken();
const response = await fetch(`https://firebaserules.googleapis.com/v1/projects/${projectId}:test`, {
  method: "POST",
  headers: { Authorization: `Bearer ${accessToken.access_token}`, "Content-Type": "application/json" },
  body: JSON.stringify({
    source: { files: [{ name: "firestore.rules", content: source }] },
    testSuite: {
      testCases: [
        {
          expectation: "DENY",
          request: {
            auth: { uid: "vip-rule-test-user" }, method: "update", path: "/databases/(default)/documents/users/vip-rule-test-user",
            resource: { data: { uid: "vip-rule-test-user", pinHash: "protected", isOnboarded: true, virtualNumbers: [{ number: "12345678", type: "primary", status: "active" }, { number: "87654321", type: "secondary", status: "active" }, { number: "00000001", type: "vip", status: "active" }] } },
          },
          resource: { data: { uid: "vip-rule-test-user", pinHash: "protected", isOnboarded: true, virtualNumbers: [{ number: "12345678", type: "primary", status: "active" }, { number: "87654321", type: "secondary", status: "active" }] } },
        },
        {
          expectation: "ALLOW",
          request: {
            auth: { uid: "vip-rule-test-user" }, method: "update", path: "/databases/(default)/documents/users/vip-rule-test-user",
            resource: { data: { uid: "vip-rule-test-user", pinHash: "protected", isOnboarded: true, displayName: "Updated name", virtualNumbers: [{ number: "12345678", type: "primary", status: "active" }, { number: "87654321", type: "secondary", status: "active" }] } },
          },
          resource: { data: { uid: "vip-rule-test-user", pinHash: "protected", isOnboarded: true, displayName: "Old name", virtualNumbers: [{ number: "12345678", type: "primary", status: "active" }, { number: "87654321", type: "secondary", status: "active" }] } },
        },
      ],
    },
  }),
});
const payload = await response.json();
if (!response.ok) throw new Error(`${response.status} ${payload?.error?.message || "Rules test API failed."}`);
if ((payload.issues || []).some(issue => issue.severity === "ERROR")) throw new Error(`Rules source errors: ${JSON.stringify(payload.issues)}`);
if (!Array.isArray(payload.testResults) || payload.testResults.some(result => result.state !== "SUCCESS")) throw new Error(`Rules semantic test failed: ${JSON.stringify(payload.testResults)}`);
console.log(JSON.stringify({ verified: true, vipClientMutation: "DENY", profileDisplayUpdate: "ALLOW", testResults: payload.testResults.map(result => result.state) }));
