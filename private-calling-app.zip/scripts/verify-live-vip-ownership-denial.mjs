import { cert, getApps, initializeApp } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getFirestore } from "firebase-admin/firestore";

const projectId = "water-reminder-1bca2";
const apiKey = "AIzaSyDkpHFS_vL1nST9rTTVlC9L5jDZlCfDVTc";
const uid = "vip-integrity-probe";
const serviceAccountJson = process.env.FIREBASE_ADMIN_SERVICE_ACCOUNT;
if (!serviceAccountJson) throw new Error("FIREBASE_ADMIN_SERVICE_ACCOUNT is unavailable to this verification task.");
const app = getApps().length ? getApps()[0] : initializeApp({ credential: cert(JSON.parse(serviceAccountJson)) });
try {
  const customToken = await getAuth(app).createCustomToken(uid);
  const identity = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken?key=${apiKey}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ token: customToken, returnSecureToken: true }),
  });
  const identityPayload = await identity.json();
  if (!identity.ok || !identityPayload.idToken) throw new Error(`Unable to mint a test Firebase client token: ${identityPayload?.error?.message || identity.status}`);

  const document = {
  fields: {
    uid: { stringValue: uid }, pinHash: { stringValue: "probe-hash" }, isOnboarded: { booleanValue: true },
    virtualNumbers: { arrayValue: { values: [
      { mapValue: { fields: { number: { stringValue: "12345678" }, type: { stringValue: "primary" }, status: { stringValue: "active" } } } },
      { mapValue: { fields: { number: { stringValue: "87654321" }, type: { stringValue: "secondary" }, status: { stringValue: "active" } } } },
      { mapValue: { fields: { number: { stringValue: "00000001" }, type: { stringValue: "vip" }, status: { stringValue: "active" } } } },
    ] } },
  },
  };
  const write = await fetch(`https://firestore.googleapis.com/v1/projects/${projectId}/databases/(default)/documents/users/${uid}?currentDocument.exists=false`, {
    method: "PATCH",
    headers: { Authorization: `Bearer ${identityPayload.idToken}`, "Content-Type": "application/json" },
    body: JSON.stringify(document),
  });
  const payload = await write.json().catch(() => ({}));
  if (write.ok) throw new Error("Security regression: a Firebase client was able to create a profile with a VIP number.");
  if (write.status !== 403) throw new Error(`Unexpected verification response ${write.status}: ${payload?.error?.message || "unknown"}`);
  console.log(JSON.stringify({ verified: true, operation: "client-create-profile-with-vip-number", result: "DENY", status: write.status }));
} finally {
  await getFirestore(app).collection("users").doc(uid).delete().catch(() => undefined);
  await getAuth(app).deleteUser(uid).catch(() => undefined);
}
