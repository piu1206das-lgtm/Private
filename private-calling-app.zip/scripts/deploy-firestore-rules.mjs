import { readFileSync } from "node:fs";
import { cert } from "firebase-admin/app";

const projectId = "water-reminder-1bca2";
const source = readFileSync(new URL("../firestore.rules", import.meta.url), "utf8");
const serviceAccountJson = process.env.FIREBASE_ADMIN_SERVICE_ACCOUNT;

if (!serviceAccountJson) throw new Error("FIREBASE_ADMIN_SERVICE_ACCOUNT is unavailable to this deployment task.");

const credential = cert(JSON.parse(serviceAccountJson));
const accessToken = await credential.getAccessToken();
const headers = { Authorization: `Bearer ${accessToken.access_token}`, "Content-Type": "application/json" };
const base = `https://firebaserules.googleapis.com/v1/projects/${projectId}`;

async function request(url, options = {}) {
  const response = await fetch(url, { ...options, headers: { ...headers, ...(options.headers || {}) } });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(`${response.status} ${body?.error?.message || "Firebase Rules API request failed."}`);
  return body;
}

const ruleset = await request(`${base}/rulesets`, {
  method: "POST",
  body: JSON.stringify({ source: { files: [{ name: "firestore.rules", content: source }] } }),
});

const releaseName = `projects/${projectId}/releases/cloud.firestore`;
let releaseExists = true;
try {
  await request(`${base}/releases/cloud.firestore`);
} catch (error) {
  if (!String(error.message).startsWith("404")) throw error;
  releaseExists = false;
}

if (releaseExists) {
  await request(`${base}/releases/cloud.firestore`, {
    method: "PATCH",
    body: JSON.stringify({ release: { name: releaseName, rulesetName: ruleset.name }, updateMask: "rulesetName" }),
  });
} else {
  await request(`${base}/releases`, {
    method: "POST",
    body: JSON.stringify({ name: releaseName, rulesetName: ruleset.name }),
  });
}

const activeRelease = await request(`${base}/releases/cloud.firestore`);
if (activeRelease.rulesetName !== ruleset.name) throw new Error("The active Firestore release did not match the newly created ruleset.");
console.log(JSON.stringify({ deployed: true, projectId, rulesetName: ruleset.name, releaseName: activeRelease.name }));
