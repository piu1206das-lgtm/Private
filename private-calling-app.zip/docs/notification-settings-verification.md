# Notification Settings Interaction Verification

The Notification Settings sheet is protected by the existing Firebase sign-in flow. The available sandbox browser session reaches the unauthenticated login screen, and no connected user browser session is available for an authenticated mobile-sheet capture.

The implementation is covered by a JSDOM component test that changes the three switches and verifies the saved settings payload, confirms the Notification sheet is marked drag-dismissible, and confirms the existing close control remains available. A focused gesture test verifies the actual dismiss policy: a long downward drag or a fast downward flick closes, while a small slow drag snaps back. TypeScript checking, full application tests, and production build are rerun before the checkpoint.

Manual authenticated verification remains appropriate after Firebase Google sign-in is available on the preview: open **Profile → Notifications**, toggle each option, drag the handle or sheet slowly (snap-back), drag it past the threshold (dismiss), and use the X control (dismiss).
