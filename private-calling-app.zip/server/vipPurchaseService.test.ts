import { describe, expect, it } from "vitest";
import { makePublicVipSearchResult } from "./vipPurchaseService";
import { analyzeVipNumber, DEFAULT_VIP_PRICING_CONFIG, isReservedVipNumber } from "./vipEngine";

describe("VIP public search and price integrity boundaries", () => {
  it("does not disclose tier, score, price, pattern, reservation, or ownership metadata when a number is unavailable", () => {
    const result = makePublicVipSearchResult(analyzeVipNumber("00000001"), false);
    expect(result).toEqual({ number: "00000001", available: false });
  });

  it("returns tier, capped score and configured backend price only for an available number", () => {
    const result = makePublicVipSearchResult(analyzeVipNumber("12345678"), true);
    expect(result).toMatchObject({ number: "12345678", available: true, tier: "Super VIP", score: 61, price: 99 });
    expect(result.patterns).toEqual([{ code: "ascending-sequence", label: "Complete ascending sequence" }]);
  });

  it("treats configured reserved numbers and prefixes as unavailable independently of a number's score", () => {
    const config = { ...DEFAULT_VIP_PRICING_CONFIG, reservedNumbers: ["12345678"], reservedPrefixes: ["0000"] };
    expect(isReservedVipNumber("12345678", config)).toBe(true);
    expect(isReservedVipNumber("00000001", config)).toBe(true);
    expect(isReservedVipNumber("45549889", config)).toBe(false);
  });
});
