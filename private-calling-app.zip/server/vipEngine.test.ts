import { describe, expect, it } from "vitest";
import { analyzeVipNumber, DEFAULT_VIP_PRICING_CONFIG, normalizeVipNumber } from "./vipEngine";

const analysis = (number: string) => analyzeVipNumber(number);
const codes = (number: string) => analysis(number).patterns.map(pattern => pattern.code);

describe("VIP number normalization", () => {
  it("removes display separators but refuses incomplete or non-numeric numbers", () => {
    expect(normalizeVipNumber("4554-9889")).toBe("45549889");
    expect(normalizeVipNumber("4554 9889")).toBe("45549889");
    expect(() => normalizeVipNumber("4554-988")).toThrow("exactly 8");
    expect(() => normalizeVipNumber("4554-A889")).toThrow("exactly 8");
  });
});

describe("VIP multi-pattern scoring", () => {
  it.each([
    ["00000000", "Ultra Rare / Collector", "all-identical"],
    ["11111111", "Ultra Rare / Collector", "all-identical"],
    ["00000001", "Ultra Rare / Collector", "seven-of-eight"],
    ["11111112", "Ultra Rare / Collector", "seven-of-eight"],
    ["12121212", "Ultra VIP", "alternating-pair"],
    ["12341234", "Super VIP", "repeated-four-block"],
    ["11223344", "Premium VIP", "double-pair-sequence"],
    ["12344321", "Ultra VIP", "full-palindrome"],
    ["87654321", "Super VIP", "descending-sequence"],
    ["12345678", "Super VIP", "ascending-sequence"],
    ["10101010", "Ultra VIP", "alternating-pair"],
    ["45549889", "Super VIP", "mirrored-four-blocks"],
    ["48277777", "Super VIP", "repeated-suffix"],
    ["48271936", "Normal", ""],
    ["99990000", "Ultra VIP", "long-identical-run"],
    ["10000001", "Ultra VIP", "full-palindrome"],
  ] as const)("classifies %s as %s", (number, tier, requiredPattern) => {
    const result = analysis(number);
    expect(result.tier).toBe(tier);
    expect(result.price).toBe(DEFAULT_VIP_PRICING_CONFIG.prices[tier]);
    if (requiredPattern) expect(codes(number)).toContain(requiredPattern);
    else expect(result.patterns).toEqual([]);
  });

  it("combines strong patterns with bounded secondary bonuses instead of choosing only one rule", () => {
    const result = analysis("12121212");
    expect(codes("12121212")).toEqual(expect.arrayContaining(["alternating-pair", "repeated-four-block"]));
    expect(result.patternScore).toBeGreaterThan(DEFAULT_VIP_PRICING_CONFIG.patternScores.repeatedPair);
    expect(result.score).toBeLessThanOrEqual(DEFAULT_VIP_PRICING_CONFIG.scoreCap);
  });

  it("keeps exceptional low-diversity patterns above a random number and honors backend configuration", () => {
    expect(analysis("00000001").score).toBeGreaterThan(analysis("48271936").score);
    const config = { ...DEFAULT_VIP_PRICING_CONFIG, prices: { ...DEFAULT_VIP_PRICING_CONFIG.prices, "Ultra Rare / Collector": 777 } };
    expect(analyzeVipNumber("11111111", config).price).toBe(777);
  });

  it("is deterministic for unchanged backend rules and applies configurable tier thresholds", () => {
    expect(analysis("45549889")).toEqual(analysis("45549889"));
    const higherPremiumThreshold = {
      ...DEFAULT_VIP_PRICING_CONFIG,
      thresholds: { ...DEFAULT_VIP_PRICING_CONFIG.thresholds, super: 90, ultra: 95, collector: 100 },
    };
    expect(analyzeVipNumber("12345678", higherPremiumThreshold).tier).toBe("Premium VIP");
  });
});
