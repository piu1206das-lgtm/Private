import { getFirebaseAdminDb } from "./firebaseAdmin";
import { DEFAULT_VIP_PRICING_CONFIG, type VipPricingConfig, type VipTier } from "./vipEngine";

function asRecord(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" && !Array.isArray(value) ? value as Record<string, unknown> : {};
}

function finiteNumber(value: unknown, fallback: number) {
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}

function stringArray(value: unknown, fallback: string[]) {
  return Array.isArray(value) && value.every(item => typeof item === "string") ? value : fallback;
}

/**
 * Backend-only configuration. A future Admin Panel can update
 * app_settings/vip_pricing without shipping a client build. Invalid values fall back safely.
 */
export async function getVipPricingConfig(): Promise<VipPricingConfig> {
  const snapshot = await getFirebaseAdminDb().collection("app_settings").doc("vip_pricing").get();
  if (!snapshot.exists) return DEFAULT_VIP_PRICING_CONFIG;
  const source = snapshot.data() || {};
  const patternScores = asRecord(source.patternScores);
  const thresholds = asRecord(source.thresholds);
  const prices = asRecord(source.prices);
  const keys = Object.keys(DEFAULT_VIP_PRICING_CONFIG.patternScores) as Array<keyof VipPricingConfig["patternScores"]>;
  const tiers = Object.keys(DEFAULT_VIP_PRICING_CONFIG.prices) as VipTier[];
  return {
    ...DEFAULT_VIP_PRICING_CONFIG,
    version: typeof source.version === "string" && source.version.trim() ? source.version : DEFAULT_VIP_PRICING_CONFIG.version,
    scoreCap: finiteNumber(source.scoreCap, DEFAULT_VIP_PRICING_CONFIG.scoreCap),
    patternScores: Object.fromEntries(keys.map(key => [key, finiteNumber(patternScores[key], DEFAULT_VIP_PRICING_CONFIG.patternScores[key])])) as VipPricingConfig["patternScores"],
    secondaryPatternFactor: finiteNumber(source.secondaryPatternFactor, DEFAULT_VIP_PRICING_CONFIG.secondaryPatternFactor),
    memorabilityCap: finiteNumber(source.memorabilityCap, DEFAULT_VIP_PRICING_CONFIG.memorabilityCap),
    rarityCap: finiteNumber(source.rarityCap, DEFAULT_VIP_PRICING_CONFIG.rarityCap),
    thresholds: {
      basic: finiteNumber(thresholds.basic, DEFAULT_VIP_PRICING_CONFIG.thresholds.basic),
      premium: finiteNumber(thresholds.premium, DEFAULT_VIP_PRICING_CONFIG.thresholds.premium),
      super: finiteNumber(thresholds.super, DEFAULT_VIP_PRICING_CONFIG.thresholds.super),
      ultra: finiteNumber(thresholds.ultra, DEFAULT_VIP_PRICING_CONFIG.thresholds.ultra),
      collector: finiteNumber(thresholds.collector, DEFAULT_VIP_PRICING_CONFIG.thresholds.collector),
    },
    prices: Object.fromEntries(tiers.map(tier => [tier, finiteNumber(prices[tier], DEFAULT_VIP_PRICING_CONFIG.prices[tier])])) as VipPricingConfig["prices"],
    reservedNumbers: stringArray(source.reservedNumbers, DEFAULT_VIP_PRICING_CONFIG.reservedNumbers),
    reservedPrefixes: stringArray(source.reservedPrefixes, DEFAULT_VIP_PRICING_CONFIG.reservedPrefixes),
    inventoryEnabled: typeof source.inventoryEnabled === "boolean" ? source.inventoryEnabled : DEFAULT_VIP_PRICING_CONFIG.inventoryEnabled,
  };
}
