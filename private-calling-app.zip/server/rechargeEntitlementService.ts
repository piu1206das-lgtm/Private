import { FieldValue, type DocumentData, type DocumentReference, type Transaction } from "firebase-admin/firestore";
import { applyVerifiedPermanentPurchase, reconcilePermanentEntitlements, type PermanentEntitlement } from "./entitlements";
import { getFirebaseAdminDb } from "./firebaseAdmin";
import { getRechargePlan, type RechargePlanRecord } from "./rechargePlans";

type StoredVirtualNumber = {
  number: string;
  type: "primary" | "secondary" | "tertiary" | "quaternary" | "quinary" | "vip";
  status: "active" | "inactive";
  createdAt: number;
};

type TemporaryEntitlementStatus = "active" | "expired" | "replaced";

type AccountProfile = {
  isOnboarded?: boolean;
  email?: string;
  virtualNumbers?: StoredVirtualNumber[];
  activeTemporaryNumber?: { number?: string } | null;
};

type TemporaryEntitlement = {
  entitlementId: string;
  purchaseId: string;
  planId: string;
  status: TemporaryEntitlementStatus;
  entitlementStart: number;
  entitlementExpiry: number;
  temporaryNumber: string;
  ownerUid: string;
  numberType: "temporary";
  createdAt: number;
  updatedAt: number;
};

export type RechargeEntitlementSummary = {
  entitlementId: string;
  purchaseIds: string[];
  planId: string;
  planName: string;
  price: number;
  validityValue: number;
  validityUnit: "hours" | "days";
  validity: string;
  benefits: readonly string[];
  status: "active" | "upcoming" | "expired";
  entitlementStart: number;
  entitlementExpiry: number;
};

export type LatestSuccessfulRecharge = {
  purchaseId: string;
  planId: string;
  planName: string;
  price: number;
  validity: string;
  fulfilledAt: number;
};

export type RechargeStatus = {
  serverTime: number;
  currentPlan: RechargeEntitlementSummary | null;
  upcomingPlans: RechargeEntitlementSummary[];
  activeTemporaryEntitlements: Array<RechargeEntitlementSummary & { temporaryNumber: string }>;
  latestSuccessfulRecharge: LatestSuccessfulRecharge | null;
};

const PERMANENT_TYPES: StoredVirtualNumber["type"][] = ["primary", "secondary", "tertiary", "quaternary", "quinary"];

type RechargePurchaseForSummary = {
  purchaseId: string;
  planId?: unknown;
  status?: unknown;
  fulfilledAt?: unknown;
};

/** Selects one server-verified purchase only; failed, pending, and duplicate records never qualify. */
export function latestSuccessfulRechargeFromPurchases(purchases: RechargePurchaseForSummary[]): LatestSuccessfulRecharge | null {
  return purchases
    .flatMap((purchase) => {
      if (purchase.status !== "fulfilled" || typeof purchase.planId !== "string" || typeof purchase.fulfilledAt !== "number") return [];
      const plan = getRechargePlan(purchase.planId);
      if (!plan) return [];
      return [{ purchaseId: purchase.purchaseId, planId: plan.planId, planName: plan.planName, price: plan.price, validity: plan.validity, fulfilledAt: purchase.fulfilledAt }];
    })
    .sort((a, b) => b.fulfilledAt - a.fulfilledAt || b.purchaseId.localeCompare(a.purchaseId))[0] || null;
}

function validPermanentEntitlement(id: string, data: DocumentData): PermanentEntitlement | null {
  if (typeof data.planId !== "string" || !getRechargePlan(data.planId)) return null;
  if (!Array.isArray(data.purchaseIds) || !data.purchaseIds.every((value: unknown) => typeof value === "string")) return null;
  if (!["active", "upcoming", "expired"].includes(data.status)) return null;
  if (![data.entitlementStart, data.entitlementExpiry, data.activatedAt, data.createdAt, data.updatedAt].every(value => typeof value === "number")) return null;
  return {
    entitlementId: id,
    purchaseIds: data.purchaseIds,
    planId: data.planId,
    status: data.status,
    entitlementStart: data.entitlementStart,
    entitlementExpiry: data.entitlementExpiry,
    activatedAt: data.activatedAt,
    createdAt: data.createdAt,
    updatedAt: data.updatedAt,
  };
}

function toSummary(record: PermanentEntitlement): RechargeEntitlementSummary {
  const plan = getRechargePlan(record.planId);
  if (!plan) throw new Error(`Recharge plan ${record.planId} is missing from the authoritative catalog.`);
  return {
    entitlementId: record.entitlementId,
    purchaseIds: record.purchaseIds,
    planId: plan.planId,
    planName: plan.planName,
    price: plan.price,
    validityValue: plan.validityValue,
    validityUnit: plan.validityUnit,
    validity: plan.validity,
    benefits: plan.benefits,
    status: record.status,
    entitlementStart: record.entitlementStart,
    entitlementExpiry: record.entitlementExpiry,
  };
}

async function reserveVirtualNumberInTransaction(
  transaction: Transaction,
  userId: string,
  type: "permanent" | "temporary",
  serverNow: number,
  validityMs?: number,
  entitlementId?: string,
) {
  const db = getFirebaseAdminDb();
  const digits = type === "permanent" ? 8 : 7;
  const lower = 10 ** (digits - 1);
  const upper = 10 ** digits;

  for (let attempt = 0; attempt < 24; attempt += 1) {
    const number = Math.floor(lower + Math.random() * (upper - lower)).toString();
    const ref = db.collection("assigned_numbers").doc(number);
    const existing = await transaction.get(ref);
    const existingData = existing.data();
    const reusableTemporary = existingData?.type === "temporary"
      && typeof existingData.expiresAt === "number"
      && existingData.expiresAt < serverNow - 7 * 24 * 60 * 60 * 1000;
    if (existing.exists && !reusableTemporary) continue;
    transaction.set(ref, {
      userId,
      ownerUid: userId,
      assignedAt: serverNow,
      activatedAt: serverNow,
      type,
      numberType: type,
      status: "active",
      ...(type === "temporary" ? { expiresAt: serverNow + (validityMs || 0), entitlementId } : {}),
    });
    return number;
  }
  throw new Error("A virtual number could not be reserved. Please retry the verified payment fulfillment.");
}

async function ensurePermanentNumberEntitlement(
  transaction: Transaction,
  profileRef: DocumentReference,
  profile: AccountProfile,
  numberEntitlement: number,
  serverNow: number,
) {
  const numbers = Array.isArray(profile.virtualNumbers) ? [...profile.virtualNumbers] : [];
  const activePermanent = numbers.filter(item => PERMANENT_TYPES.includes(item.type) && item.status === "active");
  for (let index = activePermanent.length; index < numberEntitlement; index += 1) {
    const type = PERMANENT_TYPES[index];
    if (!type) break;
    const number = await reserveVirtualNumberInTransaction(transaction, profileRef.id, "permanent", serverNow);
    numbers.push({ number, type, status: "active", createdAt: serverNow });
  }
  if (numbers.length !== (profile.virtualNumbers || []).length) {
    transaction.set(profileRef, { virtualNumbers: numbers }, { merge: true });
  }
}

async function writeReconciledPermanentState(
  transaction: Transaction,
  userId: string,
  profileRef: DocumentReference,
  profile: AccountProfile,
  records: PermanentEntitlement[],
  serverNow: number,
) {
  const db = getFirebaseAdminDb();
  const reconciliation = reconcilePermanentEntitlements(records, serverNow);
  const entitlementCollection = db.collection("users").doc(userId).collection("plan_entitlements");
  for (const record of reconciliation.records) {
    transaction.set(entitlementCollection.doc(record.entitlementId), record, { merge: true });
  }

  if (reconciliation.current) {
    const currentPlan = getRechargePlan(reconciliation.current.planId);
    if (currentPlan) {
      await ensurePermanentNumberEntitlement(transaction, profileRef, profile, currentPlan.numberEntitlement, serverNow);
      transaction.set(profileRef, {
        isVIP: FieldValue.delete(),
        activePass: {
          planId: currentPlan.planId,
          purchasedAt: reconciliation.current.activatedAt || reconciliation.current.entitlementStart,
          expiresAt: reconciliation.current.entitlementExpiry,
        },
      }, { merge: true });
    }
  } else {
    transaction.set(profileRef, { isVIP: FieldValue.delete(), activePass: FieldValue.delete() }, { merge: true });
  }
  return reconciliation;
}

function validTemporaryEntitlement(id: string, data: DocumentData, ownerUid: string): TemporaryEntitlement | null {
  if (typeof data.purchaseId !== "string" || typeof data.planId !== "string" || !getRechargePlan(data.planId)) return null;
  if (!["active", "expired", "replaced"].includes(data.status)) return null;
  if (![data.entitlementStart, data.entitlementExpiry, data.createdAt, data.updatedAt].every(value => typeof value === "number")) return null;
  if (typeof data.temporaryNumber !== "string" || !/^\d{7}$/.test(data.temporaryNumber)) return null;
  return {
    entitlementId: id,
    purchaseId: data.purchaseId,
    planId: data.planId,
    status: data.status as TemporaryEntitlementStatus,
    entitlementStart: data.entitlementStart,
    entitlementExpiry: data.entitlementExpiry,
    temporaryNumber: data.temporaryNumber,
    ownerUid: typeof data.ownerUid === "string" ? data.ownerUid : ownerUid,
    numberType: "temporary",
    createdAt: data.createdAt,
    updatedAt: data.updatedAt,
  };
}

async function reconcileInTransaction(
  transaction: Transaction,
  userId: string,
  profileRef: DocumentReference,
  profile: AccountProfile,
  serverNow: number,
) {
  const db = getFirebaseAdminDb();
  const permanentCollection = db.collection("users").doc(userId).collection("plan_entitlements");
  const temporaryCollection = db.collection("users").doc(userId).collection("temporary_entitlements");
  const [permanentSnapshot, temporarySnapshot] = await Promise.all([
    transaction.get(permanentCollection),
    transaction.get(temporaryCollection),
  ]);
  const permanentRecords = permanentSnapshot.docs
    .map(document => validPermanentEntitlement(document.id, document.data()))
    .filter((record): record is PermanentEntitlement => Boolean(record));
  const temporary = temporarySnapshot.docs
    .map(document => validTemporaryEntitlement(document.id, document.data(), userId))
    .filter((record): record is TemporaryEntitlement => Boolean(record))
    .map(record => ({ ...record, status: record.entitlementExpiry <= serverNow ? "expired" as const : record.status }));
  const activeTemporary = temporary
    .filter(record => record.status === "active")
    .sort((a, b) => b.entitlementStart - a.entitlementStart || b.createdAt - a.createdAt || b.entitlementId.localeCompare(a.entitlementId));
  const activeEntitlementId = activeTemporary[0]?.entitlementId;
  const reconciledTemporary = temporary.map(record => record.status === "active" && record.entitlementId !== activeEntitlementId
    ? { ...record, status: "replaced" as const }
    : record);
  // Firestore transactions require every read to happen before any write. Read
  // each linked assignment before reconciling permanent or temporary records.
  const assignedDocuments = await Promise.all(reconciledTemporary.map(record => transaction.get(db.collection("assigned_numbers").doc(record.temporaryNumber))));
  const permanent = await writeReconciledPermanentState(transaction, userId, profileRef, profile, permanentRecords, serverNow);
  for (let index = 0; index < reconciledTemporary.length; index += 1) {
    const record = reconciledTemporary[index]!;
    transaction.set(temporaryCollection.doc(record.entitlementId), { ...record, updatedAt: serverNow }, { merge: true });
    const assignment = assignedDocuments[index];
    if (assignment?.exists && assignment.data()?.userId === userId && assignment.data()?.type === "temporary") {
      transaction.set(assignment.ref, {
        userId,
        ownerUid: userId,
        type: "temporary",
        numberType: "temporary",
        status: record.status,
        activatedAt: record.entitlementStart,
        expiresAt: record.entitlementExpiry,
        entitlementId: record.entitlementId,
        updatedAt: serverNow,
      }, { merge: true });
    }
  }
  const currentTemporary = reconciledTemporary.find(record => record.status === "active") || null;
  transaction.set(profileRef, {
    activeTemporaryNumber: currentTemporary ? {
      number: currentTemporary.temporaryNumber,
      status: "active",
      numberType: "temporary",
      entitlementId: currentTemporary.entitlementId,
      planId: currentTemporary.planId,
      activatedAt: currentTemporary.entitlementStart,
      expiresAt: currentTemporary.entitlementExpiry,
    } : null,
  }, { merge: true });
  return { permanent, temporary: reconciledTemporary };
}

export async function getRechargeStatus(userId: string, serverNow = Date.now()): Promise<RechargeStatus> {
  const db = getFirebaseAdminDb();
  const profileRef = db.collection("users").doc(userId);
  return db.runTransaction(async transaction => {
    const [profileDocument, purchaseSnapshot] = await Promise.all([
      transaction.get(profileRef),
      transaction.get(db.collection("recharge_purchases").where("purchaserUid", "==", userId)),
    ]);
    if (!profileDocument.exists) throw new Error("Account profile not found.");
    const state = await reconcileInTransaction(transaction, userId, profileRef, profileDocument.data() as AccountProfile, serverNow);
    return {
      serverTime: serverNow,
      currentPlan: state.permanent.current ? toSummary(state.permanent.current) : null,
      upcomingPlans: state.permanent.upcoming.map(toSummary),
      activeTemporaryEntitlements: state.temporary
        .filter(record => record.status === "active")
        .sort((a, b) => a.entitlementExpiry - b.entitlementExpiry)
        .map(record => ({ ...toSummary({ ...record, purchaseIds: [record.purchaseId], activatedAt: record.entitlementStart } as PermanentEntitlement), temporaryNumber: record.temporaryNumber })),
      latestSuccessfulRecharge: latestSuccessfulRechargeFromPurchases(purchaseSnapshot.docs.map(document => ({ purchaseId: document.id, ...document.data() }))),
    };
  });
}

export async function fulfillVerifiedRechargePurchase(input: {
  purchaseId: string;
  purchaserUid: string;
  recipientUid: string;
  recipientNumber?: string;
  plan: RechargePlanRecord;
  checkoutSessionId: string;
  paymentIntentId?: string;
  verifiedAt?: number;
}) {
  const db = getFirebaseAdminDb();
  const serverNow = input.verifiedAt || Date.now();
  const purchaseRef = db.collection("recharge_purchases").doc(input.purchaseId);
  const recipientRef = db.collection("users").doc(input.recipientUid);

  return db.runTransaction(async transaction => {
    const [purchaseDocument, recipientDocument] = await Promise.all([
      transaction.get(purchaseRef),
      transaction.get(recipientRef),
    ]);
    if (!purchaseDocument.exists) throw new Error("Verified checkout is missing its server-created purchase record.");
    const purchase = purchaseDocument.data()!;
    if (purchase.status === "fulfilled") return { alreadyFulfilled: true, temporaryNumber: purchase.temporaryNumber as string | undefined };
    if (purchase.checkoutSessionId !== input.checkoutSessionId || purchase.planId !== input.plan.planId || purchase.recipientUid !== input.recipientUid) {
      throw new Error("Verified checkout does not match its server-created purchase record.");
    }
    if (!recipientDocument.exists || !recipientDocument.data()?.isOnboarded) {
      throw new Error("Recharge recipient is not eligible for fulfillment.");
    }

    const profile = recipientDocument.data() as AccountProfile;
    let temporaryNumber: string | undefined;
    let entitlementId: string;
    let status: "active" | "upcoming" = "active";

    if (input.plan.kind === "permanent") {
      const permanentCollection = recipientRef.collection("plan_entitlements");
      const snapshot = await transaction.get(permanentCollection);
      const records = snapshot.docs
        .map(document => validPermanentEntitlement(document.id, document.data()))
        .filter((record): record is PermanentEntitlement => Boolean(record));
      const applied = applyVerifiedPermanentPurchase(records, input.plan, input.purchaseId, serverNow);
      const reconciliation = await writeReconciledPermanentState(transaction, input.recipientUid, recipientRef, profile, applied.records, serverNow);
      entitlementId = applied.applied.entitlementId;
      status = reconciliation.current?.entitlementId === entitlementId ? "active" : "upcoming";
    } else {
      const temporaryCollection = recipientRef.collection("temporary_entitlements");
      const temporarySnapshot = await transaction.get(temporaryCollection);
      const existingTemporary = temporarySnapshot.docs
        .map(document => validTemporaryEntitlement(document.id, document.data(), input.recipientUid))
        .filter((record): record is TemporaryEntitlement => Boolean(record));
      temporaryNumber = await reserveVirtualNumberInTransaction(transaction, input.recipientUid, "temporary", serverNow, input.plan.validityMs, input.purchaseId);
      for (const record of existingTemporary.filter(record => record.status === "active" && record.entitlementExpiry > serverNow)) {
        transaction.set(temporaryCollection.doc(record.entitlementId), {
          status: "replaced",
          replacedAt: serverNow,
          updatedAt: serverNow,
        }, { merge: true });
        transaction.set(db.collection("assigned_numbers").doc(record.temporaryNumber), {
          status: "replaced",
          updatedAt: serverNow,
        }, { merge: true });
      }
      entitlementId = input.purchaseId;
      transaction.create(temporaryCollection.doc(entitlementId), {
        entitlementId,
        purchaseId: input.purchaseId,
        planId: input.plan.planId,
        status: "active",
        entitlementStart: serverNow,
        entitlementExpiry: serverNow + input.plan.validityMs,
        temporaryNumber,
        ownerUid: input.recipientUid,
        numberType: "temporary",
        createdAt: serverNow,
        updatedAt: serverNow,
      });
      transaction.set(recipientRef, {
        activeTemporaryNumber: {
          number: temporaryNumber,
          status: "active",
          numberType: "temporary",
          entitlementId,
          planId: input.plan.planId,
          activatedAt: serverNow,
          expiresAt: serverNow + input.plan.validityMs,
        },
      }, { merge: true });
    }

    transaction.update(purchaseRef, {
      status: "fulfilled",
      entitlementId,
      entitlementStatus: status,
      fulfilledAt: serverNow,
      ...(temporaryNumber ? { temporaryNumber } : {}),
      ...(input.paymentIntentId ? { stripePaymentIntentId: input.paymentIntentId } : {}),
    });
    return { alreadyFulfilled: false, temporaryNumber, entitlementId, status };
  });
}

/** Reconciles all accounts. Called only by the authenticated scheduled endpoint after deployment. */
export async function reconcileAllRechargeEntitlements(serverNow = Date.now()) {
  const users = await getFirebaseAdminDb().collection("users").get();
  let reconciled = 0;
  for (const user of users.docs) {
    await getRechargeStatus(user.id, serverNow);
    reconciled += 1;
  }
  return { reconciled, serverTime: serverNow };
}
