import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { getApps, cert, initializeApp } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getFirebaseAdminDb } from "./firebaseAdmin";

const apiKey = "AIzaSyDkpHFS_vL1nST9rTTVlC9L5jDZlCfDVTc";
const uid = `hello-tune-storage-${Date.now()}${Math.floor(Math.random() * 1000)}`;
const serviceAccount = process.env.FIREBASE_ADMIN_SERVICE_ACCOUNT;
if (!serviceAccount) throw new Error("FIREBASE_ADMIN_SERVICE_ACCOUNT is required for the HelloTune storage integration test.");
const app = getApps()[0] || initializeApp({ credential: cert(JSON.parse(serviceAccount)) });

beforeEach(async () => {
  await getFirebaseAdminDb().collection("users").doc(uid).set({ uid, isOnboarded: true, activeHelloTunePass: { planId: "plus", purchasedAt: Date.now(), expiresAt: Date.now() + 60_000 } });
});

afterEach(async () => {
  await getFirebaseAdminDb().collection("users").doc(uid).delete();
  await getAuth(app).deleteUser(uid).catch(() => undefined);
});

function selectedClipWav() {
  const pcmBytes = 1_600; // 0.1 seconds at 8kHz mono 16-bit PCM.
  const output = new Uint8Array(44 + pcmBytes);
  const view = new DataView(output.buffer);
  const write = (offset: number, text: string) => Array.from(text).forEach((char, index) => view.setUint8(offset + index, char.charCodeAt(0)));
  write(0, "RIFF"); view.setUint32(4, 36 + pcmBytes, true); write(8, "WAVE"); write(12, "fmt ");
  view.setUint32(16, 16, true); view.setUint16(20, 1, true); view.setUint16(22, 1, true); view.setUint32(24, 8_000, true);
  view.setUint32(28, 16_000, true); view.setUint16(32, 2, true); view.setUint16(34, 16, true); write(36, "data"); view.setUint32(40, pcmBytes, true);
  return output;
}

describe("HelloTune selected-clip storage", () => {
  it("accepts only an authenticated selected WAV clip through the managed storage endpoint", async () => {
    const customToken = await getAuth(app).createCustomToken(uid);
    const signIn = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken?key=${apiKey}`, {
      method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ token: customToken, returnSecureToken: true }),
    });
    expect(signIn.ok).toBe(true);
    const { idToken } = await signIn.json() as { idToken: string };
    const upload = await fetch("http://127.0.0.1:3000/api/hellotune/clip", {
      method: "POST", headers: { authorization: `Bearer ${idToken}`, "content-type": "audio/wav", "x-hellotune-source-name": encodeURIComponent("Original song.mp3") }, body: selectedClipWav(),
    });
    const uploadBody = await upload.text();
    if (!upload.ok) throw new Error(`Selected-clip upload rejected (${upload.status}): ${uploadBody}`);
    expect(JSON.parse(uploadBody) as { name: string; storagePath: string; url: string; clipDurationSeconds: number }).toMatchObject({ name: "Original song.mp3", storagePath: expect.stringMatching(new RegExp(`^hellotunes/${uid}/`)), url: expect.stringMatching(/^\/manus-storage\//), clipDurationSeconds: 0.1 });
  }, 30_000);
});
