import { afterEach, beforeEach, describe, expect, it } from "vitest";
import type { TrpcContext } from "./_core/context";
import { getFirebaseAdminAuth, getFirebaseAdminDb } from "./firebaseAdmin";
import { getRechargeStatus, fulfillVerifiedRechargePurchase } from "./rechargeEntitlementService";
import { getRechargePlan } from "./rechargePlans";
import { appRouter } from "./routers";

const FIREBASE_WEB_API_KEY = "AIzaSyDkpHFS_vL1nST9rTTVlC9L5jDZlCfDVTc";
const suffix = `${Date.now()}${Math.floor(Math.random() * 1000)}`.slice(-7);
const permanentCaller = { uid: `temporary-caller-${suffix}`, number: `8${suffix}` };
const permanentReceiver = { uid: `temporary-receiver-${suffix}`, number: `7${suffix}` };
const temporaryOwner = { uid: `temporary-owner-${suffix}`, number: `6${suffix}` };
const people = [permanentCaller, permanentReceiver, temporaryOwner];
let callIds: string[] = [];
let purchaseIds: string[] = [];
let temporaryNumbers: string[] = [];

async function tokenFor(uid: string) {
  const customToken = await getFirebaseAdminAuth().createCustomToken(uid);
  const response = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken?key=${FIREBASE_WEB_API_KEY}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ token: customToken, returnSecureToken: true }),
  });
  expect(response.ok).toBe(true);
  return (await response.json() as { idToken: string }).idToken;
}

function client(token: string) {
  return appRouter.createCaller({ user: null, req: { header: name => name.toLowerCase() === "authorization" ? `Bearer ${token}` : undefined }, res: {} } as TrpcContext);
}

async function fulfillTemporary(planId: "1hr-shield" | "24hr-temp" | "7d-temp", serverNow = Date.now()) {
  const plan = getRechargePlan(planId)!;
  const purchaseId = `temporary-purchase-${purchaseIds.length}-${suffix}`;
  purchaseIds.push(purchaseId);
  await getFirebaseAdminDb().collection("recharge_purchases").doc(purchaseId).set({
    purchaserUid: temporaryOwner.uid,
    recipientUid: temporaryOwner.uid,
    planId,
    checkoutSessionId: `checkout-${purchaseId}`,
    status: "pending",
    createdAt: serverNow,
  });
  const result = await fulfillVerifiedRechargePurchase({
    purchaseId,
    purchaserUid: temporaryOwner.uid,
    recipientUid: temporaryOwner.uid,
    plan,
    checkoutSessionId: `checkout-${purchaseId}`,
    verifiedAt: serverNow,
  });
  expect(result.temporaryNumber).toMatch(/^\d{7}$/);
  temporaryNumbers.push(result.temporaryNumber!);
  return { ...result, purchaseId, plan, activatedAt: serverNow, temporaryNumber: result.temporaryNumber! };
}

async function ring(from: typeof permanentCaller | typeof permanentReceiver | typeof temporaryOwner, callerNumber: string, receiverNumber: string) {
  const fromClient = client(await tokenFor(from.uid));
  const started = await fromClient.calls.start({ callerNumber, receiverNumber });
  callIds.push(started.callId);
  await fromClient.calls.submitOffer({ callId: started.callId, offer: { type: "offer", sdp: "temporary-number-integration-offer" } });
  return { callId: started.callId, fromClient };
}

async function cleanFixtures() {
  const db = getFirebaseAdminDb();
  await Promise.all(callIds.flatMap(callId => [
    db.collection("calls").doc(callId).delete(),
    ...people.map(person => db.collection("users").doc(person.uid).collection("call_history").doc(callId).delete()),
  ]));
  await Promise.all(purchaseIds.flatMap(purchaseId => [
    db.collection("recharge_purchases").doc(purchaseId).delete(),
    db.collection("users").doc(temporaryOwner.uid).collection("temporary_entitlements").doc(purchaseId).delete(),
  ]));
  await Promise.all([
    ...temporaryNumbers.map(number => db.collection("assigned_numbers").doc(number).delete()),
    ...people.flatMap(person => [
      db.collection("users").doc(person.uid).delete(),
      db.collection("assigned_numbers").doc(person.number).delete(),
      db.collection("call_policies").doc(person.uid).delete(),
      getFirebaseAdminAuth().deleteUser(person.uid).catch(() => undefined),
    ]),
    db.collection("pin_attempts").doc(`${temporaryOwner.uid}_${permanentReceiver.uid}`).delete(),
    db.collection("pin_attempts").doc(`${permanentCaller.uid}_${permanentReceiver.uid}`).delete(),
    db.collection("call_throttle").doc(`${permanentCaller.uid}_${temporaryOwner.uid}`).delete(),
    db.collection("call_throttle").doc(`${temporaryOwner.uid}_${permanentReceiver.uid}`).delete(),
    db.collection("call_throttle").doc(`${permanentCaller.uid}_${permanentReceiver.uid}`).delete(),
  ]);
  callIds = [];
  purchaseIds = [];
  temporaryNumbers = [];
}

beforeEach(async () => {
  await cleanFixtures();
  const createdAt = Date.now();
  const db = getFirebaseAdminDb();
  await Promise.all(people.flatMap(person => [
    db.collection("users").doc(person.uid).set({
      uid: person.uid,
      email: `${person.uid}@example.invalid`,
      isOnboarded: true,
      pinVersion: 0,
      dndEnabled: false,
      blockedHashes: [],
      virtualNumbers: [{ number: person.number, type: "primary", status: "active", createdAt }],
    }),
    db.collection("assigned_numbers").doc(person.number).set({ userId: person.uid, ownerUid: person.uid, type: "permanent", numberType: "permanent", status: "active", assignedAt: createdAt }),
  ]));
  await Promise.all([
    db.collection("pin_attempts").doc(`${temporaryOwner.uid}_${permanentReceiver.uid}`).set({ authorizedUntil: createdAt + 120_000, pinVersion: 0 }),
    db.collection("pin_attempts").doc(`${permanentCaller.uid}_${permanentReceiver.uid}`).set({ authorizedUntil: createdAt + 120_000, pinVersion: 0 }),
  ]);
});

afterEach(async () => { await cleanFixtures(); });

describe("real temporary versus permanent number lifecycle", () => {
  it("activates a temporary number with durable owner/type/expiry metadata, receives an incoming call, and supports a normal outgoing call", async () => {
    const temporary = await fulfillTemporary("1hr-shield");
    const [assignment, entitlement, ownerProfile] = await Promise.all([
      getFirebaseAdminDb().collection("assigned_numbers").doc(temporary.temporaryNumber).get(),
      getFirebaseAdminDb().collection("users").doc(temporaryOwner.uid).collection("temporary_entitlements").doc(temporary.purchaseId).get(),
      getFirebaseAdminDb().collection("users").doc(temporaryOwner.uid).get(),
    ]);
    expect(assignment.data()).toMatchObject({ userId: temporaryOwner.uid, ownerUid: temporaryOwner.uid, type: "temporary", numberType: "temporary", status: "active", entitlementId: temporary.purchaseId, activatedAt: temporary.activatedAt, expiresAt: temporary.activatedAt + temporary.plan.validityMs });
    expect(entitlement.data()).toMatchObject({ ownerUid: temporaryOwner.uid, numberType: "temporary", status: "active", entitlementStart: temporary.activatedAt, entitlementExpiry: temporary.activatedAt + temporary.plan.validityMs, temporaryNumber: temporary.temporaryNumber });
    expect(ownerProfile.data()?.activeTemporaryNumber).toMatchObject({ number: temporary.temporaryNumber, status: "active", numberType: "temporary", entitlementId: temporary.purchaseId });

    const incoming = await ring(permanentCaller, permanentCaller.number, temporary.temporaryNumber);
    const incomingClient = client(await tokenFor(temporaryOwner.uid));
    await incomingClient.calls.submitAnswer({ callId: incoming.callId, answer: { type: "answer", sdp: "temporary-number-integration-answer" } });
    await incoming.fromClient.calls.transition({ callId: incoming.callId, status: "connected" });
    await incoming.fromClient.calls.transition({ callId: incoming.callId, status: "ended" });
    expect((await getFirebaseAdminDb().collection("calls").doc(incoming.callId).get()).data()).toMatchObject({ receiverUid: temporaryOwner.uid, receiverNumber: temporary.temporaryNumber, status: "ended" });

    const outgoing = await ring(temporaryOwner, temporary.temporaryNumber, permanentReceiver.number);
    expect((await getFirebaseAdminDb().collection("calls").doc(outgoing.callId).get()).data()).toMatchObject({ callerUid: temporaryOwner.uid, callerNumber: temporary.temporaryNumber, receiverUid: permanentReceiver.uid, status: "ringing" });
  }, 45_000);

  it("keeps an incoming call addressed to an active temporary owner durable while no client listener is active, then accepts it after reconnection", async () => {
    const temporary = await fulfillTemporary("24hr-temp");
    const call = await ring(permanentCaller, permanentCaller.number, temporary.temporaryNumber);
    const persisted = await getFirebaseAdminDb().collection("calls").doc(call.callId).get();
    expect(persisted.data()).toMatchObject({ receiverUid: temporaryOwner.uid, receiverNumber: temporary.temporaryNumber, status: "ringing" });

    const reconnectedOwner = client(await tokenFor(temporaryOwner.uid));
    await reconnectedOwner.calls.submitAnswer({ callId: call.callId, answer: { type: "answer", sdp: "reconnected-owner-answer" } });
    await call.fromClient.calls.transition({ callId: call.callId, status: "connected" });
    expect((await getFirebaseAdminDb().collection("calls").doc(call.callId).get()).data()?.status).toBe("connected");
  }, 45_000);

  it("marks expiry in Firebase, removes it from active status, rejects routing with the exact expiry outcome, and creates no ghost call", async () => {
    const activatedAt = Date.now() - 7_200_000;
    const temporary = await fulfillTemporary("1hr-shield", activatedAt);
    const serverNow = activatedAt + temporary.plan.validityMs + 1;
    const status = await getRechargeStatus(temporaryOwner.uid, serverNow);
    expect(status.activeTemporaryEntitlements).toEqual([]);

    const beforeCalls = await getFirebaseAdminDb().collection("calls").where("receiverUid", "==", temporaryOwner.uid).get();
    const callerClient = client(await tokenFor(permanentCaller.uid));
    await expect(callerClient.calls.start({ callerNumber: permanentCaller.number, receiverNumber: temporary.temporaryNumber })).rejects.toMatchObject({ message: "This number is no longer available because its validity has expired." });
    const [assignment, entitlement, ownerProfile, afterCalls] = await Promise.all([
      getFirebaseAdminDb().collection("assigned_numbers").doc(temporary.temporaryNumber).get(),
      getFirebaseAdminDb().collection("users").doc(temporaryOwner.uid).collection("temporary_entitlements").doc(temporary.purchaseId).get(),
      getFirebaseAdminDb().collection("users").doc(temporaryOwner.uid).get(),
      getFirebaseAdminDb().collection("calls").where("receiverUid", "==", temporaryOwner.uid).get(),
    ]);
    expect(assignment.data()?.status).toBe("expired");
    expect(entitlement.data()?.status).toBe("expired");
    expect(ownerProfile.data()?.activeTemporaryNumber).toBeNull();
    expect(afterCalls.size).toBe(beforeCalls.size);
  }, 45_000);

  it("replaces a prior active temporary entitlement instead of leaving duplicate active temporary numbers and preserves permanent routing", async () => {
    const first = await fulfillTemporary("24hr-temp");
    const second = await fulfillTemporary("7d-temp", first.activatedAt + 10);
    const status = await getRechargeStatus(temporaryOwner.uid, first.activatedAt + 20);
    expect(status.activeTemporaryEntitlements).toHaveLength(1);
    expect(status.activeTemporaryEntitlements[0]?.temporaryNumber).toBe(second.temporaryNumber);
    const firstAssignment = await getFirebaseAdminDb().collection("assigned_numbers").doc(first.temporaryNumber).get();
    expect(firstAssignment.data()?.status).toBe("replaced");
    expect((await getFirebaseAdminDb().collection("users").doc(temporaryOwner.uid).get()).data()?.activeTemporaryNumber).toMatchObject({ number: second.temporaryNumber, status: "active", entitlementId: second.purchaseId });

    const permanentCall = await ring(permanentCaller, permanentCaller.number, permanentReceiver.number);
    expect((await getFirebaseAdminDb().collection("calls").doc(permanentCall.callId).get()).data()).toMatchObject({ receiverUid: permanentReceiver.uid, receiverNumber: permanentReceiver.number, status: "ringing" });
  }, 45_000);
});
