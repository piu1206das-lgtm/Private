import { afterEach, beforeEach, describe, expect, it } from "vitest";
import type { TrpcContext } from "./_core/context";
import { getFirebaseAdminAuth, getFirebaseAdminDb } from "./firebaseAdmin";
import { appRouter } from "./routers";

const FIREBASE_WEB_API_KEY = "AIzaSyDkpHFS_vL1nST9rTTVlC9L5jDZlCfDVTc";
const uid = `hello-tune-test-${Date.now()}${Math.floor(Math.random() * 1000)}`;

async function tokenFor() {
  const customToken = await getFirebaseAdminAuth().createCustomToken(uid);
  const response = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken?key=${FIREBASE_WEB_API_KEY}`, {
    method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ token: customToken, returnSecureToken: true }),
  });
  expect(response.ok).toBe(true);
  return (await response.json() as { idToken: string }).idToken;
}

async function caller() {
  const token = await tokenFor();
  return appRouter.createCaller({ user: null, req: { header: (name: string) => name.toLowerCase() === "authorization" ? `Bearer ${token}` : undefined }, res: {} } as TrpcContext);
}

beforeEach(async () => {
  await getFirebaseAdminDb().collection("users").doc(uid).delete();
  await getFirebaseAdminDb().collection("users").doc(uid).set({ uid, isOnboarded: true, activeHelloTunePass: { planId: "plus", purchasedAt: Date.now(), expiresAt: Date.now() + 60_000 } });
});

afterEach(async () => {
  await getFirebaseAdminDb().collection("users").doc(uid).delete();
  await getFirebaseAdminAuth().deleteUser(uid).catch(() => undefined);
});

describe("HelloTune selected-clip activation", () => {
  it("persists only a validated short selected clip for a user with an active pack", async () => {
    const result = await (await caller()).helloTune.activate({
      name: "My song", url: `/manus-storage/hellotunes/${uid}/selected.wav`, storagePath: `hellotunes/${uid}/selected.wav`,
      clipStartSeconds: 15, clipEndSeconds: 38.5, clipDurationSeconds: 23.5,
    });
    expect(result.success).toBe(true);
    const saved = await getFirebaseAdminDb().collection("users").doc(uid).get();
    expect(saved.data()?.helloTune).toMatchObject({ storagePath: `hellotunes/${uid}/selected.wav`, clipStartSeconds: 15, clipEndSeconds: 38.5, clipDurationSeconds: 23.5 });
  }, 30_000);

  it("rejects cross-account storage paths and selections longer than forty seconds", async () => {
    const userCaller = await caller();
    await expect(userCaller.helloTune.activate({ name: "Other", url: "https://storage.example.invalid/selected.wav", storagePath: "hellotunes/someone-else/selected.wav", clipStartSeconds: 0, clipEndSeconds: 10, clipDurationSeconds: 10 })).rejects.toMatchObject({ message: "HelloTune storage path is invalid." });
    await expect(userCaller.helloTune.activate({ name: "Long", url: "https://storage.example.invalid/selected.wav", storagePath: `hellotunes/${uid}/selected.wav`, clipStartSeconds: 0, clipEndSeconds: 40.5, clipDurationSeconds: 40.5 })).rejects.toBeDefined();
  }, 30_000);
});
