import Stripe from "stripe";

export function getStripe() {
  const secret = process.env.STRIPE_SECRET_KEY;
  if (!secret) throw new Error("Secure payment processing is not configured.");
  return new Stripe(secret);
}

export function requireSafeCheckoutOrigin(origin: string | undefined) {
  try {
    const parsed = new URL(origin || "");
    if (parsed.protocol === "http:" || parsed.protocol === "https:") return parsed.origin;
  } catch {
    // Redirect origins must be valid absolute HTTP(S) origins.
  }
  throw new Error("A valid application origin is required to start secure checkout.");
}
