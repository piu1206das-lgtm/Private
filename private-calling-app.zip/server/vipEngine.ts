export type VipTier = "Normal" | "Basic VIP" | "Premium VIP" | "Super VIP" | "Ultra VIP" | "Ultra Rare / Collector";

export type VipPattern = {
  code: string;
  label: string;
  score: number;
};

export type VipPricingConfig = {
  version: string;
  scoreCap: number;
  patternScores: {
    allIdentical: number;
    sevenOfEight: number;
    palindrome: number;
    repeatedPair: number;
    repeatedBlock: number;
    doublePairs: number;
    mirroredBlocks: number;
    ascendingSequence: number;
    descendingSequence: number;
    longRun: number;
    tripleRun: number;
    doubleRun: number;
    prefixSuffixFour: number;
    prefixSuffixThree: number;
  };
  secondaryPatternFactor: number;
  memorabilityCap: number;
  rarityCap: number;
  thresholds: {
    basic: number;
    premium: number;
    super: number;
    ultra: number;
    collector: number;
  };
  prices: Record<VipTier, number>;
  reservedNumbers: string[];
  reservedPrefixes: string[];
  inventoryEnabled: boolean;
};

export const DEFAULT_VIP_PRICING_CONFIG: VipPricingConfig = {
  version: "vip-rules-2026-08-27",
  scoreCap: 100,
  patternScores: {
    allIdentical: 100,
    sevenOfEight: 85,
    palindrome: 70,
    repeatedPair: 65,
    repeatedBlock: 65,
    doublePairs: 35,
    mirroredBlocks: 55,
    ascendingSequence: 60,
    descendingSequence: 60,
    longRun: 45,
    tripleRun: 25,
    doubleRun: 10,
    prefixSuffixFour: 45,
    prefixSuffixThree: 30,
  },
  secondaryPatternFactor: 0.25,
  memorabilityCap: 12,
  rarityCap: 8,
  thresholds: { basic: 20, premium: 40, super: 60, ultra: 80, collector: 100 },
  prices: {
    "Normal": 19,
    "Basic VIP": 19,
    "Premium VIP": 49,
    "Super VIP": 99,
    "Ultra VIP": 199,
    "Ultra Rare / Collector": 499,
  },
  reservedNumbers: [],
  reservedPrefixes: [],
  inventoryEnabled: true,
};

type PatternDetector = (digits: string, config: VipPricingConfig) => VipPattern[];

export function normalizeVipNumber(value: string) {
  const digits = value.replace(/[\s-]/g, "");
  if (!/^\d{8}$/.test(digits)) throw new Error("Enter exactly 8 numeric digits.");
  return digits;
}

function runLengths(digits: string) {
  const runs: Array<{ digit: string; length: number; start: number; end: number }> = [];
  let start = 0;
  for (let index = 1; index <= digits.length; index += 1) {
    if (index === digits.length || digits[index] !== digits[start]) {
      runs.push({ digit: digits[start], length: index - start, start, end: index - 1 });
      start = index;
    }
  }
  return runs;
}

function isAscending(digits: string) {
  return Array.from(digits).every((digit, index) => index === 0 || Number(digit) === Number(digits[index - 1]) + 1);
}

function isDescending(digits: string) {
  return Array.from(digits).every((digit, index) => index === 0 || Number(digit) === Number(digits[index - 1]) - 1);
}

const detectors: PatternDetector[] = [
  (digits, config) => /^([0-9])\1{7}$/.test(digits)
    ? [{ code: "all-identical", label: "All digits identical", score: config.patternScores.allIdentical }]
    : [],
  (digits, config) => {
    const maxCount = Math.max(...Array.from({ length: 10 }, (_, digit) => Array.from(digits).filter(value => value === String(digit)).length));
    return maxCount === 7
      ? [{ code: "seven-of-eight", label: "7 of 8 digits identical", score: config.patternScores.sevenOfEight }]
      : [];
  },
  (digits, config) => digits === Array.from(digits).reverse().join("") && !/^([0-9])\1{7}$/.test(digits)
    ? [{ code: "full-palindrome", label: "Full 8-digit palindrome", score: config.patternScores.palindrome }]
    : [],
  (digits, config) => digits.slice(0, 2).repeat(4) === digits
    ? [{ code: "alternating-pair", label: "Perfect alternating 2-digit pattern", score: config.patternScores.repeatedPair }]
    : [],
  (digits, config) => digits.slice(0, 4) === digits.slice(4)
    ? [{ code: "repeated-four-block", label: "Repeated 4-digit block", score: config.patternScores.repeatedBlock }]
    : [],
  (digits, config) => /^([0-9])\1([0-9])\2([0-9])\3([0-9])\4$/.test(digits)
    ? [{ code: "double-pair-sequence", label: "Structured double-pair sequence", score: config.patternScores.doublePairs }]
    : [],
  (digits, config) => {
    const left = digits.slice(0, 4);
    const right = digits.slice(4);
    return left === Array.from(left).reverse().join("") && right === Array.from(right).reverse().join("")
      ? [{ code: "mirrored-four-blocks", label: "Mirrored 4-digit blocks", score: config.patternScores.mirroredBlocks }]
      : [];
  },
  (digits, config) => isAscending(digits)
    ? [{ code: "ascending-sequence", label: "Complete ascending sequence", score: config.patternScores.ascendingSequence }]
    : [],
  (digits, config) => isDescending(digits)
    ? [{ code: "descending-sequence", label: "Complete descending sequence", score: config.patternScores.descendingSequence }]
    : [],
  (digits, config) => {
    const maxRun = Math.max(...runLengths(digits).map(run => run.length));
    if (maxRun >= 4) return [{ code: "long-identical-run", label: `${maxRun} consecutive identical digits`, score: config.patternScores.longRun }];
    if (maxRun === 3) return [{ code: "triple-run", label: "3 consecutive identical digits", score: config.patternScores.tripleRun }];
    if (maxRun === 2) return [{ code: "double-run", label: "2 consecutive identical digits", score: config.patternScores.doubleRun }];
    return [];
  },
  (digits, config) => {
    const runs = runLengths(digits);
    const patterns: VipPattern[] = [];
    const prefix = runs[0];
    const suffix = runs.at(-1)!;
    if (prefix.length >= 3 && prefix.length < 8) patterns.push({
      code: "repeated-prefix",
      label: `${prefix.length} repeated starting digits`,
      score: prefix.length >= 4 ? config.patternScores.prefixSuffixFour : config.patternScores.prefixSuffixThree,
    });
    if (suffix.length >= 3 && suffix.length < 8) patterns.push({
      code: "repeated-suffix",
      label: `${suffix.length} repeated ending digits`,
      score: suffix.length >= 4 ? config.patternScores.prefixSuffixFour : config.patternScores.prefixSuffixThree,
    });
    return patterns;
  },
];

function memorabilityScore(digits: string, patterns: VipPattern[], config: VipPricingConfig) {
  const uniqueDigits = new Set(digits).size;
  const diversity = Math.max(0, (8 - uniqueDigits) * 1.15);
  const mirroredPairs = [0, 1, 2, 3].filter(index => digits[index] === digits[7 - index]).length;
  const symmetry = mirroredPairs * 0.75;
  const structure = Math.min(2.5, patterns.length * 0.5);
  return Math.min(config.memorabilityCap, Math.round((diversity + symmetry + structure) * 10) / 10);
}

function structuralRarityScore(patterns: VipPattern[], config: VipPricingConfig) {
  const codes = new Set(patterns.map(pattern => pattern.code));
  if (codes.has("all-identical")) return config.rarityCap;
  if (codes.has("seven-of-eight")) return Math.min(config.rarityCap, 6);
  if (["alternating-pair", "repeated-four-block", "full-palindrome"].some(code => codes.has(code))) return Math.min(config.rarityCap, 4);
  return Math.min(config.rarityCap, Math.max(0, patterns.length - 1));
}

export function tierForVipScore(score: number, config: VipPricingConfig): VipTier {
  if (score >= config.thresholds.collector) return "Ultra Rare / Collector";
  if (score >= config.thresholds.ultra) return "Ultra VIP";
  if (score >= config.thresholds.super) return "Super VIP";
  if (score >= config.thresholds.premium) return "Premium VIP";
  if (score >= config.thresholds.basic) return "Basic VIP";
  return "Normal";
}

export type VipAnalysis = {
  number: string;
  patterns: VipPattern[];
  patternScore: number;
  memorabilityScore: number;
  rarityScore: number;
  score: number;
  tier: VipTier;
  price: number;
  configurationVersion: string;
};

export function analyzeVipNumber(value: string, config: VipPricingConfig = DEFAULT_VIP_PRICING_CONFIG): VipAnalysis {
  const number = normalizeVipNumber(value);
  const patterns = detectors
    .flatMap(detector => detector(number, config))
    .filter((pattern, index, all) => all.findIndex(other => other.code === pattern.code) === index);
  const sortedScores = patterns.map(pattern => pattern.score).sort((a, b) => b - a);
  const strongest = sortedScores[0] || 0;
  const secondary = sortedScores.slice(1, 3).reduce((total, score) => total + Math.round(score * config.secondaryPatternFactor), 0);
  const patternScore = strongest + secondary;
  const memorability = memorabilityScore(number, patterns, config);
  const rarity = structuralRarityScore(patterns, config);
  const score = Math.min(config.scoreCap, Math.round(patternScore + memorability + rarity));
  const tier = tierForVipScore(score, config);
  return {
    number,
    patterns,
    patternScore,
    memorabilityScore: memorability,
    rarityScore: rarity,
    score,
    tier,
    price: config.prices[tier],
    configurationVersion: config.version,
  };
}

export function isReservedVipNumber(number: string, config: VipPricingConfig) {
  return config.reservedNumbers.includes(number) || config.reservedPrefixes.some(prefix => number.startsWith(prefix));
}
