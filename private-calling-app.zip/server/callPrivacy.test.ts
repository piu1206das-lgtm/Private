import { describe, expect, it } from "vitest";
import { createHash } from "node:crypto";
import { isCallDeniedByBlock, reportIdFor } from "./callPrivacy";

const hash = (value: string) => createHash("sha256").update(value).digest("hex");

describe("call block enforcement", () => {
  it("denies self calls and calls blocked by either participant", () => {
    expect(isCallDeniedByBlock({ callerUid: "a", receiverUid: "a" })).toBe(true);
    expect(isCallDeniedByBlock({ callerUid: "a", receiverUid: "b", receiverBlockedUids: ["a"] })).toBe(true);
    expect(isCallDeniedByBlock({ callerUid: "a", receiverUid: "b", callerBlockedUids: ["b"] })).toBe(true);
    expect(isCallDeniedByBlock({ callerUid: "a", receiverUid: "b", receiverBlockedUids: [hash("a")] })).toBe(true);
  });

  it("allows unrelated participants when neither persisted list contains the other", () => {
    expect(isCallDeniedByBlock({ callerUid: "a", receiverUid: "b", callerBlockedUids: ["c"], receiverBlockedUids: ["d"] })).toBe(false);
  });
});

describe("report idempotency", () => {
  it("uses one stable report ID for the same reporter, number, category and normalized description", () => {
    const first = reportIdFor({ reporterUid: "user-a", reportedNumber: "12345678", category: "scam", description: "Repeated  spam" });
    const retry = reportIdFor({ reporterUid: "user-a", reportedNumber: "12345678", category: "scam", description: "repeated spam" });
    expect(first).toBe(retry);
  });

  it("keeps separate moderation signals for different category or description", () => {
    const base = reportIdFor({ reporterUid: "user-a", reportedNumber: "12345678", category: "scam", description: "Suspicious link" });
    expect(reportIdFor({ reporterUid: "user-a", reportedNumber: "12345678", category: "spam", description: "Suspicious link" })).not.toBe(base);
    expect(reportIdFor({ reporterUid: "user-a", reportedNumber: "12345678", category: "scam", description: "Different details" })).not.toBe(base);
  });
});
