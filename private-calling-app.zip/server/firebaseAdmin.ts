import { cert, getApp, getApps, initializeApp } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getFirestore } from "firebase-admin/firestore";

function readServiceAccount(): Parameters<typeof cert>[0] {
  const raw = process.env.FIREBASE_ADMIN_SERVICE_ACCOUNT;
  if (!raw) throw new Error("FIREBASE_ADMIN_SERVICE_ACCOUNT is not configured.");
  try {
    return JSON.parse(raw) as Parameters<typeof cert>[0];
  } catch {
    throw new Error("FIREBASE_ADMIN_SERVICE_ACCOUNT must contain valid JSON.");
  }
}

export function getFirebaseAdminAuth() {
  const app = getApps().length
    ? getApp()
    : initializeApp({ credential: cert(readServiceAccount()) });
  return getAuth(app);
}

export function getFirebaseAdminDb() {
  const app = getApps().length
    ? getApp()
    : initializeApp({ credential: cert(readServiceAccount()) });
  return getFirestore(app);
}
