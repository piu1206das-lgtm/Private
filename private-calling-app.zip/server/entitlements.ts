import type { RechargePlanRecord } from "./rechargePlans";

export type PermanentEntitlementStatus = "active" | "upcoming" | "expired";

export type PermanentEntitlement = {
  entitlementId: string;
  purchaseIds: string[];
  planId: string;
  status: PermanentEntitlementStatus;
  entitlementStart: number;
  entitlementExpiry: number;
  activatedAt: number;
  createdAt: number;
  updatedAt: number;
};

export type EntitlementReconciliation = {
  records: PermanentEntitlement[];
  current: PermanentEntitlement | null;
  upcoming: PermanentEntitlement[];
};

const byTimeline = (a: PermanentEntitlement, b: PermanentEntitlement) =>
  a.entitlementStart - b.entitlementStart || a.createdAt - b.createdAt || a.entitlementId.localeCompare(b.entitlementId);

/**
 * Reconciles a persisted permanent-plan timeline against a server-provided time.
 * It deliberately makes no use of client clocks and never deletes user/number data.
 */
export function reconcilePermanentEntitlements(
  source: readonly PermanentEntitlement[],
  serverNow: number,
): EntitlementReconciliation {
  const records = source.map(record => ({ ...record, purchaseIds: [...record.purchaseIds] }));
  const eligible = records
    .filter(record => record.status !== "expired")
    .sort(byTimeline);

  for (const record of eligible) {
    if (record.entitlementExpiry <= serverNow) {
      record.status = "expired";
      record.updatedAt = serverNow;
    }
  }

  const remaining = eligible.filter(record => record.status !== "expired");
  const current = remaining.find(record => record.entitlementStart <= serverNow) ?? null;

  for (const record of remaining) {
    const nextStatus = current?.entitlementId === record.entitlementId ? "active" : "upcoming";
    if (record.status !== nextStatus) record.updatedAt = serverNow;
    record.status = nextStatus;
    if (nextStatus === "active" && record.activatedAt === 0) record.activatedAt = record.entitlementStart;
  }

  return {
    records,
    current,
    upcoming: remaining.filter(record => record.status === "upcoming").sort(byTimeline),
  };
}

export type PurchaseApplication = EntitlementReconciliation & {
  applied: PermanentEntitlement;
  mode: "activated" | "stacked" | "queued" | "already-applied";
};

/**
 * Adds one verified permanent-plan purchase to a reconciled timeline. A purchase of
 * the active plan extends that entitlement; a different plan is queued. If the last
 * queued entitlement is the same plan, it is extended deterministically instead of
 * creating another conflicting future entitlement.
 */
export function applyVerifiedPermanentPurchase(
  source: readonly PermanentEntitlement[],
  plan: RechargePlanRecord,
  purchaseId: string,
  serverNow: number,
): PurchaseApplication {
  const reconciled = reconcilePermanentEntitlements(source, serverNow);
  const records = reconciled.records;
  const existingPurchase = records.find(record => record.purchaseIds.includes(purchaseId));
  if (existingPurchase) {
    return { ...reconciled, applied: existingPurchase, mode: "already-applied" };
  }
  const current = reconciled.current;
  const queueTail = reconciled.upcoming.at(-1);

  const stackTarget = current?.planId === plan.planId
    ? current
    : !current && queueTail?.planId === plan.planId
      ? queueTail
      : queueTail?.planId === plan.planId
        ? queueTail
        : null;

  if (stackTarget) {
    stackTarget.entitlementExpiry += plan.validityMs;
    stackTarget.purchaseIds = [...stackTarget.purchaseIds, purchaseId];
    stackTarget.updatedAt = serverNow;
    return {
      ...reconcilePermanentEntitlements(records, serverNow),
      applied: stackTarget,
      mode: "stacked",
    };
  }

  const start = current
    ? (queueTail?.entitlementExpiry ?? current.entitlementExpiry)
    : queueTail?.entitlementExpiry ?? serverNow;
  const mode = start <= serverNow ? "activated" : "queued";
  const applied: PermanentEntitlement = {
    entitlementId: purchaseId,
    purchaseIds: [purchaseId],
    planId: plan.planId,
    status: mode === "activated" ? "active" : "upcoming",
    entitlementStart: start,
    entitlementExpiry: start + plan.validityMs,
    activatedAt: mode === "activated" ? serverNow : 0,
    createdAt: serverNow,
    updatedAt: serverNow,
  };
  records.push(applied);
  const after = reconcilePermanentEntitlements(records, serverNow);
  const resolvedApplied = after.records.find(record => record.entitlementId === applied.entitlementId) ?? applied;
  return { ...after, applied: resolvedApplied, mode };
}
