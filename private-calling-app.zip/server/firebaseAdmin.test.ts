import { describe, expect, it } from "vitest";
import { getFirebaseAdminAuth } from "./firebaseAdmin";

describe("Firebase Admin credential", () => {
  it("authenticates against Firebase Auth with a minimal list-users request", async () => {
    expect(process.env.FIREBASE_ADMIN_SERVICE_ACCOUNT).toBeTruthy();
    const result = await getFirebaseAdminAuth().listUsers(1);
    expect(Array.isArray(result.users)).toBe(true);
  }, 20_000);
});

