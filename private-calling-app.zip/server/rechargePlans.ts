export type ValidityUnit = "hours" | "days";
export type RechargeCategory = "Recommended" | "Temporary" | "Long Validity";
export type RechargePlanKind = "permanent" | "temporary-number";

export type RechargePlanRecord = {
  planId: string;
  planName: string;
  price: number;
  validityValue: number;
  validityUnit: ValidityUnit;
  validity: string;
  validityMs: number;
  benefits: readonly string[];
  categories: readonly RechargeCategory[];
  label?: string;
  kind: RechargePlanKind;
  numberEntitlement: number;
  temporaryNumberEntitlement: number;
};

const HOUR_MS = 60 * 60 * 1000;
const DAY_MS = 24 * HOUR_MS;

function definePlan(plan: Omit<RechargePlanRecord, "validity" | "validityMs">): RechargePlanRecord {
  if (plan.categories.includes("Long Validity") && (plan.validityUnit !== "days" || plan.validityValue < 30)) {
    throw new Error("Long Validity plans must have at least 30 days of validity.");
  }
  if (plan.categories.includes("Temporary") && plan.kind !== "temporary-number") {
    throw new Error("Temporary category plans must provide a temporary number.");
  }
  const validity = `${plan.validityValue} ${plan.validityUnit === "hours"
    ? plan.validityValue === 1 ? "Hour" : "Hours"
    : plan.validityValue === 1 ? "Day" : "Days"}`;
  return { ...plan, validity, validityMs: plan.validityValue * (plan.validityUnit === "hours" ? HOUR_MS : DAY_MS) };
}

// Authoritative plan catalog. UI, Checkout and fulfillment resolve plan data only through this file.
// Values intentionally preserve the existing application’s plans, prices and stated benefits.
export const rechargePlans = [
  definePlan({
    planId: "50d-freedom", planName: "50-Day Freedom", price: 17, validityValue: 50, validityUnit: "days",
    categories: ["Recommended", "Long Validity"], label: "Best Value", kind: "permanent", numberEntitlement: 1, temporaryNumberEntitlement: 0,
    benefits: ["1 Permanent 8-Digit Virtual Number", "Unlimited app-to-app voice calling", "Permanent virtual calling identity", "PIN-protected calling"],
  }),
  definePlan({
    planId: "100d-dual", planName: "Dual-Life", price: 33, validityValue: 100, validityUnit: "days",
    categories: ["Recommended", "Long Validity"], label: "Personal + Work", kind: "permanent", numberEntitlement: 2, temporaryNumberEntitlement: 0,
    benefits: ["2 Permanent 8-Digit Virtual Numbers", "Unlimited app-to-app voice calling", "Two separate permanent calling identities", "PIN-protected calling"],
  }),
  definePlan({
    planId: "1hr-pass", planName: "1-Hour Pass", price: 1, validityValue: 1, validityUnit: "hours",
    categories: [], kind: "permanent", numberEntitlement: 0, temporaryNumberEntitlement: 0,
    benefits: ["App-to-app voice calling during the active pass", "Use your primary virtual number for outgoing calls", "PIN-protected calling according to the existing security system", "Existing permanent account remains unchanged"],
  }),
  definePlan({
    planId: "1hr-shield", planName: "1-Hour Shield", price: 1.5, validityValue: 1, validityUnit: "hours",
    categories: ["Temporary"], kind: "temporary-number", numberEntitlement: 0, temporaryNumberEntitlement: 1,
    benefits: ["1 temporary 7-digit receiving number", "Receive app-to-app voice calls", "Receive-only temporary number", "No PIN required for the temporary number", "Automatically expires after 1 hour"],
  }),
  definePlan({
    planId: "24hr-temp", planName: "24-Hour Temporary Number", price: 5, validityValue: 24, validityUnit: "hours",
    categories: ["Temporary"], label: "Popular", kind: "temporary-number", numberEntitlement: 0, temporaryNumberEntitlement: 1,
    benefits: ["1 temporary 7-digit receiving number", "Receive app-to-app voice calls", "Receive-only temporary number", "No PIN required for the temporary number", "Automatically expires after 24 hours"],
  }),
  definePlan({
    planId: "7d-temp", planName: "7-Day Temporary Number", price: 25, validityValue: 7, validityUnit: "days",
    categories: ["Temporary"], kind: "temporary-number", numberEntitlement: 0, temporaryNumberEntitlement: 1,
    benefits: ["1 temporary 7-digit receiving number", "Receive app-to-app voice calls", "Receive-only temporary number", "No PIN required for the temporary number", "Automatically expires after 7 days"],
  }),
] as const satisfies readonly RechargePlanRecord[];

export function getRechargePlan(planId: string): RechargePlanRecord | undefined {
  return rechargePlans.find(plan => plan.planId === planId);
}

export function getFriendEligibleRechargePlan(planId: string): RechargePlanRecord | undefined {
  const plan = getRechargePlan(planId);
  return plan?.kind === "permanent" ? plan : undefined;
}
