import { getFirebaseAdminDb } from "./firebaseAdmin";
import { getStripe, requireSafeCheckoutOrigin } from "./stripeClient";
import { analyzeVipNumber, isReservedVipNumber, normalizeVipNumber } from "./vipEngine";
import { getVipPricingConfig } from "./vipPricingConfig";

const RESERVATION_MS = 30 * 60 * 1000;

type VipNumberEntry = { number: string; type: "vip"; status: "active"; createdAt: number };

export function makePublicVipSearchResult(input: ReturnType<typeof analyzeVipNumber>, available: boolean) {
  return {
    number: input.number,
    available,
    ...(available ? {
      tier: input.tier,
      price: input.price,
      score: input.score,
      patterns: input.patterns.map(pattern => ({ code: pattern.code, label: pattern.label })),
      configurationVersion: input.configurationVersion,
    } : {}),
  };
}

export async function searchVipNumber(value: string) {
  const number = normalizeVipNumber(value);
  const [config, assigned] = await Promise.all([
    getVipPricingConfig(),
    getFirebaseAdminDb().collection("assigned_numbers").doc(number).get(),
  ]);
  const analysis = analyzeVipNumber(number, config);
  if (!config.inventoryEnabled || isReservedVipNumber(number, config) || assigned.exists) return makePublicVipSearchResult(analysis, false);
  const reservation = await getFirebaseAdminDb().collection("vip_reservations").doc(number).get();
  const reservedByOtherPendingCheckout = reservation.exists
    && reservation.data()?.status === "reserved"
    && Number(reservation.data()?.expiresAt || 0) > Date.now();
  return makePublicVipSearchResult(analysis, !reservedByOtherPendingCheckout);
}

export async function createVipCheckout(input: {
  purchaserUid: string;
  purchaserEmail?: string;
  number: string;
  requestId: string;
  origin?: string;
}) {
  const number = normalizeVipNumber(input.number);
  const config = await getVipPricingConfig();
  if (!config.inventoryEnabled || isReservedVipNumber(number, config)) throw new Error("This VIP number is unavailable.");
  const analysis = analyzeVipNumber(number, config);
  const db = getFirebaseAdminDb();
  const purchaseId = `${input.purchaserUid}_${input.requestId}`;
  const purchaseRef = db.collection("vip_purchases").doc(purchaseId);
  const reservationRef = db.collection("vip_reservations").doc(number);
  const serverNow = Date.now();

  const prior = await purchaseRef.get();
  if (prior.exists) {
    const data = prior.data()!;
    if (data.number !== number) throw new Error("This VIP purchase request was already used for another number.");
    if (data.status === "fulfilled") return { purchaseId, alreadyFulfilled: true, checkoutUrl: null };
    if (typeof data.checkoutSessionId === "string") {
      const session = await getStripe().checkout.sessions.retrieve(data.checkoutSessionId);
      if (session.url) return { purchaseId, alreadyFulfilled: false, checkoutUrl: session.url };
    }
    throw new Error("This VIP checkout is being prepared. Please retry shortly.");
  }

  await db.runTransaction(async transaction => {
    const [assigned, reservation, purchase] = await Promise.all([
      transaction.get(db.collection("assigned_numbers").doc(number)),
      transaction.get(reservationRef),
      transaction.get(purchaseRef),
    ]);
    if (purchase.exists) return;
    const reservationData = reservation.data();
    const currentlyReserved = reservation.exists && reservationData?.status === "reserved" && Number(reservationData.expiresAt || 0) > serverNow;
    if (assigned.exists || currentlyReserved) throw new Error("This VIP number is unavailable.");
    transaction.set(reservationRef, { purchaseId, purchaserUid: input.purchaserUid, status: "reserved", expiresAt: serverNow + RESERVATION_MS, createdAt: serverNow });
    transaction.create(purchaseRef, { purchaseId, purchaserUid: input.purchaserUid, number, requestId: input.requestId, status: "creating_checkout", createdAt: serverNow });
  });

  const baseUrl = requireSafeCheckoutOrigin(input.origin);
  const metadata = { fulfillment_kind: "vip", purchase_id: purchaseId, purchaser_uid: input.purchaserUid, vip_number: number, vip_rule_version: analysis.configurationVersion };
  const session = await getStripe().checkout.sessions.create({
    mode: "payment",
    client_reference_id: input.purchaserUid,
    ...(input.purchaserEmail ? { customer_email: input.purchaserEmail } : {}),
    allow_promotion_codes: true,
    metadata,
    payment_intent_data: { metadata },
    line_items: [{ quantity: 1, price_data: { currency: "inr", unit_amount: Math.round(analysis.price * 100), product_data: { name: `${analysis.tier} VIP Number`, description: number } } }],
    success_url: `${baseUrl}/?vip=success&session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${baseUrl}/?vip=cancelled`,
  }, { idempotencyKey: `vip-${purchaseId}` });
  if (!session.url) throw new Error("Secure VIP checkout could not be started.");

  await db.runTransaction(async transaction => {
    const [purchase, reservation] = await Promise.all([transaction.get(purchaseRef), transaction.get(reservationRef)]);
    if (!purchase.exists || reservation.data()?.purchaseId !== purchaseId) throw new Error("This VIP reservation could not be confirmed.");
    transaction.update(purchaseRef, { checkoutSessionId: session.id, status: "pending_payment", analysis: { tier: analysis.tier, score: analysis.score, price: analysis.price, configurationVersion: analysis.configurationVersion }, updatedAt: Date.now() });
  });
  return { purchaseId, alreadyFulfilled: false, checkoutUrl: session.url };
}

export async function fulfillVerifiedVipPurchase(input: { purchaseId: string; purchaserUid: string; number: string; checkoutSessionId: string; paymentIntentId?: string }) {
  const number = normalizeVipNumber(input.number);
  const db = getFirebaseAdminDb();
  const purchaseRef = db.collection("vip_purchases").doc(input.purchaseId);
  const reservationRef = db.collection("vip_reservations").doc(number);
  const assignedRef = db.collection("assigned_numbers").doc(number);
  const profileRef = db.collection("users").doc(input.purchaserUid);
  const serverNow = Date.now();
  return db.runTransaction(async transaction => {
    const [purchase, reservation, assigned, profile] = await Promise.all([transaction.get(purchaseRef), transaction.get(reservationRef), transaction.get(assignedRef), transaction.get(profileRef)]);
    if (!purchase.exists) throw new Error("Verified checkout is missing its server-created VIP purchase record.");
    const data = purchase.data()!;
    if (data.status === "fulfilled") return { alreadyFulfilled: true };
    if (data.purchaserUid !== input.purchaserUid || data.number !== number || data.checkoutSessionId !== input.checkoutSessionId) throw new Error("Verified checkout does not match its server-created VIP purchase.");
    if (!reservation.exists || reservation.data()?.purchaseId !== input.purchaseId || reservation.data()?.status !== "reserved") throw new Error("The VIP reservation is no longer valid.");
    if (assigned.exists) throw new Error("This VIP number is unavailable.");
    if (!profile.exists || !profile.data()?.isOnboarded) throw new Error("Your account is not eligible for VIP number fulfillment.");
    const virtualNumbers: VipNumberEntry[] = Array.isArray(profile.data()?.virtualNumbers) ? [...profile.data()!.virtualNumbers] : [];
    if (!virtualNumbers.some(entry => entry.number === number)) virtualNumbers.push({ number, type: "vip", status: "active", createdAt: serverNow });
    transaction.create(assignedRef, { userId: input.purchaserUid, assignedAt: serverNow, type: "vip" });
    transaction.update(profileRef, { virtualNumbers });
    transaction.update(reservationRef, { status: "fulfilled", fulfilledAt: serverNow });
    transaction.update(purchaseRef, { status: "fulfilled", fulfilledAt: serverNow, ...(input.paymentIntentId ? { stripePaymentIntentId: input.paymentIntentId } : {}) });
    return { alreadyFulfilled: false, number };
  });
}
