import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { getFirebaseAdminAuth, getFirebaseAdminDb } from "./firebaseAdmin";

const apiKey = "AIzaSyDkpHFS_vL1nST9rTTVlC9L5jDZlCfDVTc";
const projectId = "water-reminder-1bca2";
const uid = `hello-tune-rules-${Date.now()}${Math.floor(Math.random() * 1000)}`;

async function userToken() {
  const customToken = await getFirebaseAdminAuth().createCustomToken(uid);
  const response = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken?key=${apiKey}`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ token: customToken, returnSecureToken: true }) });
  expect(response.ok).toBe(true);
  return (await response.json() as { idToken: string }).idToken;
}

beforeEach(async () => {
  await getFirebaseAdminDb().collection("users").doc(uid).set({ uid, isOnboarded: true, displayName: "Rule Test", activeHelloTunePass: { planId: "plus", purchasedAt: Date.now(), expiresAt: Date.now() + 60_000 } });
});

afterEach(async () => {
  await getFirebaseAdminDb().collection("users").doc(uid).delete();
  await getFirebaseAdminAuth().deleteUser(uid).catch(() => undefined);
});

describe("HelloTune ownership rules", () => {
  it("rejects a direct client attempt to forge an active HelloTune", async () => {
    const response = await fetch(`https://firestore.googleapis.com/v1/projects/${projectId}/databases/(default)/documents/users/${uid}?currentDocument.exists=true&updateMask.fieldPaths=helloTune`, {
      method: "PATCH",
      headers: { authorization: `Bearer ${await userToken()}`, "content-type": "application/json" },
      body: JSON.stringify({ fields: { helloTune: { mapValue: { fields: { name: { stringValue: "Forged" }, storagePath: { stringValue: "hellotunes/other/forged.wav" }, url: { stringValue: "/manus-storage/forged.wav" } } } } } }),
    });
    expect(response.status).toBe(403);
  }, 30_000);
});
