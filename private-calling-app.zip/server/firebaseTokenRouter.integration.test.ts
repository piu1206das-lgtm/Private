import { describe, expect, it } from "vitest";
import type { TrpcContext } from "./_core/context";
import { getFirebaseAdminAuth } from "./firebaseAdmin";
import { appRouter } from "./routers";

const FIREBASE_WEB_API_KEY = "AIzaSyDkpHFS_vL1nST9rTTVlC9L5jDZlCfDVTc";

describe("Firebase Admin-backed tRPC authentication", () => {
  it("accepts a valid Firebase ID token for the private contacts route", async () => {
    const users = await getFirebaseAdminAuth().listUsers(100);
    const existingUser = users.users.find((user) => !user.disabled);
    expect(existingUser).toBeDefined();

    const customToken = await getFirebaseAdminAuth().createCustomToken(existingUser!.uid);
    const exchange = await fetch(
      `https://identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken?key=${FIREBASE_WEB_API_KEY}`,
      {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ token: customToken, returnSecureToken: true }),
      },
    );
    expect(exchange.ok).toBe(true);
    const body = await exchange.json() as { idToken?: string };
    expect(body.idToken).toBeTruthy();

    const caller = appRouter.createCaller({
      user: null,
      req: { header: (name: string) => name.toLowerCase() === "authorization" ? `Bearer ${body.idToken}` : undefined },
      res: {},
    } as TrpcContext);
    const contacts = await caller.contacts.list();
    expect(Array.isArray(contacts)).toBe(true);
  }, 30_000);
});
