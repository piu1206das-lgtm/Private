import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { createHash, randomInt } from "node:crypto";
import { z } from "zod";
import { getFirebaseAdminAuth, getFirebaseAdminDb } from "./firebaseAdmin";
import { rechargePlans } from "./rechargePlans";
import { getRechargeStatus } from "./rechargeEntitlementService";
import { createRechargeCheckout } from "./stripeRecharge";
import { createVipCheckout, searchVipNumber } from "./vipPurchaseService";
import { isCallDeniedByBlock, reportIdFor } from "./callPrivacy";
import { createHelloTuneCheckout, helloTunePacks } from "./helloTuneCheckout";

const PIN_LENGTH = 4;
const PIN_MAX_ATTEMPTS = 3;
const PIN_COOLDOWN_MS = 15 * 60 * 1000;
const PIN_AUTH_WINDOW_MS = 10 * 60 * 1000;
const CALL_SPAM_WINDOW_MS = 10 * 1000;

const virtualNumberInput = z.string().regex(/^\d{7,8}$/, "Enter a valid virtual number.");
const pinInput = z.string().regex(/^\d{4}$/, "PINs must contain exactly 4 digits.");
const reportCategoryInput = z.enum(["spam", "harassment", "scam", "abuse", "other"]);
const contactNameInput = z.string().trim().min(1, "Enter a contact name.").max(64, "Contact name is too long.");
const contactNumberInput = z.string().regex(/^\d{7,8}$/, "Contacts must use a 7-digit temporary or 8-digit permanent virtual number.");
const friendRechargeNumberInput = z.string().regex(/^\d{8}$/, "Enter a valid 8-digit permanent virtual number.");
const rtcDescriptionInput = z.object({ type: z.enum(["offer", "answer"]), sdp: z.string().min(1).max(250_000) });
const rtcCandidateInput = z.object({ candidate: z.string().min(1).max(8_192), sdpMid: z.string().nullable(), sdpMLineIndex: z.number().int().nullable(), usernameFragment: z.string().nullable().optional() });

const sha256 = (value: string) => createHash("sha256").update(value).digest("hex");
const now = () => Date.now();

export function resolveFourDigitPin(pinHash: string): string | null {
  for (let value = 0; value < 10 ** PIN_LENGTH; value += 1) {
    const candidate = value.toString().padStart(PIN_LENGTH, "0");
    if (sha256(candidate) === pinHash) return candidate;
  }
  return null;
}

async function requireFirebaseUser(ctx: { req: { header(name: string): string | undefined } }) {
  const authorization = ctx.req.header("authorization");
  const token = authorization?.startsWith("Bearer ") ? authorization.slice(7) : undefined;
  if (!token) {
    throw new TRPCError({ code: "UNAUTHORIZED", message: "Firebase authentication is required." });
  }
  try {
    const decoded = await getFirebaseAdminAuth().verifyIdToken(token);
    return decoded.uid;
  } catch {
    throw new TRPCError({ code: "UNAUTHORIZED", message: "Your Firebase session has expired. Please sign in again." });
  }
}

async function resolveNumber(number: string) {
  const db = getFirebaseAdminDb();
  const numberRef = db.collection("assigned_numbers").doc(number);
  const snapshot = await numberRef.get();
  if (!snapshot.exists) throw new TRPCError({ code: "NOT_FOUND", message: "This virtual number is unavailable." });
  const data = snapshot.data() as { userId?: string; type?: string; expiresAt?: number; status?: string; entitlementId?: string };
  if (!data.userId || !data.type) throw new TRPCError({ code: "NOT_FOUND", message: "This virtual number is unavailable." });
  if (data.type === "temporary") {
    if (number.length !== 7 || typeof data.expiresAt !== "number") {
      throw new TRPCError({ code: "NOT_FOUND", message: "This virtual number is unavailable." });
    }
    if (data.expiresAt <= now()) {
      await db.runTransaction(async transaction => {
        const current = await transaction.get(numberRef);
        if (current.exists && current.data()?.type === "temporary" && Number(current.data()?.expiresAt || 0) <= now()) {
          const entitlementId = current.data()?.entitlementId;
          const ownerUid = current.data()?.userId;
          const ownerRef = typeof ownerUid === "string" ? db.collection("users").doc(ownerUid) : null;
          const owner = ownerRef ? await transaction.get(ownerRef) : null;
          transaction.set(numberRef, { status: "expired", updatedAt: now() }, { merge: true });
          if (typeof entitlementId === "string" && typeof ownerUid === "string") {
            transaction.set(db.collection("users").doc(ownerUid).collection("temporary_entitlements").doc(entitlementId), { status: "expired", updatedAt: now() }, { merge: true });
          }
          if (ownerRef && owner?.data()?.activeTemporaryNumber?.number === number) {
            transaction.set(ownerRef, { activeTemporaryNumber: null }, { merge: true });
          }
        }
      });
      throw new TRPCError({ code: "NOT_FOUND", message: "This number is no longer available because its validity has expired." });
    }
    if (data.status && data.status !== "active") throw new TRPCError({ code: "NOT_FOUND", message: "This virtual number is unavailable." });
  } else if (number.length !== 8) {
    throw new TRPCError({ code: "NOT_FOUND", message: "This virtual number is unavailable." });
  }
  return { userId: data.userId, type: data.type, expiresAt: data.expiresAt };
}

async function reserveVirtualNumber(userId: string, type: "permanent" | "temporary", validityMs?: number) {
  const db = getFirebaseAdminDb();
  const digits = type === "permanent" ? 8 : 7;
  const lower = 10 ** (digits - 1);
  const upper = 10 ** digits;
  for (let attempt = 0; attempt < 15; attempt += 1) {
    const number = randomInt(lower, upper).toString();
    const numberRef = db.collection("assigned_numbers").doc(number);
    try {
      await db.runTransaction(async (transaction) => {
        const existing = await transaction.get(numberRef);
        const data = existing.exists ? existing.data() as { type?: string; expiresAt?: number } : undefined;
        const reusableTemporary = data?.type === "temporary"
          && typeof data.expiresAt === "number"
          && data.expiresAt < now() - 7 * 24 * 60 * 60 * 1000;
        if (existing.exists && !reusableTemporary) throw new Error("NUMBER_COLLISION");
        const assignedAt = now();
        transaction.set(numberRef, {
          userId,
          assignedAt,
          type,
          ...(type === "temporary" ? { expiresAt: assignedAt + (validityMs || 24 * 60 * 60 * 1000) } : {}),
        });
      });
      return number;
    } catch (error: any) {
      if (error?.message !== "NUMBER_COLLISION") throw error;
    }
  }
  throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Unable to allocate a virtual number. Please try again." });
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  pin: router({
    cooldown: publicProcedure.input(z.object({ targetNumber: virtualNumberInput })).query(async ({ ctx, input }) => {
      const callerUid = await requireFirebaseUser(ctx);
      const target = await resolveNumber(input.targetNumber);
      if (target.type === "temporary") return { lockedUntil: 0 };
      const attempt = await getFirebaseAdminDb().collection("pin_attempts").doc(`${callerUid}_${target.userId}`).get();
      const lockedUntil = attempt.exists ? Number(attempt.data()?.lockedUntil || 0) : 0;
      return { lockedUntil: lockedUntil > now() ? lockedUntil : 0 };
    }),

    verify: publicProcedure.input(z.object({ targetNumber: virtualNumberInput, pin: pinInput })).mutation(async ({ ctx, input }) => {
      const callerUid = await requireFirebaseUser(ctx);
      const target = await resolveNumber(input.targetNumber);
      if (target.type === "temporary") {
        return { success: true, targetUid: target.userId, lockedUntil: 0 };
      }
      if (target.userId === callerUid) throw new TRPCError({ code: "BAD_REQUEST", message: "You cannot call your own number." });

      const db = getFirebaseAdminDb();
      const targetProfileRef = db.collection("users").doc(target.userId);
      const attemptRef = db.collection("pin_attempts").doc(`${callerUid}_${target.userId}`);
      return db.runTransaction(async (transaction) => {
        const [targetProfile, attempt] = await Promise.all([
          transaction.get(targetProfileRef),
          transaction.get(attemptRef),
        ]);
        if (!targetProfile.exists) throw new TRPCError({ code: "NOT_FOUND", message: "This virtual number is unavailable." });
        const attemptData = attempt.exists ? attempt.data()! : { attempts: 0, lockedUntil: 0 };
        const requestTime = now();
        const lockedUntil = Number(attemptData.lockedUntil || 0);
        if (lockedUntil > requestTime) {
          return { success: false, lockedUntil, error: "PIN verification is temporarily restricted." };
        }

        const profileData = targetProfile.data() as { pinHash?: string; pinVersion?: number };
        if (profileData.pinHash === sha256(input.pin)) {
          transaction.set(attemptRef, {
            callerUid,
            targetUid: target.userId,
            attempts: 0,
            lockedUntil: 0,
            lastPinAttemptAt: requestTime,
            authorizedUntil: requestTime + PIN_AUTH_WINDOW_MS,
            pinVersion: profileData.pinVersion || 0,
          }, { merge: true });
          return { success: true, targetUid: target.userId, lockedUntil: 0 };
        }

        const attempts = Number(attemptData.attempts || 0) + 1;
        const nextLockedUntil = attempts >= PIN_MAX_ATTEMPTS ? requestTime + PIN_COOLDOWN_MS : 0;
        transaction.set(attemptRef, {
          callerUid,
          targetUid: target.userId,
          attempts: nextLockedUntil ? 0 : attempts,
          lockedUntil: nextLockedUntil,
          lastPinAttemptAt: requestTime,
          authorizedUntil: 0,
        }, { merge: true });
        return nextLockedUntil
          ? { success: false, lockedUntil: nextLockedUntil, error: "PIN verification is temporarily restricted." }
          : { success: false, lockedUntil: 0, error: `Incorrect PIN. ${PIN_MAX_ATTEMPTS - attempts} attempts remaining.` };
      });
    }),

    change: publicProcedure.input(z.object({ currentPin: pinInput, newPin: pinInput })).mutation(async ({ ctx, input }) => {
      const uid = await requireFirebaseUser(ctx);
      if (input.currentPin === input.newPin) throw new TRPCError({ code: "BAD_REQUEST", message: "Choose a different new PIN." });
      const profileRef = getFirebaseAdminDb().collection("users").doc(uid);
      await getFirebaseAdminDb().runTransaction(async (transaction) => {
        const profile = await transaction.get(profileRef);
        if (!profile.exists || profile.data()?.pinHash !== sha256(input.currentPin)) {
          throw new TRPCError({ code: "FORBIDDEN", message: "Current PIN is incorrect." });
        }
        const nextVersion = Number(profile.data()?.pinVersion || 0) + 1;
        transaction.update(profileRef, { pinHash: sha256(input.newPin), pinVersion: nextVersion, pinChangedAt: now() });
      });
      return { success: true };
    }),

    revealOwn: publicProcedure.input(z.object({})).mutation(async ({ ctx }) => {
      const uid = await requireFirebaseUser(ctx);
      const profile = await getFirebaseAdminDb().collection("users").doc(uid).get();
      const pinHash = profile.exists ? String(profile.data()?.pinHash || "") : "";
      const pin = resolveFourDigitPin(pinHash);
      if (!pin) throw new TRPCError({ code: "NOT_FOUND", message: "Your Calling PIN is unavailable. Please reset it to continue." });
      return { pin };
    }),
  }),

  privacy: router({
    setDnd: publicProcedure.input(z.object({ enabled: z.boolean() })).mutation(async ({ ctx, input }) => {
      const uid = await requireFirebaseUser(ctx);
      const db = getFirebaseAdminDb();
      await db.runTransaction(async (transaction) => {
        transaction.update(db.collection("users").doc(uid), { dndEnabled: input.enabled });
        transaction.set(db.collection("call_policies").doc(uid), { dndEnabled: input.enabled, updatedAt: now() }, { merge: true });
      });
      return { enabled: input.enabled };
    }),

    block: publicProcedure.input(z.object({ targetNumber: virtualNumberInput, label: z.string().trim().max(64).optional() })).mutation(async ({ ctx, input }) => {
      const uid = await requireFirebaseUser(ctx);
      const target = await resolveNumber(input.targetNumber);
      if (target.userId === uid) throw new TRPCError({ code: "BAD_REQUEST", message: "You cannot block your own number." });
      const db = getFirebaseAdminDb();
      const profileRef = db.collection("users").doc(uid);
      const entry = {
        uidHash: sha256(target.userId),
        deviceHash: "",
        number: input.targetNumber,
        label: input.label || "Blocked caller",
        date: now(),
      };
      await db.runTransaction(async (transaction) => {
        const profile = await transaction.get(profileRef);
        if (!profile.exists) throw new TRPCError({ code: "NOT_FOUND", message: "Account profile not found." });
        const data = profile.data() as { blockedUsersList?: typeof entry[]; blockedHashes?: string[] };
        const currentList = data.blockedUsersList || [];
        const hasEntry = currentList.some((item) => item.number === input.targetNumber);
        if (!hasEntry) {
          transaction.update(profileRef, {
            blockedUsersList: [...currentList, entry],
            blockedHashes: Array.from(new Set([...(data.blockedHashes || []), entry.uidHash])),
          });
        }
      });
      return { entry };
    }),

    unblock: publicProcedure.input(z.object({ targetNumber: virtualNumberInput })).mutation(async ({ ctx, input }) => {
      const uid = await requireFirebaseUser(ctx);
      const db = getFirebaseAdminDb();
      const profileRef = db.collection("users").doc(uid);
      await db.runTransaction(async (transaction) => {
        const profile = await transaction.get(profileRef);
        if (!profile.exists) throw new TRPCError({ code: "NOT_FOUND", message: "Account profile not found." });
        const data = profile.data() as { blockedUsersList?: { number: string; uidHash: string; deviceHash: string }[]; blockedHashes?: string[] };
        const removed = (data.blockedUsersList || []).filter((entry) => entry.number === input.targetNumber);
        transaction.update(profileRef, {
          blockedUsersList: (data.blockedUsersList || []).filter((entry) => entry.number !== input.targetNumber),
          blockedHashes: (data.blockedHashes || []).filter((hash) => !removed.some((entry) => hash === entry.uidHash || hash === entry.deviceHash)),
        });
      });
      return { success: true };
    }),

    blockStatus: publicProcedure.input(z.object({ targetNumber: virtualNumberInput })).query(async ({ ctx, input }) => {
      const uid = await requireFirebaseUser(ctx);
      const profile = await getFirebaseAdminDb().collection("users").doc(uid).get();
      if (!profile.exists) throw new TRPCError({ code: "NOT_FOUND", message: "Account profile not found." });
      const entries = Array.isArray(profile.data()?.blockedUsersList) ? profile.data()!.blockedUsersList : [];
      return { blocked: entries.some((entry: { number?: string }) => entry.number === input.targetNumber) };
    }),

    report: publicProcedure.input(z.object({ targetNumber: virtualNumberInput, category: reportCategoryInput, description: z.string().trim().max(1000).optional(), callReferenceId: z.string().trim().max(128).optional() })).mutation(async ({ ctx, input }) => {
      const uid = await requireFirebaseUser(ctx);
      const db = getFirebaseAdminDb();
      const reportId = reportIdFor({ reporterUid: uid, reportedNumber: input.targetNumber, category: input.category, description: input.description });
      const reportRef = db.collection("reports").doc(reportId);
      const created = await db.runTransaction(async (transaction) => {
        const existing = await transaction.get(reportRef);
        if (existing.exists) return false;
        transaction.create(reportRef, {
          reportId,
          reporterUid: uid,
          reportedNumber: input.targetNumber,
          category: input.category,
          description: input.description || "",
          ...(input.callReferenceId ? { callReferenceId: input.callReferenceId } : {}),
          status: "OPEN",
          createdAt: now(),
          updatedAt: now(),
        });
        return true;
      });
      return { success: true, reportId, created };
    }),
  }),

  helloTune: router({
    packs: publicProcedure.query(async ({ ctx }) => {
      await requireFirebaseUser(ctx);
      return helloTunePacks;
    }),
    createCheckout: publicProcedure.input(z.object({
      packId: z.string().min(1),
      requestId: z.string().uuid(),
      clip: z.object({
        name: z.string().trim().min(1).max(160), url: z.string().min(1).max(4_000), storagePath: z.string().trim().min(1).max(1_000),
        clipStartSeconds: z.number().min(0).max(86_400), clipEndSeconds: z.number().min(0.1).max(86_400), clipDurationSeconds: z.number().min(0.1).max(40),
      }).refine((clip) => clip.clipEndSeconds > clip.clipStartSeconds && Math.abs((clip.clipEndSeconds - clip.clipStartSeconds) - clip.clipDurationSeconds) < 0.1, "The selected clip boundaries are invalid."),
    })).mutation(async ({ ctx, input }) => {
      const purchaserUid = await requireFirebaseUser(ctx);
      const profile = await getFirebaseAdminDb().collection("users").doc(purchaserUid).get();
      return createHelloTuneCheckout({ purchaserUid, purchaserEmail: profile.data()?.email, packId: input.packId, requestId: input.requestId, clip: input.clip, origin: ctx.req.header("origin") || undefined });
    }),
    activate: publicProcedure.input(z.object({
      name: z.string().trim().min(1).max(160),
      url: z.string().min(1).max(4_000).refine((url) => url.startsWith("/manus-storage/") || /^https:\/\//.test(url), "HelloTune URL is invalid."),
      storagePath: z.string().trim().min(1).max(1_000),
      clipStartSeconds: z.number().min(0).max(86_400),
      clipEndSeconds: z.number().min(0.1).max(86_400),
      clipDurationSeconds: z.number().min(0.1).max(40),
    }).refine((input) => input.clipEndSeconds > input.clipStartSeconds && Math.abs((input.clipEndSeconds - input.clipStartSeconds) - input.clipDurationSeconds) < 0.1, "The selected clip boundaries are invalid.")).mutation(async ({ ctx, input }) => {
      const uid = await requireFirebaseUser(ctx);
      if (!input.storagePath.startsWith(`hellotunes/${uid}/`)) throw new TRPCError({ code: "FORBIDDEN", message: "HelloTune storage path is invalid." });
      const profileRef = getFirebaseAdminDb().collection("users").doc(uid);
      await getFirebaseAdminDb().runTransaction(async (transaction) => {
        const profile = await transaction.get(profileRef);
        if (!profile.exists) throw new TRPCError({ code: "NOT_FOUND", message: "Account profile not found." });
        const activePass = profile.data()?.activeHelloTunePass as { expiresAt?: number } | undefined;
        if (!activePass || Number(activePass.expiresAt || 0) <= now()) throw new TRPCError({ code: "FORBIDDEN", message: "An active HelloTune pack is required." });
        transaction.update(profileRef, { helloTune: { ...input, activatedAt: now() } });
      });
      return { success: true };
    }),
    remove: publicProcedure.mutation(async ({ ctx }) => {
      const uid = await requireFirebaseUser(ctx);
      await getFirebaseAdminDb().collection("users").doc(uid).update({ helloTune: null });
      return { success: true };
    }),
  }),

  numbers: router({
    assignPermanent: publicProcedure.mutation(async ({ ctx }) => {
      const uid = await requireFirebaseUser(ctx);
      return { number: await reserveVirtualNumber(uid, "permanent") };
    }),
  }),

  recharge: router({
    catalog: publicProcedure.query(async ({ ctx }) => {
      await requireFirebaseUser(ctx);
      return rechargePlans;
    }),

    status: publicProcedure.query(async ({ ctx }) => {
      const uid = await requireFirebaseUser(ctx);
      try {
        return await getRechargeStatus(uid);
      } catch (error) {
        throw new TRPCError({ code: "NOT_FOUND", message: error instanceof Error ? error.message : "Recharge status is unavailable." });
      }
    }),

    purchaseHistory: publicProcedure.query(async ({ ctx }) => {
      const uid = await requireFirebaseUser(ctx);
      const db = getFirebaseAdminDb();
      const [rechargeSnapshot, helloTuneSnapshot] = await Promise.all([
        db.collection("recharge_purchases").where("purchaserUid", "==", uid).limit(50).get(),
        db.collection("hellotune_purchases").where("purchaserUid", "==", uid).limit(50).get(),
      ]);
      const recharge = rechargeSnapshot.docs.map(document => {
        const data = document.data();
        const plan = rechargePlans.find(item => item.planId === data.planId);
        return {
          purchaseId: document.id,
          type: "recharge" as const,
          planName: plan?.planName || "Recharge plan",
          price: plan?.price ?? null,
          validity: plan?.validity || null,
          status: typeof data.status === "string" ? data.status : "pending_payment",
          createdAt: typeof data.createdAt === "number" ? data.createdAt : 0,
          fulfilledAt: typeof data.fulfilledAt === "number" ? data.fulfilledAt : null,
        };
      });
      const helloTune = helloTuneSnapshot.docs.map(document => {
        const data = document.data();
        const pack = helloTunePacks.find(item => item.id === data.packId);
        return {
          purchaseId: document.id,
          type: "hellotune" as const,
          planName: pack ? `HelloTune ${pack.name}` : "HelloTune pack",
          price: pack?.price ?? null,
          validity: pack?.validity || null,
          status: typeof data.status === "string" ? data.status : "pending_payment",
          createdAt: typeof data.createdAt === "number" ? data.createdAt : 0,
          fulfilledAt: typeof data.fulfilledAt === "number" ? data.fulfilledAt : null,
        };
      });
      return [...recharge, ...helloTune].sort((a, b) => b.createdAt - a.createdAt);
    }),

    validateFriendTarget: publicProcedure.input(z.object({ targetNumber: friendRechargeNumberInput })).query(async ({ ctx, input }) => {
      await requireFirebaseUser(ctx);
      const target = await resolveNumber(input.targetNumber);
      if (target.type === "temporary") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Temporary numbers cannot receive a friend recharge." });
      }
      const profile = await getFirebaseAdminDb().collection("users").doc(target.userId).get();
      if (!profile.exists || !profile.data()?.isOnboarded) {
        throw new TRPCError({ code: "NOT_FOUND", message: "This virtual number is not eligible for recharge." });
      }
      return { targetNumber: input.targetNumber, eligible: true };
    }),

    createCheckout: publicProcedure.input(z.object({ planId: z.string().min(1), requestId: z.string().uuid() })).mutation(async ({ ctx, input }) => {
      const purchaserUid = await requireFirebaseUser(ctx);
      const purchaser = await getFirebaseAdminDb().collection("users").doc(purchaserUid).get();
      if (!purchaser.exists || !purchaser.data()?.isOnboarded) throw new TRPCError({ code: "FORBIDDEN", message: "Your account is not eligible to purchase a recharge." });
      try {
        return await createRechargeCheckout({
          purchaserUid,
          purchaserEmail: typeof purchaser.data()?.email === "string" ? purchaser.data()!.email : undefined,
          recipientUid: purchaserUid,
          planId: input.planId,
          requestId: input.requestId,
          origin: ctx.req.header("origin"),
        });
      } catch (error) {
        throw new TRPCError({ code: "BAD_REQUEST", message: error instanceof Error ? error.message : "Secure checkout could not be started." });
      }
    }),

    createFriendCheckout: publicProcedure.input(z.object({
      targetNumber: friendRechargeNumberInput,
      planId: z.string().min(1),
      requestId: z.string().uuid(),
    })).mutation(async ({ ctx, input }) => {
      const purchaserUid = await requireFirebaseUser(ctx);
      const db = getFirebaseAdminDb();
      const [purchaser, target] = await Promise.all([
        db.collection("users").doc(purchaserUid).get(),
        resolveNumber(input.targetNumber),
      ]);
      if (!purchaser.exists || !purchaser.data()?.isOnboarded) throw new TRPCError({ code: "FORBIDDEN", message: "Your account is not eligible to purchase a recharge." });
      if (target.type === "temporary" || target.userId === purchaserUid) throw new TRPCError({ code: "BAD_REQUEST", message: "Enter another eligible permanent virtual number." });
      const targetProfile = await db.collection("users").doc(target.userId).get();
      if (!targetProfile.exists || !targetProfile.data()?.isOnboarded) throw new TRPCError({ code: "NOT_FOUND", message: "This virtual number is not eligible for recharge." });
      try {
        return await createRechargeCheckout({
          purchaserUid,
          purchaserEmail: typeof purchaser.data()?.email === "string" ? purchaser.data()!.email : undefined,
          recipientUid: target.userId,
          recipientNumber: input.targetNumber,
          planId: input.planId,
          requestId: input.requestId,
          origin: ctx.req.header("origin"),
        });
      } catch (error) {
        throw new TRPCError({ code: "BAD_REQUEST", message: error instanceof Error ? error.message : "Secure checkout could not be started." });
      }
    }),
  }),

  vip: router({
    search: publicProcedure.input(z.object({ number: z.string().trim().min(1).max(16) })).query(async ({ ctx, input }) => {
      await requireFirebaseUser(ctx);
      try {
        return await searchVipNumber(input.number);
      } catch (error) {
        throw new TRPCError({ code: "BAD_REQUEST", message: error instanceof Error ? error.message : "VIP number analysis is unavailable." });
      }
    }),

    createCheckout: publicProcedure.input(z.object({ number: z.string().trim().min(1).max(16), requestId: z.string().uuid() })).mutation(async ({ ctx, input }) => {
      const purchaserUid = await requireFirebaseUser(ctx);
      const profile = await getFirebaseAdminDb().collection("users").doc(purchaserUid).get();
      if (!profile.exists || !profile.data()?.isOnboarded) throw new TRPCError({ code: "FORBIDDEN", message: "Your account is not eligible to claim a VIP number." });
      try {
        return await createVipCheckout({
          purchaserUid,
          purchaserEmail: typeof profile.data()?.email === "string" ? profile.data()!.email : undefined,
          number: input.number,
          requestId: input.requestId,
          origin: ctx.req.header("origin"),
        });
      } catch (error) {
        throw new TRPCError({ code: "BAD_REQUEST", message: error instanceof Error ? error.message : "Secure VIP checkout could not be started." });
      }
    }),
  }),

  contacts: router({
    list: publicProcedure.query(async ({ ctx }) => {
      const uid = await requireFirebaseUser(ctx);
      const snapshot = await getFirebaseAdminDb().collection("users").doc(uid).collection("contacts").orderBy("name").get();
      return snapshot.docs.map((contact) => ({
        id: contact.id,
        name: String(contact.data().name || ""),
        number: String(contact.data().number || ""),
        hasCallingPin: String(contact.data().number || "").length === 8 && typeof contact.data().callingPinHash === "string" && contact.data().callingPinHash.length > 0,
        createdAt: Number(contact.data().createdAt || 0),
        updatedAt: Number(contact.data().updatedAt || 0),
      }));
    }),

    add: publicProcedure.input(z.object({ name: contactNameInput, number: contactNumberInput, callingPin: pinInput.optional() })).mutation(async ({ ctx, input }) => {
      const uid = await requireFirebaseUser(ctx);
      const contacts = getFirebaseAdminDb().collection("users").doc(uid).collection("contacts");
      const duplicate = await contacts.where("number", "==", input.number).limit(1).get();
      if (!duplicate.empty) {
        throw new TRPCError({ code: "CONFLICT", message: "Contact already exists. Edit Contact instead." });
      }
      const contactRef = contacts.doc();
      const timestamp = now();
      await contactRef.create({ name: input.name, number: input.number, callingPinHash: input.number.length === 8 && input.callingPin ? sha256(input.callingPin) : "", createdAt: timestamp, updatedAt: timestamp });
      return { id: contactRef.id };
    }),

    update: publicProcedure.input(z.object({ id: z.string().min(1), name: contactNameInput, number: contactNumberInput, callingPin: pinInput.optional() })).mutation(async ({ ctx, input }) => {
      const uid = await requireFirebaseUser(ctx);
      const contacts = getFirebaseAdminDb().collection("users").doc(uid).collection("contacts");
      const contactRef = contacts.doc(input.id);
      await getFirebaseAdminDb().runTransaction(async (transaction) => {
        const [contact, duplicate] = await Promise.all([
          transaction.get(contactRef),
          transaction.get(contacts.where("number", "==", input.number)),
        ]);
        if (!contact.exists) throw new TRPCError({ code: "NOT_FOUND", message: "Contact not found." });
        if (duplicate.docs.some((item) => item.id !== input.id)) {
          throw new TRPCError({ code: "CONFLICT", message: "Contact already exists. Edit Contact instead." });
        }
        const existingPinHash = typeof contact.data()?.callingPinHash === "string" ? contact.data()!.callingPinHash : "";
        const callingPinHash = input.number.length === 7 ? "" : input.callingPin ? sha256(input.callingPin) : existingPinHash;
        transaction.update(contactRef, { name: input.name, number: input.number, callingPinHash, updatedAt: now() });
      });
      return { success: true };
    }),

    authorizeSavedPin: publicProcedure.input(z.object({ id: z.string().min(1) })).mutation(async ({ ctx, input }) => {
      const callerUid = await requireFirebaseUser(ctx);
      const contact = await getFirebaseAdminDb().collection("users").doc(callerUid).collection("contacts").doc(input.id).get();
      if (!contact.exists) throw new TRPCError({ code: "NOT_FOUND", message: "Contact not found." });
      const data = contact.data() as { number?: string; callingPinHash?: string };
      const number = String(data.number || "");
      if (number.length === 7) return { number, pinRequired: false, authorized: true };
      if (number.length !== 8) throw new TRPCError({ code: "BAD_REQUEST", message: "Contact number is invalid." });
      const savedPin = typeof data.callingPinHash === "string" ? resolveFourDigitPin(data.callingPinHash) : null;
      if (!savedPin) return { number, pinRequired: true, authorized: false };

      const target = await resolveNumber(number);
      const db = getFirebaseAdminDb();
      const targetProfileRef = db.collection("users").doc(target.userId);
      const attemptRef = db.collection("pin_attempts").doc(`${callerUid}_${target.userId}`);
      const result = await db.runTransaction(async (transaction) => {
        const [targetProfile, attempt] = await Promise.all([transaction.get(targetProfileRef), transaction.get(attemptRef)]);
        if (!targetProfile.exists) throw new TRPCError({ code: "NOT_FOUND", message: "This virtual number is unavailable." });
        const requestTime = now();
        const attemptData = attempt.exists ? attempt.data()! : { attempts: 0, lockedUntil: 0 };
        const lockedUntil = Number(attemptData.lockedUntil || 0);
        if (lockedUntil > requestTime) return { success: false, lockedUntil };
        if (targetProfile.data()?.pinHash === sha256(savedPin)) {
          transaction.set(attemptRef, { callerUid, targetUid: target.userId, attempts: 0, lockedUntil: 0, lastPinAttemptAt: requestTime, authorizedUntil: requestTime + PIN_AUTH_WINDOW_MS, pinVersion: targetProfile.data()?.pinVersion || 0 }, { merge: true });
          return { success: true, lockedUntil: 0 };
        }
        const attempts = Number(attemptData.attempts || 0) + 1;
        const nextLockedUntil = attempts >= PIN_MAX_ATTEMPTS ? requestTime + PIN_COOLDOWN_MS : 0;
        transaction.set(attemptRef, { callerUid, targetUid: target.userId, attempts: nextLockedUntil ? 0 : attempts, lockedUntil: nextLockedUntil, lastPinAttemptAt: requestTime, authorizedUntil: 0 }, { merge: true });
        return { success: false, lockedUntil: nextLockedUntil };
      });
      return { number, pinRequired: true, authorized: result.success, lockedUntil: result.lockedUntil };
    }),

    remove: publicProcedure.input(z.object({ id: z.string().min(1) })).mutation(async ({ ctx, input }) => {
      const uid = await requireFirebaseUser(ctx);
      const contactRef = getFirebaseAdminDb().collection("users").doc(uid).collection("contacts").doc(input.id);
      const contact = await contactRef.get();
      if (!contact.exists) throw new TRPCError({ code: "NOT_FOUND", message: "Contact not found." });
      await contactRef.delete();
      return { success: true };
    }),
  }),

  calls: router({
    start: publicProcedure.input(z.object({ callerNumber: virtualNumberInput, receiverNumber: virtualNumberInput })).mutation(async ({ ctx, input }) => {
      const callerUid = await requireFirebaseUser(ctx);
      const caller = await resolveNumber(input.callerNumber);
      if (caller.userId !== callerUid) throw new TRPCError({ code: "FORBIDDEN", message: "Use a number assigned to your account." });
      const receiver = await resolveNumber(input.receiverNumber);
      if (receiver.userId === callerUid) throw new TRPCError({ code: "BAD_REQUEST", message: "You cannot call your own number." });

      const db = getFirebaseAdminDb();
      const [receiverProfile, receiverPolicy, callerProfile] = await Promise.all([
        db.collection("users").doc(receiver.userId).get(),
        db.collection("call_policies").doc(receiver.userId).get(),
        db.collection("users").doc(callerUid).get(),
      ]);
      if (!receiverProfile.exists || !callerProfile.exists || receiverProfile.data()?.dndEnabled || receiverPolicy.data()?.dndEnabled || isCallDeniedByBlock({ callerUid, receiverUid: receiver.userId, callerBlockedUids: callerProfile.data()?.blockedHashes, receiverBlockedUids: receiverProfile.data()?.blockedHashes })) {
        throw new TRPCError({ code: "FORBIDDEN", message: "User is unavailable." });
      }

      if (receiver.type !== "temporary") {
        const authorization = await db.collection("pin_attempts").doc(`${callerUid}_${receiver.userId}`).get();
        const attempt = authorization.data();
        const correctVersion = Number(attempt?.pinVersion ?? -1) === Number(receiverProfile.data()?.pinVersion ?? 0);
        if (!authorization.exists || Number(attempt?.authorizedUntil || 0) <= now() || !correctVersion) {
          throw new TRPCError({ code: "FORBIDDEN", message: "PIN authorization is required before calling this number." });
        }
      }

      const throttleRef = db.collection("call_throttle").doc(`${callerUid}_${receiver.userId}`);
      const callRef = db.collection("calls").doc();
      const activeCallQuery = db.collection("calls").where("receiverUid", "==", receiver.userId).where("status", "in", ["calling", "ringing", "connecting", "connected", "reconnecting"]).limit(1);
      await db.runTransaction(async (transaction) => {
        const [throttle, active] = await Promise.all([transaction.get(throttleRef), transaction.get(activeCallQuery)]);
        const lastCreatedAt = Number(throttle.data()?.lastCreatedAt || 0);
        if (lastCreatedAt + CALL_SPAM_WINDOW_MS > now()) {
          throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Please wait before calling this number again." });
        }
        if (!active.empty) throw new TRPCError({ code: "CONFLICT", message: "User is unavailable." });
        const createdAt = now();
        transaction.set(throttleRef, { lastCreatedAt: createdAt });
        transaction.set(callRef, { callerUid, receiverUid: receiver.userId, callerNumber: input.callerNumber, receiverNumber: input.receiverNumber, status: "calling", createdAt, updatedAt: createdAt });
      });
      return { callId: callRef.id };
    }),

    submitOffer: publicProcedure.input(z.object({ callId: z.string().min(1), offer: rtcDescriptionInput })).mutation(async ({ ctx, input }) => {
      const uid = await requireFirebaseUser(ctx);
      const db = getFirebaseAdminDb();
      const callRef = db.collection("calls").doc(input.callId);
      const started = await db.runTransaction(async (transaction) => {
        const call = await transaction.get(callRef);
        if (!call.exists) throw new TRPCError({ code: "NOT_FOUND", message: "Call not found." });
        const data = call.data() as { callerUid: string; receiverUid: string; status: string };
        if (data.callerUid !== uid || data.status !== "calling") throw new TRPCError({ code: "FORBIDDEN", message: "This call can no longer be started." });
        const [callerProfile, receiverProfile] = await Promise.all([
          transaction.get(db.collection("users").doc(data.callerUid)),
          transaction.get(db.collection("users").doc(data.receiverUid)),
        ]);
        if (isCallDeniedByBlock({ callerUid: data.callerUid, receiverUid: data.receiverUid, callerBlockedUids: callerProfile.data()?.blockedHashes, receiverBlockedUids: receiverProfile.data()?.blockedHashes })) {
          transaction.update(callRef, { status: "rejected", updatedAt: now() });
          return false;
        }
        transaction.update(callRef, { offer: input.offer, status: "ringing", updatedAt: now() });
        return true;
      });
      if (!started) throw new TRPCError({ code: "FORBIDDEN", message: "User is unavailable." });
      return { success: true };
    }),

    submitAnswer: publicProcedure.input(z.object({ callId: z.string().min(1), answer: rtcDescriptionInput })).mutation(async ({ ctx, input }) => {
      const uid = await requireFirebaseUser(ctx);
      const db = getFirebaseAdminDb();
      const callRef = db.collection("calls").doc(input.callId);
      const accepted = await db.runTransaction(async (transaction) => {
        const call = await transaction.get(callRef);
        if (!call.exists) throw new TRPCError({ code: "NOT_FOUND", message: "Call not found." });
        const data = call.data() as { callerUid: string; receiverUid: string; status: string };
        if (data.receiverUid !== uid || data.status !== "ringing") throw new TRPCError({ code: "FORBIDDEN", message: "This call can no longer be answered." });
        const [callerProfile, receiverProfile] = await Promise.all([
          transaction.get(db.collection("users").doc(data.callerUid)),
          transaction.get(db.collection("users").doc(data.receiverUid)),
        ]);
        if (isCallDeniedByBlock({ callerUid: data.callerUid, receiverUid: data.receiverUid, callerBlockedUids: callerProfile.data()?.blockedHashes, receiverBlockedUids: receiverProfile.data()?.blockedHashes })) {
          transaction.update(callRef, { status: "rejected", updatedAt: now() });
          return false;
        }
        transaction.update(callRef, { answer: input.answer, status: "connecting", updatedAt: now() });
        return true;
      });
      if (!accepted) throw new TRPCError({ code: "FORBIDDEN", message: "This call can no longer be answered." });
      return { success: true };
    }),

    addIceCandidate: publicProcedure.input(z.object({ callId: z.string().min(1), candidateId: z.string().uuid(), role: z.enum(["caller", "receiver"]), candidate: rtcCandidateInput })).mutation(async ({ ctx, input }) => {
      const uid = await requireFirebaseUser(ctx);
      const db = getFirebaseAdminDb();
      const call = await db.collection("calls").doc(input.callId).get();
      if (!call.exists) throw new TRPCError({ code: "NOT_FOUND", message: "Call not found." });
      const data = call.data() as { callerUid: string; receiverUid: string; status: string };
      const ownRole = data.callerUid === uid ? "caller" : data.receiverUid === uid ? "receiver" : null;
      if (!ownRole || ownRole !== input.role || !["calling", "ringing", "connecting", "connected", "reconnecting"].includes(data.status)) {
        throw new TRPCError({ code: "FORBIDDEN", message: "You cannot signal this call." });
      }
      await db.collection("calls").doc(input.callId).collection("candidates").doc(`${input.role}_${input.candidateId}`).set({ role: input.role, candidate: input.candidate, createdAt: now() });
      return { success: true };
    }),

    transition: publicProcedure.input(z.object({
      callId: z.string().min(1),
      status: z.enum(["connected", "reconnecting", "failed", "rejected", "cancelled", "timeout", "ended"]),
    })).mutation(async ({ ctx, input }) => {
      const uid = await requireFirebaseUser(ctx);
      const db = getFirebaseAdminDb();
      const callRef = db.collection("calls").doc(input.callId);
      await db.runTransaction(async (transaction) => {
        const call = await transaction.get(callRef);
        if (!call.exists) throw new TRPCError({ code: "NOT_FOUND", message: "Call not found." });
        const data = call.data() as { callerUid: string; receiverUid: string; callerNumber: string; receiverNumber: string; status: string };
        if (uid !== data.callerUid && uid !== data.receiverUid) {
          throw new TRPCError({ code: "FORBIDDEN", message: "You cannot update this call." });
        }
        if (data.status === input.status) return;
        const callerControls = input.status === "cancelled" || input.status === "timeout";
        const receiverControls = input.status === "rejected";
        const browserMediaControls = input.status === "connected" || input.status === "reconnecting" || input.status === "failed";
        const eitherCanEnd = input.status === "ended";
        const allowedActor = (callerControls && uid === data.callerUid)
          || (receiverControls && uid === data.receiverUid)
          || browserMediaControls
          || eitherCanEnd;
        const allowedState = input.status === "connected"
          ? ["connecting", "reconnecting"].includes(data.status)
          : input.status === "reconnecting"
            ? data.status === "connected"
            : input.status === "failed"
              ? ["calling", "ringing", "connecting", "connected", "reconnecting"].includes(data.status)
              : input.status === "ended"
                ? ["connected", "reconnecting"].includes(data.status)
                : ["calling", "ringing"].includes(data.status);
        if (!allowedActor || !allowedState) {
          throw new TRPCError({ code: "FORBIDDEN", message: "This call can no longer be updated that way." });
        }
        if (input.status === "connected" || input.status === "reconnecting") {
          const [callerProfile, receiverProfile] = await Promise.all([
            transaction.get(db.collection("users").doc(data.callerUid)),
            transaction.get(db.collection("users").doc(data.receiverUid)),
          ]);
          if (isCallDeniedByBlock({ callerUid: data.callerUid, receiverUid: data.receiverUid, callerBlockedUids: callerProfile.data()?.blockedHashes, receiverBlockedUids: receiverProfile.data()?.blockedHashes })) {
            transaction.update(callRef, { status: "failed", updatedAt: now() });
            return;
          }
        }
        const updatedAt = now();
        transaction.update(callRef, { status: input.status, updatedAt });
        if (["rejected", "cancelled", "timeout", "ended", "failed"].includes(input.status)) {
          const receiverStatus = input.status === "timeout" ? "missed" : input.status;
          const sharedHistory = { callId: input.callId, callerNumber: data.callerNumber, receiverNumber: data.receiverNumber, status: input.status, updatedAt };
          transaction.set(db.collection("users").doc(data.callerUid).collection("call_history").doc(input.callId), { ...sharedHistory, direction: "outgoing", outcome: input.status }, { merge: true });
          transaction.set(db.collection("users").doc(data.receiverUid).collection("call_history").doc(input.callId), { ...sharedHistory, direction: "incoming", outcome: receiverStatus }, { merge: true });
        }
      });
      return { success: true };
    }),
  }),
});

export type AppRouter = typeof appRouter;
