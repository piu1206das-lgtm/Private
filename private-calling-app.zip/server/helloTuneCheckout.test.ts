import { describe, expect, it } from "vitest";
import { getHelloTunePack, helloTunePacks } from "./helloTuneCheckout";

describe("HelloTune checkout catalog", () => {
  it("preserves the existing four pack prices and validity periods as server-owned data", () => {
    expect(helloTunePacks.map((pack) => [pack.price, pack.validity])).toEqual([[3, "7 Days"], [5, "30 Days"], [9, "100 Days"], [15, "376 Days"]]);
    expect(getHelloTunePack("year")?.validMs).toBe(376 * 24 * 3600 * 1000);
  });
});
