import type { Request, Response } from "express";
import { reconcileAllRechargeEntitlements } from "./rechargeEntitlementService";
import { sdk } from "./_core/sdk";

/** Managed scheduler callback. It is not publicly callable and is idempotent across retried runs. */
export async function scheduledRechargeReconciliation(req: Request, res: Response) {
  try {
    const user = await sdk.authenticateRequest(req);
    if (!user.isCron || !user.taskUid) return res.status(403).json({ error: "cron-only" });
    const result = await reconcileAllRechargeEntitlements();
    return res.json({ ok: true, taskUid: user.taskUid, ...result });
  } catch (error) {
    return res.status(500).json({
      error: error instanceof Error ? error.message : "Recharge reconciliation failed.",
      context: { path: req.path },
      timestamp: Date.now(),
    });
  }
}
