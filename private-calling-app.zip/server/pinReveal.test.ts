import { createHash } from "node:crypto";
import { describe, expect, it } from "vitest";
import type { TrpcContext } from "./_core/context";
import { appRouter, resolveFourDigitPin } from "./routers";

const hash = (value: string) => createHash("sha256").update(value).digest("hex");

describe("Calling PIN reveal", () => {
  it("resolves only an existing four-digit hash and preserves leading zeroes", () => {
    expect(resolveFourDigitPin(hash("0042"))).toBe("0042");
    expect(resolveFourDigitPin("not-a-calling-pin-hash")).toBeNull();
  });

  it("rejects an unauthenticated reveal request before any profile data is read", async () => {
    const caller = appRouter.createCaller({
      user: null,
      req: { header: () => undefined },
      res: {},
    } as TrpcContext);
    await expect(caller.pin.revealOwn({})).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });
});
