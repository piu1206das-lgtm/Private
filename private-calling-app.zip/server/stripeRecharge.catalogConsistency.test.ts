import { beforeEach, describe, expect, it, vi } from "vitest";
import { rechargePlans } from "./rechargePlans";

const checkoutCreate = vi.fn();
const purchaseRef = { get: vi.fn(), id: "purchase" };
const db = {
  collection: vi.fn(() => ({ doc: vi.fn(() => purchaseRef) })),
  runTransaction: vi.fn(),
};

vi.mock("./firebaseAdmin", () => ({ getFirebaseAdminDb: () => db }));
vi.mock("./stripeClient", () => ({
  getStripe: () => ({ checkout: { sessions: { create: checkoutCreate } } }),
  requireSafeCheckoutOrigin: () => "https://app.example.test",
}));
vi.mock("./rechargeEntitlementService", () => ({ fulfillVerifiedRechargePurchase: vi.fn() }));
vi.mock("./vipPurchaseService", () => ({ fulfillVerifiedVipPurchase: vi.fn() }));
vi.mock("./helloTuneCheckout", () => ({ fulfillVerifiedHelloTunePurchase: vi.fn() }));

import { createRechargeCheckout } from "./stripeRecharge";

describe("Recharge checkout catalog consistency", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    purchaseRef.get.mockResolvedValue({ exists: false });
    checkoutCreate.mockImplementation(async () => ({ id: `cs_${checkoutCreate.mock.calls.length}`, url: "https://checkout.example.test" }));
    db.runTransaction.mockImplementation(async (callback: (transaction: { get: () => Promise<{ exists: boolean }>; create: () => void }) => Promise<void>) => callback({ get: async () => ({ exists: false }), create: vi.fn() }));
  });

  it("uses the same server catalog name, price, and validity in every checkout line item", async () => {
    for (const [index, plan] of rechargePlans.entries()) {
      await createRechargeCheckout({ purchaserUid: "purchaser", recipientUid: "recipient", planId: plan.planId, requestId: `request-${index}`, origin: "https://app.example.test" });
      const [checkoutInput] = checkoutCreate.mock.calls[index];
      expect(checkoutInput.metadata.plan_id).toBe(plan.planId);
      expect(checkoutInput.line_items[0].price_data).toMatchObject({
        currency: "inr",
        unit_amount: Math.round(plan.price * 100),
        product_data: { name: plan.planName, description: plan.validity },
      });
    }
  });
});
