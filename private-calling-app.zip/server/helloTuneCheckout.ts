import { getFirebaseAdminDb } from "./firebaseAdmin";
import { getStripe, requireSafeCheckoutOrigin } from "./stripeClient";

export const helloTunePacks = [
  { id: "mini", name: "Mini", price: 3, validity: "7 Days", validMs: 7 * 24 * 3600 * 1000 },
  { id: "plus", name: "Plus", price: 5, validity: "30 Days", validMs: 30 * 24 * 3600 * 1000 },
  { id: "long", name: "Long", price: 9, validity: "100 Days", validMs: 100 * 24 * 3600 * 1000 },
  { id: "year", name: "Year", price: 15, validity: "376 Days", validMs: 376 * 24 * 3600 * 1000 },
] as const;

export function getHelloTunePack(packId: string) { return helloTunePacks.find((pack) => pack.id === packId); }

export async function createHelloTuneCheckout(input: { purchaserUid: string; purchaserEmail?: string; packId: string; requestId: string; clip: { name: string; url: string; storagePath: string; clipStartSeconds: number; clipEndSeconds: number; clipDurationSeconds: number }; origin?: string }) {
  const pack = getHelloTunePack(input.packId);
  if (!pack) throw new Error("This HelloTune pack is unavailable.");
  if (!input.clip.storagePath.startsWith(`hellotune-pending/${input.purchaserUid}/`)) throw new Error("The selected HelloTune clip is invalid.");
  const db = getFirebaseAdminDb();
  const purchaseId = `${input.purchaserUid}_${input.requestId}`;
  const purchaseRef = db.collection("hellotune_purchases").doc(purchaseId);
  const prior = await purchaseRef.get();
  const stripe = getStripe();
  if (prior.exists) {
    const data = prior.data()!;
    if (data.packId !== pack.id || data.clip?.storagePath !== input.clip.storagePath) throw new Error("This payment request is already tied to another HelloTune selection.");
    if (data.status === "fulfilled") return { purchaseId, alreadyFulfilled: true, checkoutUrl: null };
    const session = await stripe.checkout.sessions.retrieve(String(data.checkoutSessionId));
    return { purchaseId, alreadyFulfilled: false, checkoutUrl: session.url || null };
  }
  const baseUrl = requireSafeCheckoutOrigin(input.origin);
  const metadata = { fulfillment_kind: "hellotune", purchase_id: purchaseId, purchaser_uid: input.purchaserUid, pack_id: pack.id };
  const session = await stripe.checkout.sessions.create({ mode: "payment", client_reference_id: input.purchaserUid, ...(input.purchaserEmail ? { customer_email: input.purchaserEmail } : {}), allow_promotion_codes: true, metadata, payment_intent_data: { metadata }, line_items: [{ quantity: 1, price_data: { currency: "inr", unit_amount: pack.price * 100, product_data: { name: `HelloTune ${pack.name}`, description: pack.validity } } }], success_url: `${baseUrl}/?hellotune=success&session_id={CHECKOUT_SESSION_ID}`, cancel_url: `${baseUrl}/?hellotune=cancelled` }, { idempotencyKey: `hellotune-${purchaseId}` });
  if (!session.url) throw new Error("Secure checkout could not be started.");
  await purchaseRef.create({ purchaseId, purchaserUid: input.purchaserUid, requestId: input.requestId, packId: pack.id, clip: input.clip, checkoutSessionId: session.id, status: "pending_payment", createdAt: Date.now() });
  return { purchaseId, alreadyFulfilled: false, checkoutUrl: session.url };
}

export async function fulfillVerifiedHelloTunePurchase(input: { purchaseId: string; purchaserUid: string; packId: string; checkoutSessionId: string; paymentIntentId?: string }) {
  const pack = getHelloTunePack(input.packId);
  if (!pack) throw new Error("Verified HelloTune checkout references an unknown pack.");
  const db = getFirebaseAdminDb();
  const purchaseRef = db.collection("hellotune_purchases").doc(input.purchaseId);
  const profileRef = db.collection("users").doc(input.purchaserUid);
  await db.runTransaction(async (transaction) => {
    const purchase = await transaction.get(purchaseRef);
    if (!purchase.exists) throw new Error("Verified HelloTune purchase was not found.");
    const data = purchase.data()!;
    if (data.status === "fulfilled") return;
    if (data.purchaserUid !== input.purchaserUid || data.packId !== pack.id || data.checkoutSessionId !== input.checkoutSessionId) throw new Error("Verified HelloTune purchase does not match its checkout.");
    const paidAt = Date.now();
    transaction.update(profileRef, { activeHelloTunePass: { planId: pack.id, purchasedAt: paidAt, expiresAt: paidAt + pack.validMs }, helloTune: { ...data.clip, activatedAt: paidAt } });
    transaction.update(purchaseRef, { status: "fulfilled", fulfilledAt: paidAt, ...(input.paymentIntentId ? { paymentIntentId: input.paymentIntentId } : {}) });
  });
  return { fulfilled: true };
}
