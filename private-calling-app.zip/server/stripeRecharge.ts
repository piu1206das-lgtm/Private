import express, { type Express, type Request, type Response } from "express";
import Stripe from "stripe";
import { getFirebaseAdminDb } from "./firebaseAdmin";
import { fulfillVerifiedRechargePurchase } from "./rechargeEntitlementService";
import { getRechargePlan } from "./rechargePlans";
import { getStripe, requireSafeCheckoutOrigin } from "./stripeClient";
import { fulfillVerifiedVipPurchase } from "./vipPurchaseService";
import { fulfillVerifiedHelloTunePurchase } from "./helloTuneCheckout";

export async function createRechargeCheckout(input: {
  purchaserUid: string;
  purchaserEmail?: string;
  recipientUid: string;
  recipientNumber?: string;
  planId: string;
  requestId: string;
  origin?: string;
}) {
  const plan = getRechargePlan(input.planId);
  if (!plan) throw new Error("This recharge plan is unavailable.");
  const db = getFirebaseAdminDb();
  const purchaseId = `${input.purchaserUid}_${input.requestId}`;
  const purchaseRef = db.collection("recharge_purchases").doc(purchaseId);
  const existing = await purchaseRef.get();
  const stripe = getStripe();

  if (existing.exists) {
    const prior = existing.data()!;
    if (prior.planId !== plan.planId || prior.recipientUid !== input.recipientUid) {
      throw new Error("This purchase request was already used for another recharge.");
    }
    if (prior.status === "fulfilled") return { purchaseId, alreadyFulfilled: true, checkoutUrl: null };
    const session = await stripe.checkout.sessions.retrieve(String(prior.checkoutSessionId));
    if (!session.url) throw new Error("This secure checkout session can no longer be resumed. Start a new purchase.");
    return { purchaseId, alreadyFulfilled: false, checkoutUrl: session.url };
  }

  const baseUrl = requireSafeCheckoutOrigin(input.origin);
  const metadata = {
    fulfillment_kind: "recharge",
    purchase_id: purchaseId,
    purchaser_uid: input.purchaserUid,
    recipient_uid: input.recipientUid,
    recipient_number: input.recipientNumber || "",
    plan_id: plan.planId,
  };
  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    client_reference_id: input.purchaserUid,
    ...(input.purchaserEmail ? { customer_email: input.purchaserEmail } : {}),
    allow_promotion_codes: true,
    metadata,
    payment_intent_data: { metadata },
    line_items: [{
      quantity: 1,
      price_data: {
        currency: "inr",
        unit_amount: Math.round(plan.price * 100),
        product_data: { name: plan.planName, description: plan.validity },
      },
    }],
    success_url: `${baseUrl}/?recharge=success&session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${baseUrl}/?recharge=cancelled`,
  }, { idempotencyKey: `recharge-${purchaseId}` });
  if (!session.url) throw new Error("Secure checkout could not be started.");

  await db.runTransaction(async transaction => {
    const current = await transaction.get(purchaseRef);
    if (current.exists) {
      const prior = current.data()!;
      if (prior.checkoutSessionId !== session.id) throw new Error("A conflicting purchase request already exists.");
      return;
    }
    transaction.create(purchaseRef, {
      purchaseId,
      purchaserUid: input.purchaserUid,
      recipientUid: input.recipientUid,
      ...(input.recipientNumber ? { recipientNumber: input.recipientNumber } : {}),
      planId: plan.planId,
      requestId: input.requestId,
      checkoutSessionId: session.id,
      status: "pending_payment",
      createdAt: Date.now(),
    });
  });

  return { purchaseId, alreadyFulfilled: false, checkoutUrl: session.url };
}

async function processSuccessfulCheckout(session: Stripe.Checkout.Session) {
  if (session.payment_status !== "paid") return { skipped: "payment_not_paid" };
  const metadata = session.metadata || {};
  const paymentIntentId = typeof session.payment_intent === "string" ? session.payment_intent : session.payment_intent?.id;
  if (metadata.fulfillment_kind === "vip") {
    const purchaseId = metadata.purchase_id;
    const purchaserUid = metadata.purchaser_uid;
    const number = metadata.vip_number;
    if (!purchaseId || !purchaserUid || !number) throw new Error("Verified checkout is missing required VIP metadata.");
    return fulfillVerifiedVipPurchase({ purchaseId, purchaserUid, number, checkoutSessionId: session.id, ...(paymentIntentId ? { paymentIntentId } : {}) });
  }
  if (metadata.fulfillment_kind === "hellotune") {
    const purchaseId = metadata.purchase_id;
    const purchaserUid = metadata.purchaser_uid;
    const packId = metadata.pack_id;
    if (!purchaseId || !purchaserUid || !packId) throw new Error("Verified checkout is missing required HelloTune metadata.");
    return fulfillVerifiedHelloTunePurchase({ purchaseId, purchaserUid, packId, checkoutSessionId: session.id, ...(paymentIntentId ? { paymentIntentId } : {}) });
  }
  if (metadata.fulfillment_kind !== "recharge") throw new Error("Verified checkout has an unknown fulfillment type.");
  const plan = getRechargePlan(metadata.plan_id || "");
  const purchaseId = metadata.purchase_id;
  const purchaserUid = metadata.purchaser_uid;
  const recipientUid = metadata.recipient_uid;
  if (!plan || !purchaseId || !purchaserUid || !recipientUid) {
    throw new Error("Verified checkout is missing its required Recharge metadata.");
  }
  return fulfillVerifiedRechargePurchase({
    purchaseId,
    purchaserUid,
    recipientUid,
    recipientNumber: metadata.recipient_number || undefined,
    plan,
    checkoutSessionId: session.id,
    ...(paymentIntentId ? { paymentIntentId } : {}),
  });
}

export function registerStripeRechargeWebhook(app: Express) {
  app.post("/api/stripe/webhook", express.raw({ type: "application/json" }), async (req: Request, res: Response) => {
    try {
      const signature = req.headers["stripe-signature"];
      if (typeof signature !== "string") return res.status(400).json({ error: "Missing Stripe signature." });
      const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
      if (!webhookSecret) return res.status(503).json({ error: "Stripe webhook verification is not configured." });
      const event = getStripe().webhooks.constructEvent(req.body, signature, webhookSecret);
      if (event.id.startsWith("evt_test_")) {
        console.log("[Webhook] Test event detected, returning verification response");
        return res.json({ verified: true });
      }
      if (event.type === "checkout.session.completed" || event.type === "checkout.session.async_payment_succeeded") {
        const result = await processSuccessfulCheckout(event.data.object as Stripe.Checkout.Session);
        return res.json({ received: true, fulfilled: true, result });
      }
      return res.json({ received: true, fulfilled: false });
    } catch (error) {
      console.error("[Stripe webhook] Verification or Recharge fulfillment failed", error);
      return res.status(500).json({ error: error instanceof Error ? error.message : "Webhook processing failed." });
    }
  });
}
