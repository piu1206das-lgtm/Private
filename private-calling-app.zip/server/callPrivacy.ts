import { createHash } from "node:crypto";

function uidHash(value: string) {
  return createHash("sha256").update(value).digest("hex");
}

export function isCallDeniedByBlock(input: {
  callerUid: string;
  receiverUid: string;
  callerBlockedUids?: unknown;
  receiverBlockedUids?: unknown;
}) {
  const callerBlocks = Array.isArray(input.callerBlockedUids) ? input.callerBlockedUids : [];
  const receiverBlocks = Array.isArray(input.receiverBlockedUids) ? input.receiverBlockedUids : [];
  return input.callerUid === input.receiverUid
    || callerBlocks.includes(input.receiverUid)
    || callerBlocks.includes(uidHash(input.receiverUid))
    || receiverBlocks.includes(input.callerUid)
    || receiverBlocks.includes(uidHash(input.callerUid));
}

/** Same reporter, number, category and normalized description always maps to one server record. */
export function reportIdFor(input: { reporterUid: string; reportedNumber: string; category: string; description?: string }) {
  const normalizedDescription = (input.description || "").trim().replace(/\s+/g, " ").toLowerCase();
  const contentHash = createHash("sha256").update(`${input.category}\n${normalizedDescription}`).digest("hex").slice(0, 24);
  return `${input.reporterUid}_${input.reportedNumber}_${contentHash}`;
}
