import { describe, expect, it } from "vitest";
import { applyVerifiedPermanentPurchase, reconcilePermanentEntitlements, type PermanentEntitlement } from "./entitlements";
import { getRechargePlan } from "./rechargePlans";

const HOUR = 60 * 60 * 1000;
const DAY = 24 * HOUR;
const NOW = Date.UTC(2026, 7, 27, 0, 0, 0);
const freedom = getRechargePlan("50d-freedom")!;
const dual = getRechargePlan("100d-dual")!;

function active(planId = freedom.planId, start = NOW, days = 50): PermanentEntitlement {
  return {
    entitlementId: `entitlement-${planId}`,
    purchaseIds: ["purchase-existing"],
    planId,
    status: "active",
    entitlementStart: start,
    entitlementExpiry: start + days * DAY,
    activatedAt: start,
    createdAt: start,
    updatedAt: start,
  };
}

describe("Recharge entitlement lifecycle", () => {
  it("activates a first verified 50-Day Freedom purchase from the server timestamp", () => {
    const result = applyVerifiedPermanentPurchase([], freedom, "purchase-1", NOW);
    expect(result.mode).toBe("activated");
    expect(result.current).toMatchObject({ planId: "50d-freedom", status: "active", entitlementStart: NOW, entitlementExpiry: NOW + 50 * DAY });
  });

  it("stacks the same active plan onto its existing final expiry", () => {
    const current = active(freedom.planId, NOW - 30 * DAY, 50);
    const result = applyVerifiedPermanentPurchase([current], freedom, "purchase-2", NOW);
    expect(result.mode).toBe("stacked");
    expect(result.current?.entitlementExpiry).toBe(NOW + 70 * DAY);
    expect(result.current?.purchaseIds).toEqual(["purchase-existing", "purchase-2"]);
  });

  it("queues a different permanent plan after the active plan instead of replacing it", () => {
    const current = active();
    const result = applyVerifiedPermanentPurchase([current], dual, "purchase-3", NOW);
    expect(result.current?.planId).toBe("50d-freedom");
    expect(result.upcoming).toHaveLength(1);
    expect(result.upcoming[0]).toMatchObject({ planId: "100d-dual", status: "upcoming", entitlementStart: NOW + 50 * DAY, entitlementExpiry: NOW + 150 * DAY });
  });

  it("promotes the next queued plan when an expired plan is reconciled after the app was closed", () => {
    const current = active(freedom.planId, NOW - 50 * DAY, 50);
    const queued: PermanentEntitlement = {
      ...active(dual.planId, NOW, 100),
      entitlementId: "entitlement-dual",
      purchaseIds: ["purchase-dual"],
      status: "upcoming",
      entitlementStart: NOW,
      entitlementExpiry: NOW + 100 * DAY,
      activatedAt: 0,
    };
    const result = reconcilePermanentEntitlements([current, queued], NOW + DAY);
    expect(result.current).toMatchObject({ entitlementId: "entitlement-dual", status: "active", activatedAt: NOW });
    expect(result.records.find(record => record.entitlementId === current.entitlementId)?.status).toBe("expired");
  });

  it("does not extend entitlement twice when a verified payment webhook is delivered twice", () => {
    const first = applyVerifiedPermanentPurchase([], freedom, "purchase-once", NOW);
    const replay = applyVerifiedPermanentPurchase(first.records, freedom, "purchase-once", NOW + DAY);
    expect(replay.mode).toBe("already-applied");
    expect(replay.current?.entitlementExpiry).toBe(NOW + 50 * DAY);
    expect(replay.records).toHaveLength(1);
  });

  it("keeps queued purchases deterministically ordered and stacks a matching queue tail", () => {
    const queued = applyVerifiedPermanentPurchase([active()], dual, "purchase-dual-1", NOW);
    const stackedQueue = applyVerifiedPermanentPurchase(queued.records, dual, "purchase-dual-2", NOW);
    expect(stackedQueue.upcoming).toHaveLength(1);
    expect(stackedQueue.upcoming[0].entitlementExpiry).toBe(NOW + 250 * DAY);
  });
});
