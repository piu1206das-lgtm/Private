import { beforeEach, afterEach, describe, expect, it } from "vitest";
import type { TrpcContext } from "./_core/context";
import { getFirebaseAdminAuth, getFirebaseAdminDb } from "./firebaseAdmin";
import { appRouter } from "./routers";

const FIREBASE_WEB_API_KEY = "AIzaSyDkpHFS_vL1nST9rTTVlC9L5jDZlCfDVTc";
const suffix = `${Date.now()}${Math.floor(Math.random() * 1000)}`.slice(-7);
const callerA = { uid: `call-state-a-${suffix}`, number: `71${suffix.slice(0, 6)}` };
const callerB = { uid: `call-state-b-${suffix}`, number: `72${suffix.slice(0, 6)}` };
const callerC = { uid: `call-state-c-${suffix}`, number: `73${suffix.slice(0, 6)}` };
const participants = [callerA, callerB, callerC];
let callIds: string[] = [];

async function tokenFor(uid: string) {
  const customToken = await getFirebaseAdminAuth().createCustomToken(uid);
  const response = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken?key=${FIREBASE_WEB_API_KEY}`, {
    method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ token: customToken, returnSecureToken: true }),
  });
  expect(response.ok).toBe(true);
  return (await response.json() as { idToken: string }).idToken;
}

function caller(token: string) {
  return appRouter.createCaller({ user: null, req: { header: (name: string) => name.toLowerCase() === "authorization" ? `Bearer ${token}` : undefined }, res: {} } as TrpcContext);
}

async function startRinging(from: typeof callerA, to: typeof callerB) {
  const client = caller(await tokenFor(from.uid));
  const started = await client.calls.start({ callerNumber: from.number, receiverNumber: to.number });
  callIds.push(started.callId);
  await client.calls.submitOffer({ callId: started.callId, offer: { type: "offer", sdp: "simulation-offer" } });
  return { callId: started.callId, fromClient: client, toClient: caller(await tokenFor(to.uid)) };
}

async function connect(call: Awaited<ReturnType<typeof startRinging>>) {
  await call.toClient.calls.submitAnswer({ callId: call.callId, answer: { type: "answer", sdp: "simulation-answer" } });
  await call.fromClient.calls.transition({ callId: call.callId, status: "connected" });
}

async function cleanFixtures() {
  const db = getFirebaseAdminDb();
  await Promise.all(callIds.flatMap(callId => [
    db.collection("calls").doc(callId).delete(),
    ...participants.map(person => db.collection("users").doc(person.uid).collection("call_history").doc(callId).delete()),
  ]));
  await Promise.all(participants.flatMap(person => [
    db.collection("users").doc(person.uid).delete(),
    db.collection("assigned_numbers").doc(person.number).delete(),
    db.collection("call_policies").doc(person.uid).delete(),
  ]));
  await Promise.all([
    db.collection("pin_attempts").doc(`${callerA.uid}_${callerB.uid}`).delete(),
    db.collection("pin_attempts").doc(`${callerC.uid}_${callerB.uid}`).delete(),
    db.collection("call_throttle").doc(`${callerA.uid}_${callerB.uid}`).delete(),
    db.collection("call_throttle").doc(`${callerC.uid}_${callerB.uid}`).delete(),
    ...participants.map(person => getFirebaseAdminAuth().deleteUser(person.uid).catch(() => undefined)),
  ]);
  callIds = [];
}

beforeEach(async () => {
  await cleanFixtures();
  const db = getFirebaseAdminDb();
  const createdAt = Date.now();
  await Promise.all(participants.flatMap(person => [
    db.collection("users").doc(person.uid).set({ uid: person.uid, email: `${person.uid}@example.invalid`, isOnboarded: true, pinVersion: 0, dndEnabled: false, blockedHashes: [], virtualNumbers: [{ number: person.number, type: "primary", status: "active" }] }),
    db.collection("assigned_numbers").doc(person.number).set({ userId: person.uid, type: "permanent", assignedAt: createdAt }),
  ]));
  await Promise.all([
    db.collection("pin_attempts").doc(`${callerA.uid}_${callerB.uid}`).set({ authorizedUntil: createdAt + 120_000, pinVersion: 0 }),
    db.collection("pin_attempts").doc(`${callerC.uid}_${callerB.uid}`).set({ authorizedUntil: createdAt + 120_000, pinVersion: 0 }),
  ]);
});

afterEach(async () => { await cleanFixtures(); });

describe("persisted call lifecycle synchronization", () => {
  it("persists incoming ringing, accept, ongoing connection, end, and synchronized history", async () => {
    const call = await startRinging(callerA, callerB);
    expect((await getFirebaseAdminDb().collection("calls").doc(call.callId).get()).data()?.status).toBe("ringing");
    await connect(call);
    expect((await getFirebaseAdminDb().collection("calls").doc(call.callId).get()).data()?.status).toBe("connected");
    await call.fromClient.calls.transition({ callId: call.callId, status: "ended" });
    const [callDoc, outgoing, incoming] = await Promise.all([
      getFirebaseAdminDb().collection("calls").doc(call.callId).get(),
      getFirebaseAdminDb().collection("users").doc(callerA.uid).collection("call_history").doc(call.callId).get(),
      getFirebaseAdminDb().collection("users").doc(callerB.uid).collection("call_history").doc(call.callId).get(),
    ]);
    expect(callDoc.data()?.status).toBe("ended");
    expect(outgoing.data()).toMatchObject({ direction: "outgoing", outcome: "ended", status: "ended" });
    expect(incoming.data()).toMatchObject({ direction: "incoming", outcome: "ended", status: "ended" });
  }, 30_000);

  it("persists receiver decline with matching terminal history", async () => {
    const call = await startRinging(callerA, callerB);
    await call.toClient.calls.transition({ callId: call.callId, status: "rejected" });
    const [callDoc, incoming] = await Promise.all([
      getFirebaseAdminDb().collection("calls").doc(call.callId).get(),
      getFirebaseAdminDb().collection("users").doc(callerB.uid).collection("call_history").doc(call.callId).get(),
    ]);
    expect(callDoc.data()?.status).toBe("rejected");
    expect(incoming.data()).toMatchObject({ direction: "incoming", outcome: "rejected" });
  }, 30_000);

  it("persists reconnect recovery and allows the call to continue before ending", async () => {
    const call = await startRinging(callerA, callerB);
    await connect(call);
    await call.fromClient.calls.transition({ callId: call.callId, status: "reconnecting" });
    expect((await getFirebaseAdminDb().collection("calls").doc(call.callId).get()).data()?.status).toBe("reconnecting");
    await call.toClient.calls.transition({ callId: call.callId, status: "connected" });
    await call.toClient.calls.transition({ callId: call.callId, status: "ended" });
    expect((await getFirebaseAdminDb().collection("calls").doc(call.callId).get()).data()?.status).toBe("ended");
  }, 30_000);

  it("rejects another caller while a receiver has an ongoing call without creating a ghost record", async () => {
    const first = await startRinging(callerA, callerB);
    await connect(first);
    const second = caller(await tokenFor(callerC.uid));
    await expect(second.calls.start({ callerNumber: callerC.number, receiverNumber: callerB.number })).rejects.toMatchObject({ message: "User is unavailable." });
    const active = await getFirebaseAdminDb().collection("calls").where("receiverUid", "==", callerB.uid).where("status", "in", ["calling", "ringing", "connecting", "connected", "reconnecting"]).get();
    expect(active.docs.map(document => document.id)).toEqual([first.callId]);
  }, 30_000);

  it("marks an unanswered incoming call as timeout for the caller and missed for the receiver", async () => {
    const call = await startRinging(callerA, callerB);
    await call.fromClient.calls.transition({ callId: call.callId, status: "timeout" });
    const [callDoc, outgoing, incoming] = await Promise.all([
      getFirebaseAdminDb().collection("calls").doc(call.callId).get(),
      getFirebaseAdminDb().collection("users").doc(callerA.uid).collection("call_history").doc(call.callId).get(),
      getFirebaseAdminDb().collection("users").doc(callerB.uid).collection("call_history").doc(call.callId).get(),
    ]);
    expect(callDoc.data()?.status).toBe("timeout");
    expect(outgoing.data()).toMatchObject({ outcome: "timeout" });
    expect(incoming.data()).toMatchObject({ outcome: "missed" });
  }, 30_000);

  it("stops receiver ringing immediately when the caller cancels and writes one terminal record per participant", async () => {
    const call = await startRinging(callerA, callerB);
    await call.fromClient.calls.transition({ callId: call.callId, status: "cancelled" });
    const [ringing, callDoc, outgoing, incoming] = await Promise.all([
      getFirebaseAdminDb().collection("calls").where("receiverUid", "==", callerB.uid).where("status", "==", "ringing").get(),
      getFirebaseAdminDb().collection("calls").doc(call.callId).get(),
      getFirebaseAdminDb().collection("users").doc(callerA.uid).collection("call_history").doc(call.callId).get(),
      getFirebaseAdminDb().collection("users").doc(callerB.uid).collection("call_history").doc(call.callId).get(),
    ]);
    expect(ringing.empty).toBe(true);
    expect(callDoc.data()?.status).toBe("cancelled");
    expect(outgoing.data()).toMatchObject({ outcome: "cancelled" });
    expect(incoming.data()).toMatchObject({ outcome: "cancelled" });
  }, 30_000);
});
