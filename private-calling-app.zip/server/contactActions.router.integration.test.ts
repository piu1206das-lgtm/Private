import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { createHash } from "node:crypto";
import type { TrpcContext } from "./_core/context";
import { getFirebaseAdminAuth, getFirebaseAdminDb } from "./firebaseAdmin";
import { appRouter } from "./routers";
import { reportIdFor } from "./callPrivacy";

const FIREBASE_WEB_API_KEY = "AIzaSyDkpHFS_vL1nST9rTTVlC9L5jDZlCfDVTc";
const hash = (value: string) => createHash("sha256").update(value).digest("hex");
const suffix = `${Date.now()}${Math.floor(Math.random() * 1000)}`.slice(-7);
const reporter = { uid: `contact-test-a-${suffix}`, number: `71${suffix.slice(0, 6)}` };
const target = { uid: `contact-test-b-${suffix}`, number: `72${suffix.slice(0, 6)}` };
let createdCallId: string | null = null;

async function tokenFor(uid: string) {
  const customToken = await getFirebaseAdminAuth().createCustomToken(uid);
  const response = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken?key=${FIREBASE_WEB_API_KEY}`, {
    method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ token: customToken, returnSecureToken: true }),
  });
  expect(response.ok).toBe(true);
  return (await response.json() as { idToken: string }).idToken;
}

function caller(token: string) {
  return appRouter.createCaller({ user: null, req: { header: (name: string) => name.toLowerCase() === "authorization" ? `Bearer ${token}` : undefined }, res: {} } as TrpcContext);
}

async function cleanFixtures() {
  const db = getFirebaseAdminDb();
  const reportId = reportIdFor({ reporterUid: reporter.uid, reportedNumber: target.number, category: "scam", description: "Automated duplicate report" });
  await Promise.all([
    db.collection("users").doc(reporter.uid).delete(), db.collection("users").doc(target.uid).delete(),
    db.collection("assigned_numbers").doc(reporter.number).delete(), db.collection("assigned_numbers").doc(target.number).delete(),
    db.collection("pin_attempts").doc(`${target.uid}_${reporter.uid}`).delete(), db.collection("reports").doc(reportId).delete(),
    db.collection("call_policies").doc(reporter.uid).delete(), db.collection("call_policies").doc(target.uid).delete(),
    ...(createdCallId ? [db.collection("calls").doc(createdCallId).delete()] : []),
  ]);
  await Promise.all([getFirebaseAdminAuth().deleteUser(reporter.uid).catch(() => undefined), getFirebaseAdminAuth().deleteUser(target.uid).catch(() => undefined)]);
  createdCallId = null;
}

beforeEach(async () => {
  await cleanFixtures();
  const db = getFirebaseAdminDb();
  const createdAt = Date.now();
  await Promise.all([
    db.collection("users").doc(reporter.uid).set({ uid: reporter.uid, email: `${reporter.uid}@example.invalid`, isOnboarded: true, pinHash: "test", pinVersion: 0, dndEnabled: false, blockedUsersList: [], blockedHashes: [], virtualNumbers: [{ number: reporter.number, type: "primary", status: "active" }] }),
    db.collection("users").doc(target.uid).set({ uid: target.uid, email: `${target.uid}@example.invalid`, isOnboarded: true, pinHash: hash("1234"), pinVersion: 0, dndEnabled: false, blockedUsersList: [], blockedHashes: [], virtualNumbers: [{ number: target.number, type: "primary", status: "active" }] }),
    db.collection("assigned_numbers").doc(reporter.number).set({ userId: reporter.uid, type: "permanent", assignedAt: createdAt }),
    db.collection("assigned_numbers").doc(target.number).set({ userId: target.uid, type: "permanent", assignedAt: createdAt }),
    db.collection("pin_attempts").doc(`${target.uid}_${reporter.uid}`).set({ authorizedUntil: createdAt + 60_000, pinVersion: 0 }),
  ]);
});

afterEach(async () => { await cleanFixtures(); });

describe("Contact Details server actions", () => {
  it("persists a block, denies a blocked call, restores normal call eligibility after unblock, and rejects self calls", async () => {
    const [reporterToken, targetToken] = await Promise.all([tokenFor(reporter.uid), tokenFor(target.uid)]);
    const reporterCaller = caller(reporterToken);
    const targetCaller = caller(targetToken);

    await reporterCaller.privacy.block({ targetNumber: target.number, label: "Target" });
    expect((await reporterCaller.privacy.blockStatus({ targetNumber: target.number })).blocked).toBe(true);
    const saved = await getFirebaseAdminDb().collection("users").doc(reporter.uid).get();
    expect(saved.data()?.blockedUsersList?.some((entry: { number: string }) => entry.number === target.number)).toBe(true);
    await expect(targetCaller.calls.start({ callerNumber: target.number, receiverNumber: reporter.number })).rejects.toMatchObject({ message: "User is unavailable." });

    await reporterCaller.privacy.unblock({ targetNumber: target.number });
    expect((await reporterCaller.privacy.blockStatus({ targetNumber: target.number })).blocked).toBe(false);
    const allowed = await targetCaller.calls.start({ callerNumber: target.number, receiverNumber: reporter.number });
    createdCallId = allowed.callId;
    expect(createdCallId).toBeTruthy();
    await expect(reporterCaller.calls.start({ callerNumber: reporter.number, receiverNumber: reporter.number })).rejects.toMatchObject({ message: "You cannot call your own number." });
  }, 30_000);

  it("creates only one open report for repeated identical submissions", async () => {
    const reporterCaller = caller(await tokenFor(reporter.uid));
    const first = await reporterCaller.privacy.report({ targetNumber: target.number, category: "scam", description: "Automated duplicate report" });
    const retry = await reporterCaller.privacy.report({ targetNumber: target.number, category: "scam", description: "Automated duplicate report" });
    const saved = await getFirebaseAdminDb().collection("reports").doc(first.reportId).get();
    expect(first.created).toBe(true);
    expect(retry.created).toBe(false);
    expect(saved.data()).toMatchObject({ reportId: first.reportId, reporterUid: reporter.uid, reportedNumber: target.number, category: "scam", status: "OPEN" });
  }, 30_000);

  it("stores an optional contact PIN as a private hash, uses it for an 8-digit contact, and ignores it for a 7-digit contact", async () => {
    const reporterCaller = caller(await tokenFor(reporter.uid));
    const permanent = await reporterCaller.contacts.add({ name: "Permanent contact", number: target.number, callingPin: "1234" });
    const privateRecord = await getFirebaseAdminDb().collection("users").doc(reporter.uid).collection("contacts").doc(permanent.id).get();
    const listed = await reporterCaller.contacts.list();
    expect(privateRecord.data()).toMatchObject({ callingPinHash: hash("1234") });
    expect(privateRecord.data()?.callingPin).toBeUndefined();
    expect(listed.find(contact => contact.id === permanent.id)).toMatchObject({ hasCallingPin: true });
    expect(listed.find(contact => contact.id === permanent.id)).not.toHaveProperty("callingPinHash");
    expect(await reporterCaller.contacts.authorizeSavedPin({ id: permanent.id })).toMatchObject({ number: target.number, pinRequired: true, authorized: true });
    await reporterCaller.contacts.update({ id: permanent.id, name: "Renamed permanent contact", number: target.number });
    expect(await reporterCaller.contacts.authorizeSavedPin({ id: permanent.id })).toMatchObject({ number: target.number, pinRequired: true, authorized: true });

    const temporary = await reporterCaller.contacts.add({ name: "Temporary contact", number: "1234567", callingPin: "1234" });
    expect(await reporterCaller.contacts.authorizeSavedPin({ id: temporary.id })).toMatchObject({ number: "1234567", pinRequired: false, authorized: true });
    const temporaryRecord = await getFirebaseAdminDb().collection("users").doc(reporter.uid).collection("contacts").doc(temporary.id).get();
    expect(temporaryRecord.data()?.callingPinHash).toBe("");
  }, 30_000);
});
