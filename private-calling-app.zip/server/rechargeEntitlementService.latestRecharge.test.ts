import { describe, expect, it } from "vitest";
import { latestSuccessfulRechargeFromPurchases } from "./rechargeEntitlementService";

describe("latest successful Recharge summary", () => {
  it("selects exactly the most recent fulfilled recharge and ignores pending, failed, and malformed records", () => {
    const latest = latestSuccessfulRechargeFromPurchases([
      { purchaseId: "pending", planId: "50d-freedom", status: "pending_payment", fulfilledAt: 300 },
      { purchaseId: "failed", planId: "100d-dual", status: "failed", fulfilledAt: 400 },
      { purchaseId: "first", planId: "50d-freedom", status: "fulfilled", fulfilledAt: 100 },
      { purchaseId: "latest", planId: "100d-dual", status: "fulfilled", fulfilledAt: 200 },
      { purchaseId: "unknown", planId: "not-a-plan", status: "fulfilled", fulfilledAt: 500 },
    ]);

    expect(latest).toEqual({ purchaseId: "latest", planId: "100d-dual", planName: "Dual-Life", price: 33, validity: "100 Days", fulfilledAt: 200 });
  });

  it("returns no summary for a user with no fulfilled Recharge purchases", () => {
    expect(latestSuccessfulRechargeFromPurchases([{ purchaseId: "pending", planId: "50d-freedom", status: "pending_payment", fulfilledAt: 100 }])).toBeNull();
  });
});
