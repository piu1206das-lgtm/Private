import { describe, expect, it } from "vitest";
import { getFriendEligibleRechargePlan, getRechargePlan, rechargePlans } from "./rechargePlans";

describe("friend recharge plan eligibility", () => {
  it("permits existing account plans without changing a target number", () => {
    expect(getFriendEligibleRechargePlan("50d-freedom")?.price).toBe(17);
    expect(getFriendEligibleRechargePlan("vip-pass")).toBeUndefined();
  });

  it("rejects temporary-number plans because they cannot be applied to an existing target number", () => {
    expect(getFriendEligibleRechargePlan("1hr-shield")).toBeUndefined();
    expect(getFriendEligibleRechargePlan("not-a-plan")).toBeUndefined();
  });
});

describe("authoritative Recharge plan catalog", () => {
  it("keeps plan identity, category, benefits and configured validity together", () => {
    const freedom = getRechargePlan("50d-freedom");
    const temporary = getRechargePlan("7d-temp");
    expect(freedom).toMatchObject({ planId: "50d-freedom", planName: "50-Day Freedom", price: 17, validityValue: 50, validityUnit: "days", validity: "50 Days" });
    expect(temporary).toMatchObject({ planId: "7d-temp", validityValue: 7, validityUnit: "days", validity: "7 Days", kind: "temporary-number", temporaryNumberEntitlement: 1 });
    expect(temporary?.categories).toEqual(["Temporary"]);
    expect(freedom?.categories).toEqual(["Recommended", "Long Validity"]);
    expect(freedom?.benefits).toContain("1 Permanent 8-Digit Virtual Number");
  });

  it("does not infer plan validity or category from price or tab position", () => {
    expect(rechargePlans.map(plan => `${plan.planId}:${plan.validity}`)).toEqual([
      "50d-freedom:50 Days",
      "100d-dual:100 Days",
      "1hr-pass:1 Hour",
      "1hr-shield:1 Hour",
      "24hr-temp:24 Hours",
      "7d-temp:7 Days",
    ]);
  });

  it("does not expose the removed VIP Monthly Pass or a VIP recharge category", () => {
    expect(getRechargePlan("vip-pass")).toBeUndefined();
    expect(rechargePlans.some(plan => plan.categories.includes("VIP" as never))).toBe(false);
  });

  it("keeps all category membership consistent with actual validity and avoids short plans in Long Validity", () => {
    const longValidity = rechargePlans.filter(plan => plan.categories.includes("Long Validity"));
    const temporary = rechargePlans.filter(plan => plan.categories.includes("Temporary"));
    expect(longValidity.map(plan => plan.planId)).toEqual(["50d-freedom", "100d-dual"]);
    expect(longValidity.every(plan => plan.validityUnit === "days" && plan.validityValue >= 30)).toBe(true);
    expect(temporary.map(plan => plan.planId)).toEqual(["1hr-shield", "24hr-temp", "7d-temp"]);
    expect(temporary.every(plan => plan.kind === "temporary-number")).toBe(true);
    expect(getRechargePlan("1hr-pass")?.categories).toEqual([]);
    expect(rechargePlans.every(plan => plan.validity === `${plan.validityValue} ${plan.validityUnit === "hours" ? plan.validityValue === 1 ? "Hour" : "Hours" : plan.validityValue === 1 ? "Day" : "Days"}`)).toBe(true);
  });
});
