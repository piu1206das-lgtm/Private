import express, { type Express, type Request, type Response } from "express";
import { getFirebaseAdminAuth, getFirebaseAdminDb } from "./firebaseAdmin";
import { storagePut } from "./storage";

const MAX_CLIP_SECONDS = 40.01;
const MAX_CLIP_BYTES = 20 * 1024 * 1024;

function wavDurationSeconds(bytes: Buffer) {
  if (bytes.length < 44 || bytes.toString("ascii", 0, 4) !== "RIFF" || bytes.toString("ascii", 8, 12) !== "WAVE") throw new Error("The processed HelloTune clip must be a WAV file.");
  const byteRate = bytes.readUInt32LE(28);
  const dataLength = bytes.readUInt32LE(40);
  if (!byteRate || !dataLength || 44 + dataLength > bytes.length) throw new Error("The selected clip WAV data is invalid.");
  return dataLength / byteRate;
}

async function helloTuneClipUpload(req: Request, res: Response) {
  try {
    const authorization = req.header("authorization") || "";
    if (!authorization.startsWith("Bearer ")) return res.status(401).json({ message: "Sign in is required to upload a HelloTune clip." });
    const user = await getFirebaseAdminAuth().verifyIdToken(authorization.slice(7));
    const isPendingSelection = req.header("x-hellotune-upload-mode") === "pending-selection";
    const profile = await getFirebaseAdminDb().collection("users").doc(user.uid).get();
    const activePass = profile.data()?.activeHelloTunePass as { expiresAt?: number } | undefined;
    if (!profile.exists || (!isPendingSelection && (!activePass || Number(activePass.expiresAt || 0) <= Date.now()))) return res.status(403).json({ message: "An active HelloTune pack is required." });
    if (!Buffer.isBuffer(req.body) || req.body.length === 0) return res.status(400).json({ message: "No selected HelloTune clip was received." });
    if (req.body.length > MAX_CLIP_BYTES) return res.status(413).json({ message: "The selected HelloTune clip is too large." });
    const clipDurationSeconds = wavDurationSeconds(req.body);
    if (clipDurationSeconds > MAX_CLIP_SECONDS) return res.status(400).json({ message: "HelloTune clips must be 40 seconds or less." });
    const originalName = decodeURIComponent(req.header("x-hellotune-source-name") || "Selected audio").replace(/[\r\n]/g, "").slice(0, 160) || "Selected audio";
    const storagePrefix = isPendingSelection ? "hellotune-pending" : "hellotunes";
    const { key, url } = await storagePut(`${storagePrefix}/${user.uid}/${Date.now()}-selected.wav`, req.body, "audio/wav");
    return res.status(201).json({ storagePath: key, url, clipDurationSeconds, name: originalName });
  } catch (error) {
    console.error("HelloTune selected-clip upload failed", error);
    return res.status(400).json({ message: error instanceof Error ? error.message : "HelloTune selected-clip upload failed." });
  }
}

export function registerHelloTuneClipUpload(app: Express) {
  app.post("/api/hellotune/clip", express.raw({ type: "audio/wav", limit: MAX_CLIP_BYTES }), helloTuneClipUpload);
}
