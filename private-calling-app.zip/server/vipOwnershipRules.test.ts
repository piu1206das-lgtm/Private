import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const rules = readFileSync(new URL("../firestore.rules", import.meta.url), "utf8");

describe("VIP ownership Firestore policy", () => {
  it("does not permit a browser profile update to alter virtualNumbers", () => {
    const updateBlock = rules.match(/allow update: if ownsUser\(userId\)([\s\S]*?)allow delete:/)?.[1] || "";
    expect(updateBlock).not.toContain("'virtualNumbers'");
    expect(updateBlock).not.toContain("'activePass'");
  });

  it("limits onboarding-created virtual numbers to the existing primary and secondary 8-digit identities", () => {
    const createBlock = rules.match(/allow create: if ownsUser\(userId\)([\s\S]*?)allow update:/)?.[1] || "";
    expect(createBlock).toContain("virtualNumbers.size() == 2");
    expect(createBlock).toContain("virtualNumbers[0].type == 'primary'");
    expect(createBlock).toContain("virtualNumbers[1].type == 'secondary'");
    expect(createBlock).not.toContain("'vip'");
  });
});
