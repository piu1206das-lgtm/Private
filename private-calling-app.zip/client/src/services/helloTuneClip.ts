export const MAX_HELLOTUNE_CLIP_SECONDS = 40;
export const MIN_HELLOTUNE_CLIP_SECONDS = 0.1;

export type HelloTuneSelection = { start: number; end: number };

const clamp = (value: number, lower: number, upper: number) => Math.min(upper, Math.max(lower, value));

export function normalizeHelloTuneSelection(selection: HelloTuneSelection, sourceDuration: number): HelloTuneSelection {
  const duration = Math.max(0, Number.isFinite(sourceDuration) ? sourceDuration : 0);
  const start = clamp(Number.isFinite(selection.start) ? selection.start : 0, 0, duration);
  const maxEnd = Math.min(duration, start + MAX_HELLOTUNE_CLIP_SECONDS);
  const minimumEnd = Math.min(duration, start + MIN_HELLOTUNE_CLIP_SECONDS);
  const end = clamp(Number.isFinite(selection.end) ? selection.end : maxEnd, minimumEnd, maxEnd);
  return { start, end };
}

export function selectionForStart(start: number, current: HelloTuneSelection, sourceDuration: number) {
  const normalized = normalizeHelloTuneSelection(current, sourceDuration);
  const nextStart = clamp(start, 0, Math.max(0, normalized.end - MIN_HELLOTUNE_CLIP_SECONDS));
  return normalizeHelloTuneSelection({ start: nextStart, end: normalized.end }, sourceDuration);
}

export function selectionForEnd(end: number, current: HelloTuneSelection, sourceDuration: number) {
  const normalized = normalizeHelloTuneSelection(current, sourceDuration);
  return normalizeHelloTuneSelection({ start: normalized.start, end }, sourceDuration);
}

function encodeWav(audioBuffer: AudioBuffer) {
  const frameCount = audioBuffer.length;
  const channels = audioBuffer.numberOfChannels;
  const bytesPerSample = 2;
  const output = new ArrayBuffer(44 + frameCount * channels * bytesPerSample);
  const view = new DataView(output);
  const write = (offset: number, value: string) => Array.from(value).forEach((character, index) => view.setUint8(offset + index, character.charCodeAt(0)));
  write(0, "RIFF");
  view.setUint32(4, 36 + frameCount * channels * bytesPerSample, true);
  write(8, "WAVE");
  write(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, channels, true);
  view.setUint32(24, audioBuffer.sampleRate, true);
  view.setUint32(28, audioBuffer.sampleRate * channels * bytesPerSample, true);
  view.setUint16(32, channels * bytesPerSample, true);
  view.setUint16(34, 16, true);
  write(36, "data");
  view.setUint32(40, frameCount * channels * bytesPerSample, true);
  let offset = 44;
  for (let frame = 0; frame < frameCount; frame += 1) {
    for (let channel = 0; channel < channels; channel += 1) {
      const sample = Math.max(-1, Math.min(1, audioBuffer.getChannelData(channel)[frame] || 0));
      view.setInt16(offset, sample < 0 ? sample * 0x8000 : sample * 0x7fff, true);
      offset += bytesPerSample;
    }
  }
  return new Blob([output], { type: "audio/wav" });
}

/** Decodes only locally and returns a new WAV Blob containing exactly the selected clip. */
export async function createHelloTuneClip(file: Blob, selection: HelloTuneSelection, onProgress?: (progress: number) => void) {
  const AudioContextClass = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AudioContextClass) throw new Error("Audio trimming is not supported by this browser.");
  onProgress?.(8);
  const context = new AudioContextClass();
  try {
    const decoded = await context.decodeAudioData(await file.arrayBuffer());
    onProgress?.(38);
    const normalized = normalizeHelloTuneSelection(selection, decoded.duration);
    const frameStart = Math.floor(normalized.start * decoded.sampleRate);
    const frameEnd = Math.ceil(normalized.end * decoded.sampleRate);
    const clipped = context.createBuffer(decoded.numberOfChannels, Math.max(1, frameEnd - frameStart), decoded.sampleRate);
    for (let channel = 0; channel < decoded.numberOfChannels; channel += 1) {
      clipped.copyToChannel(decoded.getChannelData(channel).slice(frameStart, frameEnd), channel);
    }
    onProgress?.(65);
    return { blob: encodeWav(clipped), selection: normalized };
  } finally {
    await context.close().catch(() => undefined);
  }
}
