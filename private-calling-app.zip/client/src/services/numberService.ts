import { secureApi } from "./secureApi";

export const generate7DigitNumber = (): string => "";

export const assignUniqueNumber = async (userId: string): Promise<string> => {
  void userId;
  const result = await secureApi.numbers.assignPermanent.mutate();
  return result.number;
};
