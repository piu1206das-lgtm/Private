// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from "vitest";
import { MAX_HELLOTUNE_CLIP_SECONDS, createHelloTuneClip, normalizeHelloTuneSelection, selectionForEnd, selectionForStart } from "./helloTuneClip";

const originalAudioContext = window.AudioContext;

class FakeAudioBuffer {
  numberOfChannels: number;
  length: number;
  sampleRate: number;
  duration: number;
  private channels: Float32Array[];

  constructor(channels: number, length: number, sampleRate: number) {
    this.numberOfChannels = channels;
    this.length = length;
    this.sampleRate = sampleRate;
    this.duration = length / sampleRate;
    this.channels = Array.from({ length: channels }, () => new Float32Array(length).fill(0.2));
  }

  getChannelData(channel: number) { return this.channels[channel]; }
  copyToChannel(source: Float32Array, channel: number) { this.channels[channel].set(source); }
}

class FakeAudioContext {
  decodeAudioData = vi.fn(async () => new FakeAudioBuffer(1, 1_000, 10));
  createBuffer = (channels: number, length: number, sampleRate: number) => new FakeAudioBuffer(channels, length, sampleRate);
  close = vi.fn(async () => undefined);
}

afterEach(() => { Object.defineProperty(window, "AudioContext", { configurable: true, value: originalAudioContext }); });

describe("HelloTune clip selection", () => {
  it("caps every selected clip to the 40-second calling window", () => {
    expect(normalizeHelloTuneSelection({ start: 70, end: 130 }, 180)).toEqual({ start: 70, end: 70 + MAX_HELLOTUNE_CLIP_SECONDS });
  });

  it("keeps selection boundaries within the source and preserves an ordered range", () => {
    expect(normalizeHelloTuneSelection({ start: -5, end: 99 }, 20)).toEqual({ start: 0, end: 20 });
    expect(selectionForStart(25, { start: 0, end: 30 }, 90)).toEqual({ start: 25, end: 30 });
    expect(selectionForEnd(90, { start: 25, end: 30 }, 90)).toEqual({ start: 25, end: 65 });
  });

  it("encodes and returns only the selected ≤40-second audio range", async () => {
    Object.defineProperty(window, "AudioContext", { configurable: true, value: FakeAudioContext });
    const output = await createHelloTuneClip(new File(["original-source-audio"], "song.mp3", { type: "audio/mpeg" }), { start: 10, end: 70 });
    expect(output.selection).toEqual({ start: 10, end: 50 });
    expect(output.blob.type).toBe("audio/wav");
    expect(output.blob.size).toBe(44 + (40 * 10 * 2));
  });
});
