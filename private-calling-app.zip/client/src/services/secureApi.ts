import { httpBatchLink } from "@trpc/client";
import superjson from "superjson";
import { auth } from "../firebase";
import { trpc } from "../lib/trpc";

export const secureApi = trpc.createClient({
  links: [
    httpBatchLink({
      url: "/api/trpc",
      transformer: superjson,
      async headers() {
        const token = await auth?.currentUser?.getIdToken();
        return token ? { authorization: `Bearer ${token}` } : {};
      },
    }),
  ],
});
