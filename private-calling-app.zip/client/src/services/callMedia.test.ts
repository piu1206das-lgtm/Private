import { describe, expect, it, vi } from "vitest";
import { CallMediaSession, mediaStateFromPeerConnection } from "./callMedia";

describe("WebRTC call-state mapping", () => {
  it("marks connected only when the peer connection reports connected", () => {
    expect(mediaStateFromPeerConnection("connecting")).toBeNull();
    expect(mediaStateFromPeerConnection("connected")).toBe("connected");
  });

  it("maps real disconnection and failed peer states without pretending the call is connected", () => {
    expect(mediaStateFromPeerConnection("disconnected")).toBe("reconnecting");
    expect(mediaStateFromPeerConnection("failed")).toBe("failed");
  });

  it("sends only valid DTMF tones through the active audio sender", () => {
    const insertDTMF = vi.fn();
    const session = Object.create(CallMediaSession.prototype) as CallMediaSession;
    (session as any).peer = { getSenders: () => [{ track: { kind: "audio" }, dtmf: { insertDTMF } }] };

    expect(session.sendDtmf("5")).toBe(true);
    expect(insertDTMF).toHaveBeenCalledWith("5", 140, 70);
    expect(session.sendDtmf("A")).toBe(false);
  });
});
