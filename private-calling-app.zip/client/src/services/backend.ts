import { doc, updateDoc } from "firebase/firestore";
import { db } from "../firebase";
import { UserProfile } from "../types";
import { secureApi } from "./secureApi";

export type ReportCategory = "spam" | "harassment" | "scam" | "abuse" | "other";

export async function validatePinAndRecordAttempt(
  callerUid: string,
  targetNumber: string,
  pin: string,
): Promise<{ success: boolean; error?: string; lockedUntil?: number; targetUid?: string }> {
  void callerUid;
  const result = await secureApi.pin.verify.mutate({ targetNumber, pin });
  return {
    success: result.success,
    lockedUntil: result.lockedUntil,
    error: "error" in result ? result.error : undefined,
    targetUid: "targetUid" in result ? result.targetUid : undefined,
  };
}

export async function getPinCooldown(callerUid: string, targetNumber: string): Promise<number> {
  void callerUid;
  const result = await secureApi.pin.cooldown.query({ targetNumber });
  return result.lockedUntil;
}

export async function changePin(uid: string, currentPin: string, newPin: string): Promise<{ success: boolean; error?: string }> {
  void uid;
  try {
    return await secureApi.pin.change.mutate({ currentPin, newPin });
  } catch (error: any) {
    return { success: false, error: error?.message || "Unable to update PIN." };
  }
}

export async function blockUser(blockerUid: string, targetNumber: string, label?: string) {
  void blockerUid;
  return secureApi.privacy.block.mutate({ targetNumber, label });
}

export async function unblockUser(blockerUid: string, blockedUser: { uidHash?: string; deviceHash?: string; number: string } | string) {
  void blockerUid;
  return secureApi.privacy.unblock.mutate({ targetNumber: typeof blockedUser === "string" ? blockedUser : blockedUser.number });
}

export async function reportUser(reporterUid: string, targetNumber: string, category: ReportCategory, description?: string) {
  void reporterUid;
  return secureApi.privacy.report.mutate({ targetNumber, category, description });
}

export async function startCallSession(callerUid: string, callerNumber: string, receiverNumber: string, callerDeviceId: string): Promise<string> {
  void callerUid;
  void callerDeviceId;
  const result = await secureApi.calls.start.mutate({ callerNumber, receiverNumber });
  return result.callId;
}

export async function updateCallSession(callId: string, status: "connected" | "reconnecting" | "failed" | "rejected" | "cancelled" | "timeout" | "ended") {
  return secureApi.calls.transition.mutate({ callId, status });
}

export async function updateDND(uid: string, enabled: boolean) {
  void uid;
  return secureApi.privacy.setDnd.mutate({ enabled });
}

export async function updateNotificationSettings(uid: string, settings: UserProfile["notificationSettings"]) {
  await updateDoc(doc(db, "users", uid), { notificationSettings: settings });
}
