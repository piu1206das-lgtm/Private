import { collection, doc, onSnapshot, query, where, type Unsubscribe } from "firebase/firestore";
import { db } from "../firebase";
import { secureApi } from "./secureApi";

export type LiveCallState = "calling" | "ringing" | "connecting" | "connected" | "reconnecting" | "failed" | "disconnected";
type SignallingRole = "caller" | "receiver";

export function mediaStateFromPeerConnection(state: RTCPeerConnectionState): LiveCallState | null {
  if (state === "connected") return "connected";
  if (state === "disconnected") return "reconnecting";
  if (state === "failed") return "failed";
  return null;
}

export class CallMediaSession {
  private readonly role: SignallingRole;
  private peer: RTCPeerConnection | null = null;
  private localStream: MediaStream | null = null;
  private remoteStream = new MediaStream();
  private unsubscribers: Unsubscribe[] = [];
  private disconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private wasConnected = false;

  constructor(
    private readonly callId: string,
    isIncoming: boolean,
    private readonly onState: (state: LiveCallState) => void,
    private readonly onRemoteStream: (stream: MediaStream) => void,
  ) {
    this.role = isIncoming ? "receiver" : "caller";
  }

  async beginOutgoing(): Promise<void> {
    this.onState("calling");
    await this.preparePeer();
    const offer = await this.peer!.createOffer({ offerToReceiveAudio: true });
    await this.peer!.setLocalDescription(offer);
    await secureApi.calls.submitOffer.mutate({ callId: this.callId, offer: { type: "offer", sdp: offer.sdp || "" } });
    this.onState("ringing");
    this.listenForRemoteAnswerAndCandidates();
  }

  async acceptIncoming(offer: RTCSessionDescriptionInit): Promise<void> {
    this.onState("connecting");
    await this.preparePeer();
    await this.peer!.setRemoteDescription(offer);
    const answer = await this.peer!.createAnswer();
    await this.peer!.setLocalDescription(answer);
    await secureApi.calls.submitAnswer.mutate({ callId: this.callId, answer: { type: "answer", sdp: answer.sdp || "" } });
    this.listenForRemoteCandidates();
  }

  setMuted(muted: boolean) {
    this.localStream?.getAudioTracks().forEach((track) => { track.enabled = !muted; });
  }

  sendDtmf(tone: string): boolean {
    if (!/^[0-9*#]$/.test(tone)) return false;
    const audioSender = this.peer?.getSenders().find((sender) => sender.track?.kind === "audio" && sender.dtmf);
    if (!audioSender?.dtmf) return false;
    audioSender.dtmf.insertDTMF(tone, 140, 70);
    return true;
  }

  async close(status?: "cancelled" | "rejected" | "timeout" | "ended" | "failed") {
    if (status) {
      try { await secureApi.calls.transition.mutate({ callId: this.callId, status }); } catch { /* state may already have changed remotely */ }
    }
    this.cleanup();
  }

  cleanup() {
    if (this.disconnectTimer) clearTimeout(this.disconnectTimer);
    this.unsubscribers.forEach((unsubscribe) => unsubscribe());
    this.unsubscribers = [];
    this.localStream?.getTracks().forEach((track) => track.stop());
    this.localStream = null;
    this.peer?.close();
    this.peer = null;
  }

  private async preparePeer() {
    if (!navigator.mediaDevices?.getUserMedia) {
      throw new Error("Microphone calling is not supported by this browser.");
    }
    this.localStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
    this.peer = new RTCPeerConnection({ iceServers: [{ urls: "stun:stun.l.google.com:19302" }] });
    this.localStream.getTracks().forEach((track) => this.peer!.addTrack(track, this.localStream!));
    this.peer.ontrack = (event) => {
      event.streams[0]?.getTracks().forEach((track) => this.remoteStream.addTrack(track));
      this.onRemoteStream(this.remoteStream);
    };
    this.peer.onicecandidate = (event) => {
      if (!event.candidate) return;
      const candidate = event.candidate.toJSON();
      void secureApi.calls.addIceCandidate.mutate({
        callId: this.callId,
        candidateId: crypto.randomUUID(),
        role: this.role,
        candidate: { candidate: candidate.candidate || "", sdpMid: candidate.sdpMid ?? null, sdpMLineIndex: candidate.sdpMLineIndex ?? null, usernameFragment: candidate.usernameFragment ?? null },
      });
    };
    this.peer.onconnectionstatechange = () => {
      const state = mediaStateFromPeerConnection(this.peer!.connectionState);
      if (!state) return;
      this.onState(state);
      if (state === "connected") {
        this.wasConnected = true;
        if (this.disconnectTimer) clearTimeout(this.disconnectTimer);
        void secureApi.calls.transition.mutate({ callId: this.callId, status: "connected" });
      } else if (state === "reconnecting") {
        void secureApi.calls.transition.mutate({ callId: this.callId, status: "reconnecting" });
        this.disconnectTimer = setTimeout(() => void this.close("failed"), 12_000);
      } else if (state === "failed") {
        void this.close("failed");
      }
    };
  }

  private listenForRemoteAnswerAndCandidates() {
    this.unsubscribers.push(onSnapshot(doc(db, "calls", this.callId), async (snapshot) => {
      const answer = snapshot.data()?.answer as RTCSessionDescriptionInit | undefined;
      if (answer?.type === "answer" && this.peer && !this.peer.currentRemoteDescription) {
        await this.peer.setRemoteDescription(answer);
        this.onState("connecting");
      }
    }));
    this.listenForRemoteCandidates();
  }

  private listenForRemoteCandidates() {
    const remoteRole: SignallingRole = this.role === "caller" ? "receiver" : "caller";
    this.unsubscribers.push(onSnapshot(query(collection(db, "calls", this.callId, "candidates"), where("role", "==", remoteRole)), (snapshot) => {
      snapshot.docChanges().forEach((change) => {
        if (change.type === "added" && this.peer) {
          const candidate = change.doc.data().candidate as RTCIceCandidateInit;
          void this.peer.addIceCandidate(candidate).catch(() => undefined);
        }
      });
    }));
  }
}
