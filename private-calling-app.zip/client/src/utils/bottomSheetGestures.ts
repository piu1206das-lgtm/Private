export const BOTTOM_SHEET_DISMISS_DISTANCE_PX = 96;
export const BOTTOM_SHEET_DISMISS_VELOCITY_PX_PER_SECOND = 700;

export function shouldDismissBottomSheet(offsetY: number, velocityY: number) {
  return offsetY > BOTTOM_SHEET_DISMISS_DISTANCE_PX || velocityY > BOTTOM_SHEET_DISMISS_VELOCITY_PX_PER_SECOND;
}
