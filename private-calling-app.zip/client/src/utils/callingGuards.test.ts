import { describe, expect, it } from "vitest";
import { isOwnedVirtualNumber } from "./callingGuards";

describe("self-call guard", () => {
  it("identifies any owned virtual number before a client starts a call", () => {
    const numbers = [{ number: "12345678" }, { number: "87654321" }];
    expect(isOwnedVirtualNumber("12345678", numbers)).toBe(true);
    expect(isOwnedVirtualNumber("87654321", numbers)).toBe(true);
    expect(isOwnedVirtualNumber("11112222", numbers)).toBe(false);
  });
});
