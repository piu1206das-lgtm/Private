export function isOwnedVirtualNumber(targetNumber: string, virtualNumbers: Array<{ number: string }> | undefined) {
  return (virtualNumbers || []).some((virtualNumber) => virtualNumber.number === targetNumber);
}
