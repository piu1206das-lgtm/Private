import { DeviceSession } from "../types";

export function mergeDeviceSession(sessions: DeviceSession[] | undefined, current: DeviceSession): DeviceSession[] {
  return [...(sessions || []).filter((session) => session.deviceId !== current.deviceId), current];
}
