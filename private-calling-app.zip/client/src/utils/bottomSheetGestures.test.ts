import { describe, expect, it } from "vitest";
import { BOTTOM_SHEET_DISMISS_DISTANCE_PX, BOTTOM_SHEET_DISMISS_VELOCITY_PX_PER_SECOND, shouldDismissBottomSheet } from "./bottomSheetGestures";

describe("bottom sheet drag dismissal", () => {
  it("dismisses after a substantial downward drag", () => {
    expect(shouldDismissBottomSheet(BOTTOM_SHEET_DISMISS_DISTANCE_PX + 1, 0)).toBe(true);
  });

  it("dismisses on a deliberate fast downward flick", () => {
    expect(shouldDismissBottomSheet(8, BOTTOM_SHEET_DISMISS_VELOCITY_PX_PER_SECOND + 1)).toBe(true);
  });

  it("snaps back after a small, slow downward movement", () => {
    expect(shouldDismissBottomSheet(BOTTOM_SHEET_DISMISS_DISTANCE_PX - 1, BOTTOM_SHEET_DISMISS_VELOCITY_PX_PER_SECOND - 1)).toBe(false);
  });
});
