import type { RecentCall } from "../components/DialerTab";
import type { SimulatedCallResult } from "../components/SimulatedCallScreen";

export function simulatedHistoryEntry(number: string, result: SimulatedCallResult): RecentCall {
  const time = result.durationSeconds > 0
    ? `${Math.floor(result.durationSeconds / 60)}:${(result.durationSeconds % 60).toString().padStart(2, "0")}`
    : "Now";
  return {
    id: `simulation-${result.endedAt}`,
    name: "Simulated call",
    number,
    time,
    type: result.direction === "incoming" ? "incoming" : "outgoing",
  };
}
