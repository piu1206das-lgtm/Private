import { describe, expect, it } from "vitest";
import { requiresContactCallingPin } from "./contactCallingPin";

describe("saved contact Calling PIN rule", () => {
  it("requires a PIN only for permanent 8-digit numbers", () => {
    expect(requiresContactCallingPin("12345678")).toBe(true);
    expect(requiresContactCallingPin("1234-5678")).toBe(true);
    expect(requiresContactCallingPin("1234567")).toBe(false);
    expect(requiresContactCallingPin("123-4567")).toBe(false);
  });
});
