// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from "vitest";
import { CALLING_PIN_REVEAL_DURATION_MS, scheduleCallingPinMask } from "./callingPinVisibility";

describe("Calling PIN visibility", () => {
  afterEach(() => vi.useRealTimers());

  it("automatically masks a revealed PIN after exactly five seconds", () => {
    vi.useFakeTimers();
    const onMask = vi.fn();
    scheduleCallingPinMask(onMask);
    vi.advanceTimersByTime(CALLING_PIN_REVEAL_DURATION_MS - 1);
    expect(onMask).not.toHaveBeenCalled();
    vi.advanceTimersByTime(1);
    expect(onMask).toHaveBeenCalledTimes(1);
  });
});
