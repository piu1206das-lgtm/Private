import { describe, expect, it } from "vitest";
import { mergeDeviceSession } from "./sessions";

describe("mergeDeviceSession", () => {
  it("refreshes only the current device and preserves active sessions on other devices", () => {
    const result = mergeDeviceSession([
      { sessionId: "desktop-old", deviceId: "desktop", deviceName: "Desktop", lastActive: 10 },
      { sessionId: "phone", deviceId: "phone", deviceName: "Phone", lastActive: 20 },
    ], { sessionId: "desktop-new", deviceId: "desktop", deviceName: "Desktop", lastActive: 30 });

    expect(result).toEqual([
      { sessionId: "phone", deviceId: "phone", deviceName: "Phone", lastActive: 20 },
      { sessionId: "desktop-new", deviceId: "desktop", deviceName: "Desktop", lastActive: 30 },
    ]);
  });
});
