export const hapticFeedback = {
  light: () => {
    if (typeof navigator !== 'undefined' && navigator.vibrate) navigator.vibrate(10);
  },
  medium: () => {
    if (typeof navigator !== 'undefined' && navigator.vibrate) navigator.vibrate(20);
  },
  heavy: () => {
    if (typeof navigator !== 'undefined' && navigator.vibrate) navigator.vibrate(40);
  },
  error: () => {
    if (typeof navigator !== 'undefined' && navigator.vibrate) navigator.vibrate([40, 40, 40]);
  },
  success: () => {
    if (typeof navigator !== 'undefined' && navigator.vibrate) navigator.vibrate([20, 50, 20]);
  }
};
