export type AnnounceableCallState =
  | "busy"
  | "failed"
  | "rejected"
  | "ended"
  | "missed"
  | "cancelled"
  | "timeout"
  | "reconnecting"
  | "disconnected";

export type CallAnnouncementInput = {
  callId?: string;
  state: AnnounceableCallState;
  initialMessage?: string;
};

type SpeechSynthesisLike = Pick<SpeechSynthesis, "speak" | "cancel">;

const UNAVAILABLE_NUMBER_MESSAGE = "The number you are trying to reach is unavailable.";
const EXPIRED_TEMPORARY_NUMBER_MESSAGE = "This number is no longer available because its validity has expired.";

export function callStatusAnnouncementText({ state, initialMessage }: CallAnnouncementInput): string | null {
  if (state === "busy") {
    return "Sorry, the person you are trying to reach is currently busy on another call and is unavailable to take your call.";
  }
  if (state === "rejected") return "The call was declined.";
  if (state === "missed") return "You missed this call.";
  if (state === "cancelled") return "The call was cancelled.";
  if (state === "timeout") return "The call was not answered.";
  if (state === "ended") return "Call ended.";
  if (state === "reconnecting" || state === "disconnected") return "Poor connection. Reconnecting your call.";
  if (state === "failed" && /validity has expired|number.*expired/i.test(initialMessage || "")) {
    return EXPIRED_TEMPORARY_NUMBER_MESSAGE;
  }
  if (state === "failed" && /virtual number is unavailable|number.*unavailable/i.test(initialMessage || "")) {
    return UNAVAILABLE_NUMBER_MESSAGE;
  }
  if (state === "failed") return "The call could not be connected. Please try again.";
  return null;
}

function getBrowserSpeechSynthesis(): SpeechSynthesisLike | null {
  if (typeof window === "undefined" || !window.speechSynthesis) return null;
  return window.speechSynthesis;
}

/**
 * Keeps spoken event keys for the lifetime of a CallScreen, so repeated
 * Firestore snapshots or media callbacks cannot replay the same announcement.
 */
export function createCallStatusAnnouncer(speech: SpeechSynthesisLike | null = getBrowserSpeechSynthesis()) {
  const spokenEventKeys = new Set<string>();

  return {
    announce(input: CallAnnouncementInput): boolean {
      const text = callStatusAnnouncementText(input);
      if (!text || !speech || typeof SpeechSynthesisUtterance === "undefined") return false;

      const eventKey = `${input.callId || "local-call"}:${input.state}:${text}`;
      if (spokenEventKeys.has(eventKey)) return false;

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = "en-IN";
      utterance.rate = 0.94;
      utterance.pitch = 1;
      // The Web Speech API queues requests. Clearing the old queue first ensures
      // an outdated reconnecting prompt cannot play after a terminal outcome.
      speech.cancel();
      speech.speak(utterance);
      spokenEventKeys.add(eventKey);
      return true;
    },
    cancel() {
      speech?.cancel();
    },
  };
}
