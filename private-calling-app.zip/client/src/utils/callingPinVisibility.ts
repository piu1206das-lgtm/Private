export const CALLING_PIN_REVEAL_DURATION_MS = 5_000;

export function scheduleCallingPinMask(onMask: () => void): number {
  return window.setTimeout(onMask, CALLING_PIN_REVEAL_DURATION_MS);
}
