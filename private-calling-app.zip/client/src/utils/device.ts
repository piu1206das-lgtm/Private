const DEVICE_ID_KEY = "device_id";

export function getOrCreateDeviceId(): string {
  const existing = localStorage.getItem(DEVICE_ID_KEY);
  if (existing) return existing;

  const deviceId = crypto.randomUUID();
  localStorage.setItem(DEVICE_ID_KEY, deviceId);
  return deviceId;
}

export function getDeviceName(): string {
  const userAgent = navigator.userAgent;
  if (/android/i.test(userAgent)) return "Android Device";
  if (/iPad|iPhone|iPod/.test(userAgent)) return "iOS Device";
  if (/Windows/.test(userAgent)) return "Windows PC";
  if (/Mac/.test(userAgent)) return "Mac";
  return "Web Browser";
}

export function clearLegacyPinCache(): void {
  localStorage.removeItem("cached_pin");
}

export function getCallCooldownKey(number: string): string {
  return `call_cooldown_${number}`;
}

export const CALL_COOLDOWN_MS = 15 * 60 * 1000;
