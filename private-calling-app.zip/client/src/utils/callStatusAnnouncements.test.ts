import { beforeEach, describe, expect, it, vi } from "vitest";
import { callStatusAnnouncementText, createCallStatusAnnouncer } from "./callStatusAnnouncements";

class TestUtterance {
  lang = "";
  rate = 0;
  pitch = 0;
  constructor(public text: string) {}
}

describe("call status announcements", () => {
  beforeEach(() => {
    vi.stubGlobal("SpeechSynthesisUtterance", TestUtterance);
  });

  it("maps each requested live and terminal state to clear professional English", () => {
    expect(callStatusAnnouncementText({ state: "busy" })).toBe("Sorry, the person you are trying to reach is currently busy on another call and is unavailable to take your call.");
    expect(callStatusAnnouncementText({ state: "rejected" })).toBe("The call was declined.");
    expect(callStatusAnnouncementText({ state: "missed" })).toBe("You missed this call.");
    expect(callStatusAnnouncementText({ state: "reconnecting" })).toBe("Poor connection. Reconnecting your call.");
    expect(callStatusAnnouncementText({ state: "ended" })).toBe("Call ended.");
    expect(callStatusAnnouncementText({ state: "failed", initialMessage: "This virtual number is unavailable." })).toBe("The number you are trying to reach is unavailable.");
    expect(callStatusAnnouncementText({ state: "failed", initialMessage: "This number is no longer available because its validity has expired." })).toBe("This number is no longer available because its validity has expired.");
  });

  it("speaks a state event once per call while allowing distinct later state events", () => {
    const speak = vi.fn();
    const cancel = vi.fn();
    const announcer = createCallStatusAnnouncer({ speak, cancel });

    expect(announcer.announce({ callId: "call-1", state: "busy" })).toBe(true);
    expect(announcer.announce({ callId: "call-1", state: "busy" })).toBe(false);
    expect(announcer.announce({ callId: "call-1", state: "reconnecting" })).toBe(true);
    expect(announcer.announce({ callId: "call-2", state: "busy" })).toBe(true);
    expect(speak).toHaveBeenCalledTimes(3);
    expect(cancel).toHaveBeenCalledTimes(3);

    const firstUtterance = speak.mock.calls[0]?.[0] as TestUtterance;
    expect(firstUtterance).toMatchObject({ lang: "en-IN", rate: 0.94, pitch: 1 });

    announcer.cancel();
    expect(cancel).toHaveBeenCalledTimes(4);
  });
});
