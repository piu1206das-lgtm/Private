/**
 * Interaction reminder — retain the existing Android-native movement language:
 * direct, restrained spring feedback for call controls and app-level sheets.
 */
import { Transition, Variants } from "motion/react";

const navigationSpring: Transition = { type: "spring", stiffness: 400, damping: 30 };
const sheetSpring: Transition = { type: "spring", stiffness: 300, damping: 30 };
const tapSpring: Transition = { type: "spring", stiffness: 500, damping: 25 };

export const spring: Transition = navigationSpring;

export const pageTransition: Variants = {
  initial: { opacity: 0, x: 20 },
  animate: { opacity: 1, x: 0, transition: { duration: 0.25, ease: "easeOut" } },
  exit: { opacity: 0, x: -20, transition: { duration: 0.2, ease: "easeIn" } },
};

export const bottomSheetTransition: Variants = {
  initial: { opacity: 0, y: "100%" },
  animate: { opacity: 1, y: 0, transition: sheetSpring },
  exit: { opacity: 0, y: "100%", transition: sheetSpring },
};

export const dialogTransition: Variants = {
  initial: { opacity: 0, scale: 0.95, y: 10 },
  animate: { opacity: 1, scale: 1, y: 0, transition: navigationSpring },
  exit: { opacity: 0, scale: 0.95, y: 10, transition: { duration: 0.15, ease: "easeIn" } },
};

export const listStagger: Variants = {
  animate: { transition: { staggerChildren: 0.05 } },
};

export const listItemFade: Variants = {
  initial: { opacity: 0, y: 10 },
  animate: { opacity: 1, y: 0 },
};

export const tapScale = { scale: 0.95, transition: tapSpring };
