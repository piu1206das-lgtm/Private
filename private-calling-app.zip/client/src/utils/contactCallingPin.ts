export function requiresContactCallingPin(number: string): boolean {
  return number.replace(/\D/g, "").length === 8;
}
