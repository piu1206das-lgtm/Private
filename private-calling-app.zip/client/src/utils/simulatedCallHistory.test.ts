import { describe, expect, it } from "vitest";
import { simulatedHistoryEntry } from "./simulatedCallHistory";

describe("simulatedHistoryEntry", () => {
  it("creates an existing Dialer history entry when an outgoing simulation ends", () => {
    expect(simulatedHistoryEntry("12345678", { durationSeconds: 65, direction: "outgoing", endedAt: 123 })).toEqual({
      id: "simulation-123", name: "Simulated call", number: "12345678", time: "1:05", type: "outgoing",
    });
  });

  it("records an incoming simulation with its existing Dialer-compatible type", () => {
    expect(simulatedHistoryEntry("1234567", { durationSeconds: 0, direction: "incoming", endedAt: 124 })).toMatchObject({
      number: "1234567", time: "Now", type: "incoming",
    });
  });
});
