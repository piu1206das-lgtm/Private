export async function detectVPN(): Promise<boolean> {
  try {
    const res = await fetch('https://ipapi.co/json/');
    const data = await res.json();
    const org = (data.org || '').toLowerCase();
    // Basic heuristic for typical VPN/Datacenter endpoints
    const isVpn = org.includes('vpn') || 
                  org.includes('proxy') || 
                  org.includes('datacenter') || 
                  org.includes('hosting') ||
                  org.includes('cloud');
    return isVpn;
  } catch (error) {
    console.error('VPN check failed', error);
    // If the API fails, we shouldn't block the user outright, just assume false.
    return false;
  }
}
