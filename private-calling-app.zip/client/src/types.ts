import { User as FirebaseUser } from "firebase/auth";

export interface AudioSettings {
  speaker: string;
  mic: string;
  quality: "Auto" | "HD";
  noiseCancellation: boolean;
}

export interface VirtualNumber {
  number: string;
  type: "primary" | "secondary" | "tertiary" | "quaternary" | "quinary" | "vip";
  status: "active" | "inactive";
  createdAt: number;
}

export interface DeviceSession {
  sessionId: string;
  deviceId: string;
  deviceName: string;
  lastActive: number;
}

export interface HelloTune {
  id?: string; url: string;
  storagePath: string;
  name?: string;
  clipStartSeconds?: number;
  clipEndSeconds?: number;
  clipDurationSeconds?: number;
}

export interface UserProfile {
  dndEnabled?: boolean;
  notificationSettings?: { ringtone: boolean; vibrate: boolean; sound: boolean };
  blockedUsersList?: { uidHash: string; deviceHash: string; number: string; label?: string; date: number }[];
  bio?: string;
  uid: string;
  displayName: string;
  email: string;
  photoURL: string;
  pinHash: string;
  pinVersion?: number;
  pinChangedAt?: number;
  virtualNumbers: VirtualNumber[];
  createdAt: number;
  isOnboarded: boolean;
  isOnline?: boolean;
  isVIP?: boolean;
  temporaryActivations?: number;
  vipSelections?: number;
  blockedDeviceIds?: string[];
  blockedHashes?: string[];
  sessions?: DeviceSession[];
  lastNumberChangeDate?: number;
  helloTune?: HelloTune;
  activeHelloTunePass?: { planId: string; purchasedAt: number; expiresAt: number; };
  audioSettings?: AudioSettings;
  activePass?: {
    planId: '1hr-pass' | '1hr-shield' | '24hr-temp' | '7d-temp' | 'vip-pass' | '50d-freedom' | '100d-dual' | '200d-privacy' | '376d-freedom';
    purchasedAt: number;
    expiresAt: number;
    temporaryNumber?: string;
  };
  activeTemporaryNumber?: {
    number: string;
    status: "active";
    numberType: "temporary";
    entitlementId: string;
    planId: string;
    activatedAt: number;
    expiresAt: number;
  } | null;
}

export interface AppUser {
  authUser: FirebaseUser;
  profile: UserProfile | null;
}

export interface CallSession {
  id?: string;
  callerUid: string;
  receiverUid: string;
  callerNumber: string;
  receiverNumber: string;
  status: 'calling' | 'ringing' | 'connecting' | 'connected' | 'reconnecting' | 'failed' | 'rejected' | 'ended' | 'missed' | 'timeout' | 'cancelled';
  createdAt: number;
  updatedAt: number;
}
