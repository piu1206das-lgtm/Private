import React, { useState, useRef, useEffect } from "react";
import { UserProfile } from "../types";
import { Music, Play, Pause, Trash2, ArrowLeft, Upload } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { pageTransition, tapScale } from "../utils/animations";
import { hapticFeedback } from "../utils/haptics";
import { auth } from "../firebase";
import { MAX_HELLOTUNE_CLIP_SECONDS, createHelloTuneClip, normalizeHelloTuneSelection, selectionForEnd, selectionForStart, type HelloTuneSelection } from "../services/helloTuneClip";
import { secureApi } from "../services/secureApi";

interface HelloTuneTabProps {
  profile: UserProfile;
  onClose: () => void;
}

type ClipUploadResult = { storagePath?: string; url?: string; clipDurationSeconds?: number; name?: string; message?: string };

function uploadSelectedHelloTuneClip(blob: Blob, token: string, sourceName: string, onProgress: (progress: number) => void, pendingSelection = false) {
  return new Promise<ClipUploadResult>((resolve, reject) => {
    const request = new XMLHttpRequest();
    request.open("POST", "/api/hellotune/clip");
    request.setRequestHeader("authorization", `Bearer ${token}`);
    request.setRequestHeader("content-type", "audio/wav");
    request.setRequestHeader("x-hellotune-source-name", encodeURIComponent(sourceName));
    if (pendingSelection) request.setRequestHeader("x-hellotune-upload-mode", "pending-selection");
    request.upload.onprogress = (event) => {
      if (event.lengthComputable) onProgress(70 + Math.round((event.loaded / event.total) * 22));
    };
    request.onerror = () => reject(new Error("Uploading the selected clip failed."));
    request.onload = () => {
      let result: ClipUploadResult = {};
      try { result = JSON.parse(request.responseText) as ClipUploadResult; } catch { /* handled below */ }
      if (request.status < 200 || request.status >= 300) reject(new Error(result.message || "Uploading the selected clip failed."));
      else resolve(result);
    };
    request.send(blob);
  });
}

export default function HelloTuneTab({ profile, onClose }: HelloTuneTabProps) {
  const [showTrimmer, setShowTrimmer] = useState(false);
  
  const now = Date.now();
  const hasActivePass = profile.activeHelloTunePass && profile.activeHelloTunePass.expiresAt > now;
  
  const activeHelloTune = profile.helloTune;

  const handleDelete = async () => {
    if (!confirm("Delete HelloTune?\n\nThis will remove your current HelloTune audio.")) return;
    hapticFeedback.light();
    try {
      await secureApi.helloTune.remove.mutate();
      hapticFeedback.success();
    } catch (e) {
      console.error(e);
      alert("Failed to delete HelloTune");
    }
  };

  const renderActiveState = () => (
    <div className="p-6">
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 text-center mb-6">
        <div className="w-16 h-16 bg-amber-100 text-amber-500 rounded-full flex items-center justify-center mx-auto mb-4">
          <Music className="w-8 h-8" />
        </div>
        {activeHelloTune ? (
          <>
            <h3 className="text-sm font-medium text-amber-600 uppercase tracking-widest mb-1">HelloTune Active</h3>
            <p className="text-xl font-bold text-slate-900 mb-1 line-clamp-1">{activeHelloTune.name || "Custom Audio"}</p>
            <p className="text-sm text-slate-500 mb-6">Valid until: {new Date(profile.activeHelloTunePass!.expiresAt).toLocaleDateString()}</p>
            
            <div className="flex gap-3 justify-center">
              <button 
                onClick={() => {
                   const audio = new Audio(activeHelloTune.url);
                   audio.play();
                   setTimeout(() => audio.pause(), 5000);
                }} 
                className="px-4 py-2 bg-slate-100 text-slate-700 rounded-lg font-medium active:bg-slate-200"
              >
                Preview
              </button>
              <button onClick={() => setShowTrimmer(true)} className="px-4 py-2 bg-amber-500 text-white rounded-lg font-medium active:bg-amber-600 shadow-sm">
                Change
              </button>
              <button onClick={handleDelete} className="px-4 py-2 bg-red-50 text-red-600 rounded-lg font-medium active:bg-red-100">
                Delete
              </button>
            </div>
          </>
        ) : (
          <>
            <h3 className="text-lg font-bold text-slate-900 mb-1">No HelloTune set</h3>
            <p className="text-sm text-slate-500 mb-6">Choose a sound from your device and set the part you want callers to hear.</p>
            <button onClick={() => setShowTrimmer(true)} className="w-full h-12 bg-amber-500 text-white rounded-xl font-semibold active:bg-amber-600 shadow-sm">
              Set HelloTune
            </button>
          </>
        )}
      </div>
      
      {!activeHelloTune && profile.activeHelloTunePass && (
        <p className="text-center text-sm text-slate-500">
          Pack valid until: {new Date(profile.activeHelloTunePass.expiresAt).toLocaleDateString()}
        </p>
      )}
    </div>
  );

  return (
    <div className="flex-1 flex flex-col bg-slate-50 h-full relative overflow-hidden">
      <div className="flex items-center px-4 h-14 bg-white border-b border-slate-100 shrink-0">
        <button onClick={onClose} className="min-w-12 min-h-12 -ml-2 flex items-center justify-center rounded-full active:bg-slate-100 text-slate-700 ripple" aria-label="Back to Recharge"><ArrowLeft className="w-6 h-6" /></button>
        <h1 className="ml-1 text-[18px] font-medium text-slate-900 tracking-tight">HelloTune</h1>
      </div>

      <div className="flex-1 overflow-y-auto">
        <div className="px-6 py-8 text-center">
          <h2 className="text-xl font-bold text-slate-800 mb-2">Set your own sound</h2>
          <p className="text-slate-500 text-sm">Set your own sound for incoming calls.</p>
        </div>

        {hasActivePass ? renderActiveState() : <div className="p-6"><div className="rounded-2xl border border-slate-100 bg-white p-6 text-center shadow-sm"><div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-amber-100 text-amber-500"><Music className="h-8 w-8" /></div><h3 className="text-lg font-bold text-slate-900">No active HelloTune pack</h3><p className="mt-2 text-sm leading-5 text-slate-500">Select a pack and audio in Recharge before secure payment. Your audio becomes active only after payment verification.</p><button onClick={onClose} className="mt-5 h-12 w-full rounded-xl bg-amber-500 font-semibold text-white active:bg-amber-600">Return to Recharge</button></div></div>}
      </div>

      <AnimatePresence>
        {showTrimmer && (
          <AudioTrimmer profile={profile} onClose={() => setShowTrimmer(false)} />
        )}
      </AnimatePresence>
    </div>
  );
}

// Internal AudioTrimmer component. The original file never leaves this device;
// only a newly encoded selected clip is uploaded and persisted.
export function AudioTrimmer({ profile, onClose, onPrepared }: { profile: UserProfile, onClose: () => void, onPrepared?: (clip: { name: string; url: string; storagePath: string; clipStartSeconds: number; clipEndSeconds: number; clipDurationSeconds: number }) => Promise<void> | void }) {
  const [file, setFile] = useState<File | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [duration, setDuration] = useState(0);
  const [selection, setSelection] = useState<HelloTuneSelection>({ start: 0, end: 0 });
  const [waveform, setWaveform] = useState<number[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [processingError, setProcessingError] = useState("");
  const audioRef = useRef<HTMLAudioElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const timelineRef = useRef<HTMLDivElement>(null);
  const selectedDuration = Math.max(0, selection.end - selection.start);

  useEffect(() => () => { if (audioUrl) URL.revokeObjectURL(audioUrl); }, [audioUrl]);

  const pausePreview = () => {
    if (audioRef.current) audioRef.current.pause();
    setIsPlaying(false);
  };

  const buildWaveform = async (source: File) => {
    const AudioContextClass = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;
    const context = new AudioContextClass();
    try {
      const buffer = await context.decodeAudioData(await source.arrayBuffer());
      const channel = buffer.getChannelData(0);
      const bars = 56;
      const step = Math.max(1, Math.floor(channel.length / bars));
      setWaveform(Array.from({ length: bars }, (_, index) => {
        let peak = 0;
        for (let offset = index * step; offset < Math.min(channel.length, (index + 1) * step); offset += 1) peak = Math.max(peak, Math.abs(channel[offset] || 0));
        return Math.max(0.1, peak);
      }));
    } catch {
      setWaveform([]);
    } finally {
      await context.close().catch(() => undefined);
    }
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (!selectedFile) return;
    if (!selectedFile.type.startsWith("audio/")) {
      setProcessingError("Choose a valid audio file from your device.");
      return;
    }
    pausePreview();
    setFile(selectedFile);
    setProcessingError("");
    setProgress(0);
    const url = URL.createObjectURL(selectedFile);
    setAudioUrl(url);
    const metadata = new Audio(url);
    metadata.onloadedmetadata = () => {
      const nextDuration = Number.isFinite(metadata.duration) ? metadata.duration : 0;
      setDuration(nextDuration);
      setSelection(normalizeHelloTuneSelection({ start: 0, end: Math.min(MAX_HELLOTUNE_CLIP_SECONDS, nextDuration) }, nextDuration));
    };
    metadata.onerror = () => setProcessingError("This audio file could not be read. Try another file.");
    void buildWaveform(selectedFile);
  };

  const updateStart = (value: number) => {
    pausePreview();
    setSelection((current) => selectionForStart(value, current, duration));
  };

  const updateEnd = (value: number) => {
    pausePreview();
    setSelection((current) => selectionForEnd(value, current, duration));
  };

  const updateSelectionFromPointer = (handle: "start" | "end", clientX: number) => {
    const timeline = timelineRef.current;
    if (!timeline || !duration) return;
    const bounds = timeline.getBoundingClientRect();
    const percentage = Math.max(0, Math.min(1, (clientX - bounds.left) / Math.max(1, bounds.width)));
    const time = percentage * duration;
    if (handle === "start") updateStart(time);
    else updateEnd(time);
  };

  const adjustSelectionWithKey = (handle: "start" | "end", key: string) => {
    const delta = key === "ArrowLeft" ? -0.5 : key === "ArrowRight" ? 0.5 : 0;
    if (!delta) return;
    if (handle === "start") updateStart(selection.start + delta);
    else updateEnd(selection.end + delta);
  };

  const togglePlay = async () => {
    const audio = audioRef.current;
    if (!audio || !selectedDuration) return;
    if (isPlaying) {
      pausePreview();
      return;
    }
    audio.currentTime = selection.start;
    try {
      await audio.play();
      setIsPlaying(true);
    } catch {
      setProcessingError("Selected clip preview could not start. Check your device audio permission and try again.");
    }
  };

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    const stopAtSelectionEnd = () => {
      if (audio.currentTime >= selection.end || audio.ended) {
        audio.pause();
        audio.currentTime = selection.start;
        setIsPlaying(false);
      }
    };
    audio.addEventListener("timeupdate", stopAtSelectionEnd);
    audio.addEventListener("ended", stopAtSelectionEnd);
    return () => {
      audio.removeEventListener("timeupdate", stopAtSelectionEnd);
      audio.removeEventListener("ended", stopAtSelectionEnd);
    };
  }, [selection.start, selection.end]);

  const handleConfirm = async () => {
    if (!file || !audioUrl || isProcessing || selectedDuration < 0.1) return;
    hapticFeedback.light();
    pausePreview();
    setIsProcessing(true);
    setProcessingError("");
    setProgress(2);
    try {
      const processed = await createHelloTuneClip(file, selection, setProgress);
      setProgress(70);
      const token = await auth.currentUser?.getIdToken();
      if (!token) throw new Error("Sign in is required to activate a HelloTune.");
      const uploadResult = await uploadSelectedHelloTuneClip(processed.blob, token, file.name, setProgress, Boolean(onPrepared));
      if (!uploadResult.storagePath || !uploadResult.url || !uploadResult.clipDurationSeconds) throw new Error(uploadResult.message || "Uploading the selected clip failed.");
      setProgress(92);
      setProgress(96);
      const preparedClip = {
          name: uploadResult.name || file.name,
          url: uploadResult.url,
          storagePath: uploadResult.storagePath,
          clipStartSeconds: processed.selection.start,
          clipEndSeconds: processed.selection.end,
          clipDurationSeconds: Number(uploadResult.clipDurationSeconds.toFixed(3)),
      };
      if (onPrepared) await onPrepared(preparedClip);
      else await secureApi.helloTune.activate.mutate(preparedClip);
      setProgress(100);
      hapticFeedback.success();
      onClose();
    } catch (error) {
      console.error("HelloTune clip processing failed", error);
      setProcessingError(error instanceof Error ? error.message : "Processing the selected clip failed. Please retry.");
      hapticFeedback.error();
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <motion.div initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }} transition={{ type: "spring", damping: 25, stiffness: 200 }} className="absolute inset-0 bg-slate-50 z-[60] flex flex-col text-slate-900">
      <div className="flex items-center px-4 h-14 bg-white border-b border-slate-100 shrink-0">
        <button onClick={onClose} disabled={isProcessing} className="min-w-12 min-h-12 -ml-2 flex items-center justify-center rounded-full active:bg-slate-100 text-slate-700 disabled:opacity-50" aria-label="Back to HelloTune"><ArrowLeft className="w-6 h-6" /></button>
        <h1 className="ml-2 text-[18px] font-medium">Preview & Select</h1>
      </div>
      <div className="flex-1 overflow-y-auto p-6 flex flex-col items-center justify-center">
        {!audioUrl ? (
          <div className="text-center w-full max-w-sm"><div className="w-20 h-20 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-6 text-amber-600"><Upload className="w-10 h-10" /></div><h2 className="text-xl font-bold mb-2">Select Audio</h2><p className="text-slate-500 text-sm mb-8">Choose audio from your device, then select up to 40 seconds for callers to hear.</p><input type="file" accept="audio/*" ref={fileInputRef} className="hidden" onChange={handleFileChange} /><button onClick={() => fileInputRef.current?.click()} className="w-full h-14 bg-amber-500 text-white rounded-xl font-bold active:bg-amber-600">Browse Device</button>{processingError && <p className="mt-4 text-sm text-red-600" role="alert">{processingError}</p>}</div>
        ) : (
          <div className="w-full max-w-sm flex flex-col"><h2 className="text-xl font-bold mb-1 text-center truncate">{file?.name}</h2><p className="text-slate-500 text-sm text-center mb-5">Selected: {selectedDuration.toFixed(1)}s / Max 40s</p><audio ref={audioRef} src={audioUrl} preload="metadata" />
            <div className="bg-white border border-slate-100 p-5 rounded-2xl mb-5 flex flex-col items-center shadow-sm"><button onClick={() => void togglePlay()} disabled={isProcessing || !selectedDuration} aria-label={isPlaying ? "Pause selected clip" : "Play selected clip"} className="w-16 h-16 bg-amber-500 rounded-full flex items-center justify-center text-white active:scale-95 transition-transform mb-5 disabled:opacity-50">{isPlaying ? <Pause className="w-8 h-8" /> : <Play className="w-8 h-8 ml-1" />}</button>
              <div className="w-full"><div className="flex justify-between text-xs text-slate-500 mb-2"><span>0:00</span><span>{Math.floor(duration / 60)}:{(Math.floor(duration) % 60).toString().padStart(2, "0")}</span></div><div ref={timelineRef} className="relative h-20 rounded-xl bg-slate-100 overflow-hidden touch-none" aria-label="Audio timeline"><div className="absolute inset-x-2 inset-y-3 flex items-center gap-px pointer-events-none">{waveform.length > 0 ? waveform.map((height, index) => <span key={index} className="flex-1 bg-slate-300 rounded-full" style={{ height: `${Math.max(14, height * 100)}%` }} />) : <span className="w-full text-center text-xs text-slate-400">Loading waveform…</span>}</div><div className="absolute top-0 bottom-0 bg-amber-300/35 border-x-2 border-amber-500 pointer-events-none" style={{ left: `${duration ? (selection.start / duration) * 100 : 0}%`, width: `${duration ? (selectedDuration / duration) * 100 : 0}%` }} /><button type="button" role="slider" aria-label="Selection start" aria-valuemin={0} aria-valuemax={selection.end} aria-valuenow={selection.start} disabled={isProcessing || !duration} onPointerDown={(event) => { event.currentTarget.setPointerCapture(event.pointerId); updateSelectionFromPointer("start", event.clientX); }} onPointerMove={(event) => { if (event.currentTarget.hasPointerCapture(event.pointerId)) updateSelectionFromPointer("start", event.clientX); }} onPointerUp={(event) => event.currentTarget.releasePointerCapture(event.pointerId)} onKeyDown={(event) => adjustSelectionWithKey("start", event.key)} className="absolute top-1/2 z-10 -translate-x-1/2 -translate-y-1/2 w-7 h-12 rounded-full bg-amber-500 border-2 border-white shadow-md touch-none disabled:opacity-50" style={{ left: `${duration ? (selection.start / duration) * 100 : 0}%` }}><span className="mx-auto block h-5 w-0.5 rounded-full bg-white/80" /></button><button type="button" role="slider" aria-label="Selection end" aria-valuemin={selection.start} aria-valuemax={duration} aria-valuenow={selection.end} disabled={isProcessing || !duration} onPointerDown={(event) => { event.currentTarget.setPointerCapture(event.pointerId); updateSelectionFromPointer("end", event.clientX); }} onPointerMove={(event) => { if (event.currentTarget.hasPointerCapture(event.pointerId)) updateSelectionFromPointer("end", event.clientX); }} onPointerUp={(event) => event.currentTarget.releasePointerCapture(event.pointerId)} onKeyDown={(event) => adjustSelectionWithKey("end", event.key)} className="absolute top-1/2 z-10 -translate-x-1/2 -translate-y-1/2 w-7 h-12 rounded-full bg-amber-500 border-2 border-white shadow-md touch-none disabled:opacity-50" style={{ left: `${duration ? (selection.end / duration) * 100 : 0}%` }}><span className="mx-auto block h-5 w-0.5 rounded-full bg-white/80" /></button></div><div className="mt-3 flex justify-between text-[11px] font-medium text-slate-500"><span>Start {selection.start.toFixed(1)}s</span><span>End {selection.end.toFixed(1)}s</span></div><p className="text-center text-xs text-slate-500 mt-3">Drag either yellow handle to choose the part callers hear.</p></div>
            </div>
            {isProcessing && <div className="mb-4"><div className="flex justify-between text-xs font-semibold text-slate-600 mb-2"><span>Processing selected clip…</span><span>{progress}%</span></div><div className="h-2 bg-slate-200 rounded-full overflow-hidden"><motion.div className="h-full bg-amber-500" animate={{ width: `${progress}%` }} transition={{ duration: 0.2 }} /></div></div>}
            {processingError && <div className="mb-4 rounded-xl bg-red-50 border border-red-100 p-3 text-sm text-red-700" role="alert"><p>{processingError}</p><button onClick={() => void handleConfirm()} disabled={isProcessing} className="mt-2 font-semibold underline disabled:opacity-50">Retry</button></div>}
            <button onClick={() => void handleConfirm()} disabled={isProcessing || selectedDuration < 0.1} className="w-full h-14 bg-amber-500 text-white rounded-xl font-bold active:bg-amber-600 disabled:opacity-70 flex items-center justify-center">{isProcessing ? "Processing…" : "Confirm & Activate"}</button>
          </div>
        )}
      </div>
    </motion.div>
  );
}
