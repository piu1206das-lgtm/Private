// @vitest-environment jsdom
import React from "react";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import PlanSelection from "./PlanSelection";
import { secureApi } from "../services/secureApi";

const catalog = [{ planId: "50d-freedom", planName: "50-Day Freedom", price: 17, validityValue: 50, validityUnit: "days", validity: "50 Days", benefits: ["1 Permanent 8-Digit Virtual Number", "Unlimited app-to-app voice calling"], categories: ["Recommended", "Long Validity"], label: "Best Value", kind: "permanent", numberEntitlement: 1, temporaryNumberEntitlement: 0 }];

vi.mock("../services/secureApi", () => ({
  secureApi: {
    recharge: { catalog: { query: vi.fn() }, status: { query: vi.fn() }, purchaseHistory: { query: vi.fn() }, createCheckout: { mutate: vi.fn() }, validateFriendTarget: { query: vi.fn() }, createFriendCheckout: { mutate: vi.fn() } },
    helloTune: { packs: { query: vi.fn() }, createCheckout: { mutate: vi.fn() } },
  },
}));
vi.mock("./VipNumberSearch", () => ({ default: () => null }));
vi.mock("./HelloTuneTab", () => ({ AudioTrimmer: () => null }));
vi.mock("../utils/haptics", () => ({ hapticFeedback: { light: vi.fn(), medium: vi.fn(), success: vi.fn(), error: vi.fn() } }));

afterEach(cleanup);

beforeEach(() => {
  vi.clearAllMocks();
  Object.defineProperty(HTMLElement.prototype, "scrollTo", { value: vi.fn(), configurable: true });
  vi.mocked(secureApi.recharge.catalog.query).mockResolvedValue(catalog as never);
  vi.mocked(secureApi.recharge.status.query).mockResolvedValue({ serverTime: Date.now(), currentPlan: null, upcomingPlans: [], activeTemporaryEntitlements: [] } as never);
  vi.mocked(secureApi.recharge.purchaseHistory.query).mockResolvedValue([] as never);
  vi.mocked(secureApi.helloTune.packs.query).mockResolvedValue([{ id: "mini", name: "Mini", price: 3, validity: "7 Days" }, { id: "plus", name: "Plus", price: 5, validity: "30 Days" }, { id: "long", name: "Long", price: 9, validity: "100 Days" }, { id: "year", name: "Year", price: 15, validity: "376 Days" }] as never);
});

describe("Recharge plan presentation consistency", () => {
  it("carries the selected plan’s server catalog price, validity, and benefits from card to details and confirmation", async () => {
    render(<PlanSelection profile={{ uid: "owner", virtualNumbers: [{ number: "12345678", type: "primary", status: "active" }] } as any} onClose={vi.fn()} onOpenHelloTune={vi.fn()} />);
    fireEvent.click(await screen.findByRole("button", { name: /50-Day Freedom/ }));
    expect(screen.getByText("Plan Details")).toBeTruthy();
    expect(screen.getAllByText("₹17").length).toBeGreaterThan(0);
    expect(screen.getAllByText("50 Days").length).toBeGreaterThan(0);
    expect(screen.getByText("1 Permanent 8-Digit Virtual Number")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "Select this plan" }));
    expect(screen.getByText("Confirm Recharge")).toBeTruthy();
    expect(screen.getAllByText("50-Day Freedom").length).toBeGreaterThan(0);
    expect(screen.getAllByText("₹17").length).toBeGreaterThan(1);
    expect(screen.getAllByText("50 Days").length).toBeGreaterThan(1);
  });

  it("renders the four HelloTune packs directly from the server catalog", async () => {
    render(<PlanSelection profile={{ uid: "owner", virtualNumbers: [] } as any} onClose={vi.fn()} onOpenHelloTune={vi.fn()} />);
    fireEvent.click(await screen.findByRole("button", { name: "HelloTune" }));
    expect(screen.getByText("₹3")).toBeTruthy();
    expect(screen.getByText("₹5")).toBeTruthy();
    expect(screen.getByText("₹9")).toBeTruthy();
    expect(screen.getByText("₹15")).toBeTruthy();
    expect(screen.getByText("376 Days")).toBeTruthy();
  });

  it("removes the standalone HelloTune service shortcut while retaining the dedicated category tab", async () => {
    render(<PlanSelection profile={{ uid: "owner", virtualNumbers: [] } as any} onClose={vi.fn()} onOpenHelloTune={vi.fn()} />);
    await screen.findByRole("button", { name: /50-Day Freedom/ });
    expect(screen.queryByText("Set your own caller audio")).toBeNull();
    expect(screen.getAllByRole("button", { name: "HelloTune" })).toHaveLength(1);
  });

  it("shows only the server-provided latest successful recharge while retaining the no-recharge state when absent", async () => {
    vi.mocked(secureApi.recharge.status.query).mockResolvedValue({ serverTime: Date.now(), currentPlan: null, upcomingPlans: [], activeTemporaryEntitlements: [], latestSuccessfulRecharge: { purchaseId: "purchase-latest", planId: "50d-freedom", planName: "50-Day Freedom", price: 17, validity: "50 Days", fulfilledAt: Date.UTC(2026, 7, 27) } } as never);
    render(<PlanSelection profile={{ uid: "owner", virtualNumbers: [] } as any} onClose={vi.fn()} onOpenHelloTune={vi.fn()} />);
    expect(await screen.findByText("Last Recharge: 50-Day Freedom")).toBeTruthy();
    expect(screen.getByText(/₹17 • 50 Days/)).toBeTruthy();
    expect(screen.queryByText("No active plan")).toBeNull();
  });

  it("visually distinguishes the permanent virtual number from the one server-active temporary number", async () => {
    vi.mocked(secureApi.recharge.status.query).mockResolvedValue({ serverTime: Date.now(), currentPlan: null, upcomingPlans: [], latestSuccessfulRecharge: null, activeTemporaryEntitlements: [{ entitlementId: "temporary-active", planId: "7d-temp", planName: "7-Day Temporary Number", price: 25, validity: "7 Days", benefits: [], status: "active", entitlementStart: 1, entitlementExpiry: Date.UTC(2026, 7, 28), temporaryNumber: "7000001" }] } as never);
    render(<PlanSelection profile={{ uid: "owner", virtualNumbers: [{ number: "12345678", type: "primary", status: "active" }] } as any} onClose={vi.fn()} onOpenHelloTune={vi.fn()} />);
    expect(await screen.findByText("Your Permanent Virtual Number")).toBeTruthy();
    expect(screen.getByText("Active Temporary Number")).toBeTruthy();
    expect(screen.getByText("700-0001")).toBeTruthy();
  });

  it("refreshes Last Recharge from a fresh server status when the user returns from checkout", async () => {
    vi.mocked(secureApi.recharge.status.query)
      .mockResolvedValueOnce({ serverTime: Date.now(), currentPlan: null, upcomingPlans: [], activeTemporaryEntitlements: [], latestSuccessfulRecharge: null } as never)
      .mockResolvedValueOnce({ serverTime: Date.now(), currentPlan: null, upcomingPlans: [], activeTemporaryEntitlements: [], latestSuccessfulRecharge: { purchaseId: "purchase-new", planId: "50d-freedom", planName: "50-Day Freedom", price: 17, validity: "50 Days", fulfilledAt: Date.UTC(2026, 7, 27) } } as never);
    render(<PlanSelection profile={{ uid: "owner", virtualNumbers: [] } as any} onClose={vi.fn()} onOpenHelloTune={vi.fn()} />);
    expect(await screen.findByText("No active plan")).toBeTruthy();
    window.dispatchEvent(new Event("focus"));
    expect(await screen.findByText("Last Recharge: 50-Day Freedom")).toBeTruthy();
  });

  it("filters only Recharge plans instantly by plan name, price, validity, and benefits without revealing HelloTune packs", async () => {
    render(<PlanSelection profile={{ uid: "owner", virtualNumbers: [] } as any} onClose={vi.fn()} onOpenHelloTune={vi.fn()} />);
    fireEvent.click(await screen.findByRole("button", { name: "Search plans" }));
    const search = screen.getByPlaceholderText("Search plans and packs");
    fireEvent.change(search, { target: { value: "17" } });
    expect(screen.getByRole("button", { name: /50-Day Freedom/ })).toBeTruthy();
    fireEvent.change(search, { target: { value: "unlimited app" } });
    expect(screen.getByRole("button", { name: /50-Day Freedom/ })).toBeTruthy();
    fireEvent.change(search, { target: { value: "376 Days" } });
    expect(screen.queryByText("₹15")).toBeNull();
    expect(screen.getByText("No Recharge plans or packs match your search.")).toBeTruthy();
    fireEvent.change(search, { target: { value: "nothing matches" } });
    expect(screen.getByText("No Recharge plans or packs match your search.")).toBeTruthy();
  });

  it("opens the four requested Android-style overflow actions and refreshes verified purchases", async () => {
    render(<PlanSelection profile={{ uid: "owner", virtualNumbers: [] } as any} onClose={vi.fn()} onOpenHelloTune={vi.fn()} />);
    await screen.findByRole("button", { name: /50-Day Freedom/ });
    fireEvent.click(screen.getByRole("button", { name: "More recharge options" }));
    expect(screen.getByText("Active Plans")).toBeTruthy();
    expect(screen.getByText("Purchase History")).toBeTruthy();
    expect(screen.getByText("Restore Purchases")).toBeTruthy();
    expect(screen.getByText("Help & Recharge Info")).toBeTruthy();
    fireEvent.click(screen.getByText("Purchase History"));
    expect(await screen.findByText("No Recharge purchases yet.")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "Close purchase history" }));
    fireEvent.click(screen.getByRole("button", { name: "More recharge options" }));
    fireEvent.click(screen.getByText("Help & Recharge Info"));
    expect(screen.getByText(/Choose a plan, review its price and validity/)).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "Close recharge help" }));
    fireEvent.click(screen.getByRole("button", { name: "More recharge options" }));
    fireEvent.click(screen.getByText("Restore Purchases"));
    expect(await screen.findByText("Your verified Recharge and HelloTune purchases have been refreshed.")).toBeTruthy();
  });
});
