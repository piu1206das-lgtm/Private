import React, { useEffect, useRef, useState } from "react";
import {
  AlertCircle, Check, Grid3X3, LockKeyhole, Mic, MicOff, Phone,
  PhoneIncoming, PhoneOff, PhoneOutgoing, User as UserIcon, Volume2, X,
} from "lucide-react";
import { doc, onSnapshot } from "firebase/firestore";
import { AnimatePresence, motion } from "motion/react";
import { db } from "../firebase";
import CachedImage from "./CachedImage";
import { hapticFeedback } from "../utils/haptics";
import { secureApi } from "../services/secureApi";
import { CallMediaSession, type LiveCallState } from "../services/callMedia";
import { createCallStatusAnnouncer, type AnnounceableCallState } from "../utils/callStatusAnnouncements";

interface CallScreenProps {
  callId?: string;
  targetNumber: string;
  isIncoming?: boolean;
  receiverNumber?: string;
  initialState?: TerminalState | "busy";
  initialMessage?: string;
  onEndCall: () => void;
}

type TerminalState = "rejected" | "ended" | "missed" | "cancelled" | "timeout" | "failed";
type DisplayCallState = LiveCallState | TerminalState | "busy";

const terminalStates: TerminalState[] = ["rejected", "ended", "missed", "cancelled", "timeout", "failed"];
const keypadTones = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#"];

function formatNumber(number: string) {
  if (number.length === 7) return `${number.slice(0, 3)}-${number.slice(3)}`;
  return number.length > 4 ? `${number.slice(0, 4)}-${number.slice(4)}` : number;
}

function labelForState(state: DisplayCallState, incoming: boolean) {
  const labels: Record<DisplayCallState, string> = {
    calling: "Calling…",
    ringing: incoming ? "Incoming call" : "Ringing…",
    connecting: "Connecting…",
    connected: "Connected",
    reconnecting: "Reconnecting…",
    disconnected: "Connection interrupted",
    busy: "Call busy",
    failed: "Call failed",
    rejected: "Call declined",
    ended: "Call ended",
    missed: "Missed call",
    cancelled: "Call cancelled",
    timeout: "No answer",
  };
  return labels[state];
}

function initialsFor(identity: string) {
  const initials = identity.trim().split(/\s+/).map(part => part[0]).filter(Boolean).join("").slice(0, 2);
  return initials ? initials.toUpperCase() : "?";
}

function timeForDuration(duration: number) {
  return `${Math.floor(duration / 60).toString().padStart(2, "0")}:${(duration % 60).toString().padStart(2, "0")}`;
}

function ControlButton({ label, active = false, disabled = false, onClick, children, ariaLabel }: {
  label: string;
  active?: boolean;
  disabled?: boolean;
  onClick: () => void;
  children: React.ReactNode;
  ariaLabel: string;
}) {
  return <div className="flex min-w-0 flex-1 flex-col items-center gap-2">
    <motion.button
      type="button"
      whileTap={{ scale: 0.94 }}
      onClick={onClick}
      disabled={disabled}
      aria-label={ariaLabel}
      aria-pressed={active}
      className={`ripple flex h-14 w-14 items-center justify-center rounded-[20px] border transition-colors disabled:opacity-50 ${active ? "border-amber-300 bg-amber-400 text-slate-950 shadow-lg shadow-amber-500/25" : "border-white/10 bg-white/10 text-white active:bg-white/20"}`}
    >
      {children}
    </motion.button>
    <span className={`truncate text-[11px] font-medium ${active ? "text-amber-200" : "text-slate-300"}`}>{label}</span>
  </div>;
}

export default function CallScreen({ callId, targetNumber, isIncoming = false, receiverNumber, initialState, initialMessage, onEndCall }: CallScreenProps) {
  const [contactName, setContactName] = useState<string | null>(null);
  const [contactPhoto] = useState<string | null>(null);
  const [callState, setCallState] = useState<DisplayCallState>(initialState || (isIncoming ? "ringing" : "calling"));
  const [duration, setDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isSpeaker, setIsSpeaker] = useState(false);
  const [isRoutingAudio, setIsRoutingAudio] = useState(false);
  const [showInCallKeypad, setShowInCallKeypad] = useState(false);
  const [sentTones, setSentTones] = useState("");
  const [permissionStep, setPermissionStep] = useState<"idle" | "explaining" | "requesting" | "denied">(initialState ? "idle" : (isIncoming ? "idle" : "explaining"));
  const [mediaError, setMediaError] = useState<string | null>(null);
  const [offer, setOffer] = useState<RTCSessionDescriptionInit | null>(null);
  const [isUpdating, setIsUpdating] = useState(false);
  const remoteAudioRef = useRef<HTMLAudioElement>(null);
  const sessionRef = useRef<CallMediaSession | null>(null);
  const terminalTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const onEndCallRef = useRef(onEndCall);
  const statusAnnouncerRef = useRef<ReturnType<typeof createCallStatusAnnouncer> | null>(null);

  if (!statusAnnouncerRef.current) statusAnnouncerRef.current = createCallStatusAnnouncer();

  useEffect(() => { onEndCallRef.current = onEndCall; }, [onEndCall]);

  useEffect(() => {
    const announceableStates: AnnounceableCallState[] = ["busy", "failed", "rejected", "ended", "missed", "cancelled", "timeout", "reconnecting", "disconnected"];
    if (announceableStates.includes(callState as AnnounceableCallState)) {
      statusAnnouncerRef.current?.announce({ callId, state: callState as AnnounceableCallState, initialMessage });
    }
  }, [callId, callState, initialMessage]);

  useEffect(() => {
    void secureApi.contacts.list.query().then((contacts) => {
      const contact = contacts.find((item) => item.number === targetNumber);
      if (contact) setContactName(contact.name);
    }).catch(() => undefined);
  }, [targetNumber]);

  const cleanUpAndReturn = () => {
    sessionRef.current?.cleanup();
    sessionRef.current = null;
    if (terminalTimerRef.current) clearTimeout(terminalTimerRef.current);
    terminalTimerRef.current = setTimeout(() => onEndCallRef.current(), 1500);
  };

  useEffect(() => {
    if (!callId) return;
    const unsubscribe = onSnapshot(doc(db, "calls", callId), (snapshot) => {
      if (!snapshot.exists()) return;
      const data = snapshot.data();
      const state = String(data.status || "calling") as LiveCallState | TerminalState;
      if (data.offer?.type === "offer" && data.offer.sdp) setOffer(data.offer as RTCSessionDescriptionInit);
      if (terminalStates.includes(state as TerminalState)) {
        setCallState(state);
        cleanUpAndReturn();
        return;
      }
      if (["calling", "ringing", "connecting", "connected", "reconnecting"].includes(state)) {
        setCallState(state as LiveCallState);
      }
    });
    return () => {
      unsubscribe();
      if (terminalTimerRef.current) clearTimeout(terminalTimerRef.current);
    };
  }, [callId]);

  useEffect(() => {
    if (!initialState) return;
    terminalTimerRef.current = setTimeout(() => onEndCallRef.current(), 1500);
    return () => { if (terminalTimerRef.current) clearTimeout(terminalTimerRef.current); };
  }, [initialState]);

  useEffect(() => {
    if (callState !== "connected") return;
    const timer = setInterval(() => setDuration((value) => value + 1), 1000);
    return () => clearInterval(timer);
  }, [callState]);

  useEffect(() => {
    if (!callId || isIncoming || !["calling", "ringing"].includes(callState)) return;
    const timeout = setTimeout(() => void endWith("timeout"), 40_000);
    return () => clearTimeout(timeout);
  }, [callId, isIncoming, callState]);

  useEffect(() => () => {
    sessionRef.current?.cleanup();
    statusAnnouncerRef.current?.cancel();
  }, []);

  const startRealMedia = async () => {
    if (!callId || isUpdating) return;
    setIsUpdating(true);
    setPermissionStep("requesting");
    setMediaError(null);
    try {
      const session = new CallMediaSession(
        callId,
        isIncoming,
        (state) => setCallState(state),
        (stream) => {
          const audio = remoteAudioRef.current;
          if (audio) {
            audio.srcObject = stream;
            void audio.play().catch(() => setMediaError("Tap speaker to play the caller audio."));
          }
        },
      );
      sessionRef.current = session;
      if (isIncoming) {
        if (!offer) throw new Error("Call offer is no longer available. Please ask the caller to try again.");
        await session.acceptIncoming(offer);
      } else {
        await session.beginOutgoing();
      }
      setPermissionStep("idle");
    } catch (error: any) {
      const denied = error?.name === "NotAllowedError" || error?.name === "SecurityError";
      setPermissionStep(denied ? "denied" : "idle");
      setMediaError(denied ? "Microphone access was denied. The call was not connected." : (error?.message || "Unable to start a secure audio connection."));
      setCallState("failed");
      sessionRef.current?.cleanup();
      sessionRef.current = null;
      try { await secureApi.calls.transition.mutate({ callId, status: "failed" }); } catch { /* remote state may already be terminal */ }
    } finally {
      setIsUpdating(false);
    }
  };

  const endWith = async (status: "cancelled" | "rejected" | "timeout" | "ended" | "failed") => {
    if (!callId || isUpdating) return;
    setIsUpdating(true);
    try {
      if (sessionRef.current) await sessionRef.current.close(status);
      else await secureApi.calls.transition.mutate({ callId, status });
      setCallState(status);
      cleanUpAndReturn();
    } catch (error: any) {
      setMediaError(error?.message || "Unable to update the call state.");
    } finally {
      setIsUpdating(false);
    }
  };

  const acceptIncoming = () => {
    setPermissionStep("explaining");
    setMediaError(null);
    hapticFeedback.medium();
  };

  const toggleMute = () => {
    if (!sessionRef.current) {
      setMediaError("Microphone controls are unavailable until the audio connection is ready.");
      return;
    }
    const nextMuted = !isMuted;
    sessionRef.current.setMuted(nextMuted);
    setIsMuted(nextMuted);
    hapticFeedback.light();
  };

  const toggleSpeaker = () => {
    void (async () => {
      const audio = remoteAudioRef.current as (HTMLAudioElement & { setSinkId?: (deviceId: string) => Promise<void> }) | null;
      const mediaDevices = navigator.mediaDevices as MediaDevices & { selectAudioOutput?: () => Promise<MediaDeviceInfo> };
      if (!audio?.setSinkId || !mediaDevices?.selectAudioOutput) {
        setMediaError("This browser lets Android manage speaker and earpiece routing. Use your device audio controls to change it.");
        return;
      }
      setIsRoutingAudio(true);
      setMediaError(null);
      try {
        if (isSpeaker) {
          await audio.setSinkId("default");
          setIsSpeaker(false);
        } else {
          const output = await mediaDevices.selectAudioOutput();
          await audio.setSinkId(output.deviceId);
          setIsSpeaker(true);
        }
        hapticFeedback.light();
      } catch (error: any) {
        if (error?.name !== "NotAllowedError" && error?.name !== "AbortError") {
          setMediaError("Unable to change the audio output for this call.");
        }
      } finally {
        setIsRoutingAudio(false);
      }
    })();
  };

  const sendInCallTone = (tone: string) => {
    if (!sessionRef.current?.sendDtmf(tone)) {
      setMediaError("In-call keypad tones are not supported by this browser or audio connection.");
      return;
    }
    setSentTones((current) => `${current}${tone}`.slice(-16));
    hapticFeedback.light();
  };

  useEffect(() => {
    if (callState !== "connected") setShowInCallKeypad(false);
  }, [callState]);

  const isConnected = callState === "connected";
  const hasActiveMedia = callState === "connected" || callState === "reconnecting";
  const isTerminal = callState === "busy" || terminalStates.includes(callState as TerminalState);
  const identity = contactName || formatNumber(targetNumber);
  const statusLabel = isConnected ? timeForDuration(duration) : labelForState(callState, isIncoming);
  const statusIcon = isIncoming ? <PhoneIncoming className="h-3.5 w-3.5" /> : <PhoneOutgoing className="h-3.5 w-3.5" />;

  return <motion.section
    initial={{ opacity: 0, scale: 0.985 }}
    animate={{ opacity: 1, scale: 1 }}
    exit={{ opacity: 0, scale: 0.985 }}
    transition={{ type: "spring", stiffness: 360, damping: 34 }}
    className="absolute inset-0 z-[70] flex min-h-0 flex-col overflow-hidden bg-[#111827] text-white"
    aria-label="Call screen"
  >
    <audio ref={remoteAudioRef} autoPlay playsInline />
    <div aria-hidden="true" className="pointer-events-none absolute -right-20 -top-24 h-80 w-80 rounded-full bg-amber-400/10 blur-3xl" />
    <div aria-hidden="true" className="pointer-events-none absolute -bottom-20 -left-24 h-72 w-72 rounded-full bg-orange-500/10 blur-3xl" />

    <header className="relative z-10 flex shrink-0 items-center justify-between px-5 pb-3 pt-[max(1.25rem,env(safe-area-inset-top,0px))]">
      <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.06] px-3 py-1.5 text-[11px] font-semibold tracking-[0.08em] text-slate-200">
        <LockKeyhole className="h-3.5 w-3.5 text-amber-300" /> SECURE CALL
      </div>
      <span className={`inline-flex items-center gap-1.5 text-xs font-medium ${callState === "reconnecting" ? "text-amber-300" : "text-slate-400"}`}>
        {callState === "reconnecting" ? "Connection recovering" : isTerminal ? "Ending safely" : "Internet calling"}
      </span>
    </header>

    <main className="relative z-10 flex min-h-0 flex-1 flex-col items-center justify-center px-6 pb-4 pt-1 text-center">
      <motion.div
        animate={isTerminal ? { scale: 0.96, opacity: 0.8 } : { scale: 1, opacity: 1 }}
        transition={{ duration: 0.2 }}
        className="relative"
      >
        {!isTerminal && <><span aria-hidden="true" className={`absolute -inset-4 rounded-full border ${callState === "reconnecting" ? "border-amber-300/30" : "border-white/10"}`} /><span aria-hidden="true" className="absolute -inset-8 rounded-full border border-white/[0.04]" /></>}
        <div className="relative flex h-32 w-32 items-center justify-center overflow-hidden rounded-[44px] border border-white/10 bg-gradient-to-br from-slate-600 to-slate-800 shadow-2xl shadow-black/30">
          {contactPhoto ? <CachedImage src={contactPhoto} className="h-full w-full object-cover" /> : <span className="text-[38px] font-semibold tracking-tight text-white">{initialsFor(identity)}</span>}
        </div>
      </motion.div>

      <div className="mt-10 max-w-full">
        <h1 className="truncate text-[30px] font-semibold leading-tight tracking-tight text-white">{identity}</h1>
        <p className="mt-2 font-mono text-[15px] tracking-[0.16em] text-slate-400">{formatNumber(targetNumber)}</p>
      </div>

      <div className={`mt-6 inline-flex min-h-8 items-center gap-2 rounded-full border px-3.5 py-1.5 text-[13px] font-semibold ${callState === "reconnecting" ? "border-amber-300/25 bg-amber-400/10 text-amber-200" : isTerminal ? "border-white/10 bg-white/[0.06] text-slate-300" : "border-white/10 bg-white/[0.08] text-slate-100"}`}>
        {!isTerminal && !isConnected && statusIcon}
        {isConnected && <Check className="h-3.5 w-3.5 text-emerald-300" />}
        <span>{statusLabel}</span>
      </div>
      {isConnected && <p className="mt-2 text-xs font-medium text-emerald-300">Encrypted voice connection</p>}
      {isIncoming && receiverNumber?.length === 7 && <p className="mt-2 text-xs font-medium text-blue-200">Calling your temporary number</p>}
      {callState === "connecting" && <p className="mt-3 max-w-[260px] text-[13px] leading-5 text-slate-400">Establishing a secure audio connection…</p>}
      {isTerminal && <p className="mt-3 text-[13px] text-slate-400">Returning to the app…</p>}
      {(mediaError || initialMessage) && <div role="alert" className="mt-6 flex max-w-sm items-start gap-2.5 rounded-2xl border border-amber-300/15 bg-slate-900/85 px-4 py-3 text-left text-[13px] leading-5 text-slate-100 shadow-lg shadow-black/20"><AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-amber-300" /><span>{mediaError || initialMessage}</span></div>}
    </main>

    <footer className="relative z-10 shrink-0 border-t border-white/[0.07] bg-slate-950/35 px-6 pb-[max(1.25rem,env(safe-area-inset-bottom,0px))] pt-5 backdrop-blur-sm">
      {hasActiveMedia ? <div className="mx-auto flex w-full max-w-sm items-start justify-between gap-2">
        <ControlButton label={isMuted ? "Unmute" : "Mute"} active={isMuted} onClick={toggleMute} ariaLabel={isMuted ? "Unmute microphone" : "Mute microphone"}><>{isMuted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}</></ControlButton>
        <ControlButton label="Speaker" active={isSpeaker} disabled={isRoutingAudio} onClick={toggleSpeaker} ariaLabel="Toggle speaker output"><Volume2 className="h-5 w-5" /></ControlButton>
        <ControlButton label="Keypad" active={showInCallKeypad} onClick={() => { setShowInCallKeypad(visible => !visible); hapticFeedback.light(); }} ariaLabel={showInCallKeypad ? "Close in-call keypad" : "Open in-call keypad"}><Grid3X3 className="h-5 w-5" /></ControlButton>
        <ControlButton label="End" onClick={() => void endWith("ended")} disabled={isUpdating} ariaLabel="End call"><PhoneOff className="h-5 w-5" /></ControlButton>
      </div> : !isTerminal && isIncoming && callState === "ringing" ? <div className="mx-auto flex max-w-sm items-start justify-around gap-8">
        <div className="flex flex-col items-center gap-2"><motion.button type="button" whileTap={{ scale: 0.94 }} onClick={() => void endWith("rejected")} disabled={isUpdating} aria-label="Decline call" className="ripple flex h-16 w-16 items-center justify-center rounded-[22px] bg-red-500 text-white shadow-lg shadow-red-500/25 active:bg-red-600 disabled:opacity-60"><PhoneOff className="h-7 w-7" /></motion.button><span className="text-xs font-medium text-slate-300">Decline</span></div>
        <div className="flex flex-col items-center gap-2"><motion.button type="button" whileTap={{ scale: 0.94 }} onClick={acceptIncoming} disabled={isUpdating} aria-label="Accept call" className="ripple flex h-16 w-16 items-center justify-center rounded-[22px] bg-amber-400 text-slate-950 shadow-lg shadow-amber-500/25 active:bg-amber-300 disabled:opacity-60"><Phone className="h-7 w-7 fill-current" /></motion.button><span className="text-xs font-medium text-amber-200">Accept</span></div>
      </div> : !isTerminal && !isIncoming && ["calling", "ringing"].includes(callState) ? <div className="flex flex-col items-center gap-2"><motion.button type="button" whileTap={{ scale: 0.94 }} onClick={() => void endWith("cancelled")} disabled={isUpdating} aria-label="Cancel call" className="ripple flex h-16 w-16 items-center justify-center rounded-[22px] bg-red-500 text-white shadow-lg shadow-red-500/25 active:bg-red-600 disabled:opacity-60"><PhoneOff className="h-7 w-7" /></motion.button><span className="text-xs font-medium text-slate-300">Cancel</span></div> : <div className="h-[74px]" />}
    </footer>

    <AnimatePresence>
      {showInCallKeypad && isConnected && <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 z-[80] flex items-end bg-black/50 backdrop-blur-[1px]" onClick={() => setShowInCallKeypad(false)}>
        <motion.section role="dialog" aria-label="In-call keypad" initial={{ y: 300 }} animate={{ y: 0 }} exit={{ y: 300 }} transition={{ type: "spring", stiffness: 360, damping: 32 }} className="w-full rounded-t-[32px] border-t border-white/10 bg-slate-900 px-6 pb-[max(1.5rem,env(safe-area-inset-bottom,0px))] pt-3 shadow-2xl" onClick={(event) => event.stopPropagation()}>
          <div className="mx-auto h-1 w-10 rounded-full bg-slate-600" />
          <div className="mb-4 mt-3 flex items-start justify-between gap-3"><div className="text-left"><h2 className="text-[16px] font-semibold text-white">In-call keypad</h2><p aria-label="Sent keypad tones" className="mt-1 h-4 font-mono text-[12px] tracking-[0.22em] text-amber-200">{sentTones || " "}</p></div><button type="button" onClick={() => setShowInCallKeypad(false)} aria-label="Dismiss in-call keypad" className="ripple flex h-10 w-10 items-center justify-center rounded-full text-slate-300 active:bg-white/10"><X className="h-5 w-5" /></button></div>
          <div className="mx-auto grid max-w-[272px] grid-cols-3 gap-x-5 gap-y-1">{keypadTones.map((tone) => <motion.button type="button" whileTap={{ scale: 0.9 }} key={tone} onClick={() => sendInCallTone(tone)} aria-label={`Send tone ${tone}`} className="ripple h-12 rounded-2xl text-[26px] font-medium leading-none text-white active:bg-white/10">{tone}</motion.button>)}</div>
        </motion.section>
      </motion.div>}
    </AnimatePresence>

    <AnimatePresence>
      {permissionStep === "explaining" && <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 z-[90] flex items-end bg-black/45 backdrop-blur-[1px]">
        <motion.section role="dialog" aria-label="Microphone permission" initial={{ y: 260 }} animate={{ y: 0 }} exit={{ y: 260 }} transition={{ type: "spring", stiffness: 340, damping: 32 }} className="w-full rounded-t-[32px] bg-white px-6 pb-[max(1.75rem,env(safe-area-inset-bottom,0px))] pt-4 text-slate-900">
          <div className="mx-auto h-1 w-10 rounded-full bg-slate-200" /><div className="mt-5 flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-100 text-amber-700"><Mic className="h-5 w-5" /></div><h2 className="mt-4 text-[21px] font-semibold tracking-tight">Allow microphone access</h2><p className="mt-2 text-[14px] leading-5 text-slate-600">Microphone access is required to establish this call. The app will not show Connected unless an audio connection is actually established.</p><div className="mt-6 flex gap-3"><button type="button" onClick={() => void endWith(isIncoming ? "rejected" : "cancelled")} className="ripple h-12 flex-1 rounded-xl bg-slate-100 text-[14px] font-semibold text-slate-700 active:bg-slate-200">Cancel</button><button type="button" onClick={() => void startRealMedia()} disabled={isUpdating} className="ripple h-12 flex-1 rounded-xl bg-amber-400 text-[14px] font-semibold text-slate-950 shadow-sm shadow-amber-500/25 active:bg-amber-300 disabled:opacity-60">{isIncoming ? "Accept & connect" : "Allow & call"}</button></div></motion.section>
      </motion.div>}
      {permissionStep === "requesting" && <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 z-[90] flex items-end bg-black/45"><div className="w-full rounded-t-[32px] bg-white px-6 pb-[max(1.75rem,env(safe-area-inset-bottom,0px))] pt-6 text-center text-slate-900"><div className="mx-auto h-8 w-8 animate-spin rounded-full border-[3px] border-amber-200 border-t-amber-600" /><p className="mt-4 text-[15px] font-semibold">Requesting microphone access…</p></div></motion.div>}
      {permissionStep === "denied" && <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 z-[90] flex items-end bg-black/45"><motion.section initial={{ y: 160 }} animate={{ y: 0 }} exit={{ y: 160 }} className="w-full rounded-t-[32px] bg-white px-6 pb-[max(1.75rem,env(safe-area-inset-bottom,0px))] pt-5 text-slate-900"><AlertCircle className="h-6 w-6 text-red-500" /><h2 className="mt-3 text-[20px] font-semibold">Microphone permission needed</h2><p className="mt-2 text-[14px] leading-5 text-slate-600">The call was not connected because microphone access was denied. Enable it in Android settings before trying again.</p><button type="button" onClick={() => onEndCallRef.current()} className="ripple mt-6 h-12 w-full rounded-xl bg-amber-400 text-[14px] font-semibold text-slate-950 active:bg-amber-300">Done</button></motion.section></motion.div>}
    </AnimatePresence>
  </motion.section>;
}
