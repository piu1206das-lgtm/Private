/**
 * Style reminder — this remains an Android contact utility surface: compact rows
 * on one quiet background, visible virtual numbers, and contextual bottom sheets.
 */
import React, { useCallback, useEffect, useMemo, useState } from "react";
import { AlertCircle, Ban, Check, Edit2, Phone, Search, ShieldAlert, Trash2, UserPlus, X } from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { secureApi } from "../services/secureApi";
import { UserProfile } from "../types";
import { bottomSheetTransition, listItemFade, listStagger, tapScale } from "../utils/animations";
import { hapticFeedback } from "../utils/haptics";
import { requiresContactCallingPin } from "../utils/contactCallingPin";
import PinPadModal from "./PinPadModal";

interface Contact {
  id: string;
  name: string;
  number: string;
  hasCallingPin?: boolean;
  createdAt?: number;
  updatedAt?: number;
}

interface ContactsTabProps {
  profile: UserProfile;
  onCallInitiate: (number: string) => void;
  onBlockContact: (number: string, label: string) => Promise<void>;
  onUnblockContact: (number: string) => Promise<void>;
  onReportContact: (number: string) => void;
}

const cleanNumber = (value: string) => value.replace(/\D/g, "").slice(0, 8);
const formatNumber = (number: string) => number.length > 4 ? `${number.slice(0, 4)}-${number.slice(4)}` : number;
const avatarInitial = (name: string) => name.trim().charAt(0).toUpperCase() || "?";

export default function ContactsTab({ profile, onCallInitiate, onBlockContact, onUnblockContact, onReportContact }: ContactsTabProps) {
  const [search, setSearch] = useState("");
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);
  const [editorMode, setEditorMode] = useState<"add" | "edit" | null>(null);
  const [editName, setEditName] = useState("");
  const [editNumber, setEditNumber] = useState("");
  const [editCallingPin, setEditCallingPin] = useState("");
  const [error, setError] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [isOnline, setIsOnline] = useState(() => typeof navigator === "undefined" || navigator.onLine);
  const [selectedBlockState, setSelectedBlockState] = useState<boolean | null>(null);
  const [pendingBlockAction, setPendingBlockAction] = useState<"block" | "unblock" | null>(null);
  const [pinContact, setPinContact] = useState<Contact | null>(null);

  const loadContacts = useCallback(async () => {
    if (!navigator.onLine) return;
    try {
      const latest = await secureApi.contacts.list.query();
      setContacts(latest);
      setError("");
    } catch (loadError: any) {
      setError(loadError?.message || "Contacts could not be refreshed. Check your connection and try again.");
    }
  }, []);

  useEffect(() => {
    const updateOnline = () => setIsOnline(navigator.onLine);
    window.addEventListener("online", updateOnline);
    window.addEventListener("offline", updateOnline);
    return () => {
      window.removeEventListener("online", updateOnline);
      window.removeEventListener("offline", updateOnline);
    };
  }, []);

  useEffect(() => {
    if (!isOnline) return;
    void loadContacts();
    const syncInterval = window.setInterval(() => void loadContacts(), 15_000);
    return () => window.clearInterval(syncInterval);
  }, [isOnline, loadContacts, profile.uid]);

  const blockedNumbers = useMemo(() => new Set((profile.blockedUsersList || []).map((entry) => entry.number)), [profile.blockedUsersList]);
  const filteredContacts = useMemo(() => {
    const term = search.trim().toLowerCase();
    return contacts
      .filter((contact) => !term || contact.name.toLowerCase().includes(term) || contact.number.includes(term))
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [contacts, search]);

  const openAdd = () => {
    setError("");
    setEditName("");
    setEditNumber("");
    setEditCallingPin("");
    setEditorMode("add");
  };

  const openEdit = () => {
    if (!selectedContact) return;
    setError("");
    setEditName(selectedContact.name);
    setEditNumber(selectedContact.number);
    setEditCallingPin("");
    setEditorMode("edit");
  };

  const openContactDetails = (contact: Contact) => {
    hapticFeedback.light();
    setError("");
    setSelectedContact(contact);
    setSelectedBlockState(null);
    if (!navigator.onLine) {
      setError("Block status could not be refreshed while offline.");
      return;
    }
    void secureApi.privacy.blockStatus.query({ targetNumber: contact.number }).then((result) => {
      setSelectedBlockState(result.blocked);
    }).catch((statusError: any) => {
      setError(statusError?.message || "Current block status could not be refreshed.");
      setSelectedBlockState(null);
    });
  };

  const saveContact = async () => {
    const name = editName.trim();
    const number = cleanNumber(editNumber);
    if (!name || (number.length !== 7 && number.length !== 8)) {
      setError("Enter a name and a 7-digit temporary or 8-digit permanent virtual number.");
      return;
    }
    if (editCallingPin && !/^\d{4}$/.test(editCallingPin)) {
      setError("Calling PIN must contain exactly 4 digits.");
      return;
    }
    if (!isOnline) {
      setError("Saving contacts requires an internet connection. Your current contacts remain available.");
      return;
    }
    setIsSaving(true);
    setError("");
    try {
      if (editorMode === "edit" && selectedContact) {
        await secureApi.contacts.update.mutate({ id: selectedContact.id, name, number, callingPin: editCallingPin || undefined });
        setSelectedContact({ ...selectedContact, name, number, hasCallingPin: number.length === 8 && Boolean(editCallingPin || selectedContact.hasCallingPin) });
      } else {
        await secureApi.contacts.add.mutate({ name, number, callingPin: editCallingPin || undefined });
      }
      await loadContacts();
      hapticFeedback.success();
      setEditorMode(null);
    } catch (saveError: any) {
      setError(saveError?.message || "Unable to save this contact.");
    } finally {
      setIsSaving(false);
    }
  };

  const callContact = async (contact: Contact, closeDetails = false) => {
    if (!requiresContactCallingPin(contact.number)) {
      await onCallInitiate(contact.number);
      if (closeDetails) setSelectedContact(null);
      return;
    }
    if (!contact.hasCallingPin) {
      setPinContact(contact);
      return;
    }
    try {
      const authorization = await secureApi.contacts.authorizeSavedPin.mutate({ id: contact.id });
      if (!authorization.pinRequired || authorization.authorized) {
        await onCallInitiate(contact.number);
        if (closeDetails) setSelectedContact(null);
      } else {
        setPinContact(contact);
      }
    } catch (callError: any) {
      setError(callError?.message || "Unable to prepare this call.");
    }
  };

  const deleteContact = async () => {
    if (!selectedContact || isSaving) return;
    if (!confirm("Delete this contact?")) return;
    if (!isOnline) {
      setError("Deleting contacts requires an internet connection.");
      return;
    }
    setIsSaving(true);
    try {
      await secureApi.contacts.remove.mutate({ id: selectedContact.id });
      await loadContacts();
      hapticFeedback.success();
      setSelectedContact(null);
      setEditorMode(null);
    } catch (deleteError: any) {
      setError(deleteError?.message || "Unable to delete this contact.");
    } finally {
      setIsSaving(false);
    }
  };

  const blockSelected = async () => {
    if (!selectedContact || isSaving) return;
    setIsSaving(true);
    try {
      await onBlockContact(selectedContact.number, selectedContact.name);
      setSelectedBlockState(true);
      setPendingBlockAction(null);
      hapticFeedback.success();
    } catch (blockError: any) {
      setError(blockError?.message || "Unable to block this number.");
    } finally {
      setIsSaving(false);
    }
  };

  const unblockSelected = async () => {
    if (!selectedContact || isSaving) return;
    setIsSaving(true);
    try {
      await onUnblockContact(selectedContact.number);
      setSelectedBlockState(false);
      setPendingBlockAction(null);
      hapticFeedback.success();
    } catch (unblockError: any) {
      setError(unblockError?.message || "Unable to unblock this number.");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="flex-1 w-full bg-white flex flex-col relative overflow-hidden">
      <div className="px-5 pt-12 pb-3 flex items-center justify-between bg-white z-10 border-b border-slate-100">
        <div>
          <h1 className="text-[22px] font-semibold text-slate-900 tracking-tight">Contacts</h1>
          <p className="text-xs text-slate-400 mt-0.5">Private labels, synced to your account</p>
        </div>
        <button onClick={openAdd} aria-label="Add contact" className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-amber-500 active:bg-slate-50 transition-colors ripple">
          <UserPlus className="w-6 h-6" />
        </button>
      </div>

      {!isOnline && (
        <div className="px-5 py-2 bg-amber-50 border-b border-amber-100 text-[12px] text-amber-800 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          Offline — contacts shown here may be stale. Saving changes requires a connection.
        </div>
      )}

      <div className="px-5 py-3 bg-white z-10 border-b border-slate-100">
        <div className="relative">
          <Search className="w-5 h-5 absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
          <input type="search" placeholder="Search contacts" value={search} onChange={(event) => setSearch(event.target.value)} className="w-full h-11 bg-slate-50 border-none rounded-full pl-11 pr-4 outline-none focus:bg-slate-100 transition-colors text-[16px] text-slate-700 placeholder:text-slate-400" />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto bg-white pb-24">
        {error && <p className="mx-5 mt-3 px-3 py-2 bg-red-50 rounded-lg text-sm text-red-700" role="alert">{error}</p>}
        {filteredContacts.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-slate-400 px-10 text-center">
            <Search className="w-8 h-8 mb-3 opacity-30" />
            <p className="text-sm font-medium">{search ? "No contacts match your search" : "No saved contacts yet"}</p>
            {!search && <button onClick={openAdd} className="mt-3 text-sm font-semibold text-amber-600">Add Contact</button>}
          </div>
        ) : (
          <motion.div variants={listStagger} initial="initial" animate="animate" className="divide-y divide-slate-100">
            <AnimatePresence>
              {filteredContacts.map((contact) => {
                const isBlocked = blockedNumbers.has(contact.number);
                return (
                  <motion.div variants={listItemFade} layout key={contact.id} onClick={() => openContactDetails(contact)} className="flex items-center px-5 py-3 active:bg-slate-50 transition-colors cursor-pointer">
                    <div className="w-11 h-11 rounded-full bg-amber-100 flex items-center justify-center mr-4 shrink-0">
                      <span className="text-amber-800 font-semibold text-lg">{avatarInitial(contact.name)}</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-[17px] font-normal text-slate-900 truncate">{contact.name}</h4>
                      <p className="text-[13px] text-slate-500 font-mono tracking-wide">{formatNumber(contact.number)}</p>
                    </div>
                    {isBlocked ? (
                      <span className="text-[11px] font-semibold text-red-500 mr-2">Blocked</span>
                    ) : (
                      <motion.button whileTap={tapScale} onClick={(event) => { event.stopPropagation(); hapticFeedback.light(); void callContact(contact); }} aria-label={`Call ${contact.name}`} className="w-12 h-12 flex items-center justify-center text-amber-500 active:bg-amber-50 rounded-full transition-colors ripple">
                        <Phone className="w-5 h-5" />
                      </motion.button>
                    )}
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </motion.div>
        )}
      </div>

      <AnimatePresence>
        {editorMode && (
          <div className="absolute inset-0 z-50 flex flex-col justify-end">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={() => setEditorMode(null)} />
            <motion.div variants={bottomSheetTransition} initial="initial" animate="animate" exit="exit" className="bg-white rounded-t-[24px] p-6 pb-8 shadow-2xl relative z-10">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-semibold text-slate-900">{editorMode === "add" ? "Add Contact" : "Edit Contact"}</h3>
                <motion.button whileTap={tapScale} onClick={() => setEditorMode(null)} className="p-2 text-slate-400 active:bg-slate-100 rounded-full"><X className="w-5 h-5" /></motion.button>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1 block">Name</label>
                  <input type="text" value={editName} onChange={(event) => setEditName(event.target.value)} className="w-full h-12 border border-slate-200 rounded-xl px-4 text-slate-800 text-lg outline-none focus:border-amber-400" placeholder="Contact name" autoFocus />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1 block">Virtual Number</label>
                  <input type="tel" inputMode="numeric" value={formatNumber(cleanNumber(editNumber))} onChange={(event) => setEditNumber(cleanNumber(event.target.value))} className="w-full h-12 border border-slate-200 rounded-xl px-4 text-slate-800 font-mono text-lg outline-none focus:border-amber-400" placeholder="7 or 8 digit number" />
                  <p className="mt-1 text-xs text-slate-400">7 digits: temporary, no PIN. 8 digits: permanent, PIN required.</p>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1 block">Calling PIN <span className="normal-case font-normal">(Optional)</span></label>
                  <input type="password" inputMode="numeric" maxLength={4} value={editCallingPin} onChange={(event) => setEditCallingPin(event.target.value.replace(/\D/g, "").slice(0, 4))} className="w-full h-12 border border-slate-200 rounded-xl px-4 text-slate-800 font-mono text-lg outline-none focus:border-amber-400" placeholder="••••" />
                  <p className="mt-1 text-xs text-slate-400">Used only for this 8-digit permanent contact. Ignored for temporary numbers.</p>
                </div>
                {error && <p className="text-sm text-red-600" role="alert">{error}</p>}
                <motion.button whileTap={isSaving ? undefined : tapScale} onClick={saveContact} disabled={isSaving} className="w-full h-12 bg-amber-500 text-white rounded-xl font-semibold mt-2 shadow-sm disabled:opacity-50">
                  {isSaving ? "Saving…" : editorMode === "add" ? "Save Contact" : "Save Changes"}
                </motion.button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {selectedContact && !editorMode && (
          <div className="absolute inset-0 z-50 flex flex-col justify-end">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={() => setSelectedContact(null)} />
            <motion.div variants={bottomSheetTransition} initial="initial" animate="animate" exit="exit" className="bg-white rounded-t-[28px] p-6 pb-8 shadow-2xl relative z-10 max-h-[90%] overflow-y-auto">
              <div className="w-full flex justify-center mb-4"><div className="w-12 h-1.5 bg-slate-200 rounded-full" /></div>
              <div className="absolute top-6 right-6 flex gap-2">
                <motion.button whileTap={tapScale} onClick={openEdit} aria-label="Edit contact" className="p-2 text-slate-500 active:bg-slate-100 rounded-full ripple"><Edit2 className="w-5 h-5" /></motion.button>
                <motion.button whileTap={tapScale} onClick={deleteContact} aria-label="Delete contact" className="p-2 text-red-500 active:bg-red-50 rounded-full ripple"><Trash2 className="w-5 h-5" /></motion.button>
              </div>
              <div className="flex flex-col items-center mb-6 mt-2">
                <div className="w-24 h-24 rounded-full bg-amber-100 flex items-center justify-center mb-4"><span className="text-amber-800 font-semibold text-4xl">{avatarInitial(selectedContact.name)}</span></div>
                <h2 className="text-[28px] font-normal text-slate-900 mb-1">{selectedContact.name}</h2>
                <p className="text-[18px] font-mono text-slate-500 tracking-wider">{formatNumber(selectedContact.number)}</p>
                <p className="text-xs text-slate-400 mt-2">Saved locally to your account — not verified identity.</p>
              </div>
              {selectedBlockState === true ? (
                <div className="flex items-center justify-center gap-2 py-3 text-red-600 text-sm font-semibold"><Ban className="w-4 h-4" /> This contact is blocked</div>
              ) : selectedBlockState === false ? (
                <div className="flex justify-center gap-4 mb-6">
                  <motion.button whileTap={tapScale} onClick={() => { hapticFeedback.medium(); void callContact(selectedContact, true); }} className="w-16 h-16 bg-amber-500 text-white rounded-full flex items-center justify-center shadow-lg shadow-amber-500/20 ripple"><Phone className="w-6 h-6 fill-current" /></motion.button>
                </div>
              ) : <div className="flex items-center justify-center gap-2 py-3 text-slate-500 text-sm"><span className="w-3 h-3 rounded-full border-2 border-slate-300 border-t-amber-500 animate-spin" /> Checking current block status…</div>}
              <div className="border-t border-slate-100 pt-2">
                {selectedBlockState === false && <motion.button whileTap={tapScale} onClick={() => setPendingBlockAction("block")} disabled={isSaving} className="w-full flex items-center gap-4 py-4 px-2 active:bg-slate-50 text-slate-700 ripple disabled:opacity-50"><ShieldAlert className="w-6 h-6 text-slate-400" /><span className="font-normal text-[16px]">Block number</span></motion.button>}
                {selectedBlockState === true && <motion.button whileTap={tapScale} onClick={() => setPendingBlockAction("unblock")} disabled={isSaving} className="w-full flex items-center gap-4 py-4 px-2 active:bg-slate-50 text-slate-700 ripple disabled:opacity-50"><Ban className="w-6 h-6 text-slate-400" /><span className="font-normal text-[16px]">Unblock number</span></motion.button>}
                <motion.button whileTap={tapScale} onClick={() => { onReportContact(selectedContact.number); setSelectedContact(null); }} className="w-full flex items-center gap-4 py-4 px-2 active:bg-slate-50 text-slate-700 ripple"><AlertCircle className="w-6 h-6 text-slate-400" /><span className="font-normal text-[16px]">Report number</span></motion.button>
              </div>
              <AnimatePresence>{pendingBlockAction && <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 z-10 flex items-end bg-slate-900/40" onClick={() => setPendingBlockAction(null)}><motion.div initial={{ y: 32 }} animate={{ y: 0 }} exit={{ y: 32 }} className="w-full rounded-t-[24px] bg-white p-6 pb-8" onClick={(event) => event.stopPropagation()}><h3 className="text-[20px] font-semibold text-slate-900">{pendingBlockAction === "block" ? "Block this number?" : "Unblock this number?"}</h3>{pendingBlockAction === "block" && <p className="mt-2 text-[14px] leading-5 text-slate-500">You will no longer receive calls from this number.</p>}<div className="mt-6 flex gap-3"><button onClick={() => setPendingBlockAction(null)} disabled={isSaving} className="h-12 flex-1 rounded-xl bg-slate-100 font-semibold text-slate-700">Cancel</button><button onClick={() => { void (pendingBlockAction === "block" ? blockSelected() : unblockSelected()); }} disabled={isSaving} className={`h-12 flex-1 rounded-xl font-semibold text-white ${pendingBlockAction === "block" ? "bg-amber-500" : "bg-slate-800"}`}>{isSaving ? "Saving…" : pendingBlockAction === "block" ? "Block" : "Unblock"}</button></div></motion.div></motion.div>}</AnimatePresence>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      {pinContact && <PinPadModal callerUid={profile.uid} targetNumber={pinContact.number} onSuccess={async () => { const contact = pinContact; setPinContact(null); await onCallInitiate(contact.number); setSelectedContact(null); }} onCancel={() => setPinContact(null)} />}
    </div>
  );
}
