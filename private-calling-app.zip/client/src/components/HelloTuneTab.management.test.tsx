// @vitest-environment jsdom
import React from "react";
import { render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import HelloTuneTab from "./HelloTuneTab";

vi.mock("../firebase", () => ({ auth: { currentUser: null } }));
vi.mock("../services/secureApi", () => ({ secureApi: { helloTune: { remove: { mutate: vi.fn() }, activate: { mutate: vi.fn() } } } }));
vi.mock("../utils/haptics", () => ({ hapticFeedback: { light: vi.fn(), success: vi.fn(), error: vi.fn() } }));

describe("HelloTune management surface", () => {
  it("does not expose hardcoded packs or a client-only purchase action when no verified pass is active", () => {
    render(<HelloTuneTab profile={{ uid: "owner", activeHelloTunePass: undefined, helloTune: undefined } as any} onClose={vi.fn()} />);
    expect(screen.getByText("No active HelloTune pack")).toBeTruthy();
    expect(screen.getByRole("button", { name: "Return to Recharge" })).toBeTruthy();
    expect(screen.queryByText("Select this plan")).toBeNull();
    expect(screen.queryByText("₹3")).toBeNull();
  });
});
