// @vitest-environment jsdom
import React from "react";
import { cleanup, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

const motionProbe = vi.hoisted(() => ({ onDragEnd: null as null | ((event: unknown, info: { offset: { y: number }; velocity: { y: number } }) => void) }));

vi.mock("motion/react", async () => {
  const ReactModule = await import("react");
  const motionElement = (tag: string) => ({ children, onDragEnd, drag: _drag, dragConstraints: _constraints, dragElastic: _elastic, dragMomentum: _momentum, dragSnapToOrigin: _snap, variants: _variants, initial: _initial, animate: _animate, exit: _exit, whileTap: _whileTap, ...props }: any) => {
    if (onDragEnd) motionProbe.onDragEnd = onDragEnd;
    return ReactModule.createElement(tag, {
    ...props,
    });
  };
  return { motion: { div: motionElement("div"), button: motionElement("button") } };
});

vi.mock("../firebase", () => ({ auth: null, db: null }));
vi.mock("../utils/haptics", () => ({ hapticFeedback: { light: vi.fn() } }));

import { BottomSheet } from "./ProfileModals";

afterEach(cleanup);

describe("BottomSheet bound drag behavior", () => {
  it("keeps a small drag open and dismisses after a sufficient downward drag", () => {
    const onClose = vi.fn();
    render(<BottomSheet title="Notifications" onClose={onClose} dragToDismiss><div>Content</div></BottomSheet>);
    const sheet = screen.getByTestId("bottom-sheet");

    motionProbe.onDragEnd?.({}, { offset: { y: 42 }, velocity: { y: 120 } });
    expect(onClose).not.toHaveBeenCalled();
    motionProbe.onDragEnd?.({}, { offset: { y: 110 }, velocity: { y: 0 } });
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  it("keeps non-draggable shared sheets from binding a dismiss gesture", () => {
    render(<BottomSheet title="Other" onClose={vi.fn()}><div>Content</div></BottomSheet>);
    expect(screen.getByTestId("bottom-sheet").getAttribute("data-drag-dismiss")).toBe("false");
  });
});
