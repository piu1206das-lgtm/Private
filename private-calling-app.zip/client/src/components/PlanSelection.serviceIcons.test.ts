import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const source = readFileSync(fileURLToPath(new URL("./PlanSelection.tsx", import.meta.url)), "utf8");

describe("Recharge service PNG icons", () => {
  it("uses only the designated transparent PNG sources at the retained 20px service-icon size", () => {
    expect(source).toContain('const RECHARGE_FRIEND_ICON_SRC = "/manus-storage/recharge-friend-icon_75c0f152.png"');
    expect(source).toContain('const VIP_NUMBERS_ICON_SRC = "/manus-storage/vip-numbers-crown-icon_ac02359c.png"');
    expect(source).toContain('src={RECHARGE_FRIEND_ICON_SRC}');
    expect(source).toContain('src={VIP_NUMBERS_ICON_SRC}');
    expect(source).toContain('className="w-5 h-5 object-contain"');
    expect(source).not.toContain('<ShieldCheck className="w-5 h-5" />');
  });
});
