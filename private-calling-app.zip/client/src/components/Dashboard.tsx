import { Hash, Copy, CheckCircle2, Phone } from "lucide-react";
import { UserProfile, VirtualNumber } from "../types";
import { useState } from "react";
import Dialer from "./Dialer";

interface DashboardProps {
  profile: UserProfile;
  onOpenDialer?: () => void;
  onStartCall: (num: string) => void;
}

export default function Dashboard({ profile, onStartCall }: DashboardProps) {
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [showDialer, setShowDialer] = useState(false);

  const copyToClipboard = (number: string) => {
    navigator.clipboard.writeText(number);
    setToastMessage(`Number ${number} copied to clipboard!`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  if (showDialer) {
    return <Dialer profile={profile} onBack={() => setShowDialer(false)} onCall={onStartCall} />;
  }

  return (
    <div className="flex-1 flex flex-col bg-slate-50 overflow-y-auto relative z-10">
      
      {/* Top Banner */}
      <div className="bg-gradient-to-b from-[#FFC107] to-[#FFC107]/90 px-6 pt-6 pb-12 rounded-b-[40px] shadow-sm relative z-10">
        <div className="flex items-center justify-between mb-2">
          <h1 className="text-3xl font-black text-[#1A1A1A] tracking-tight">CallConnect</h1>
          <div className="w-12 h-12 rounded-full border-[3px] border-white/40 overflow-hidden bg-white/20">
            <img src={profile.photoURL || `https://ui-avatars.com/api/?name=${profile.displayName}`} alt="User" className="w-full h-full object-cover" />
          </div>
        </div>
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#1A1A1A]/10 text-[#1A1A1A] text-xs font-bold rounded-full backdrop-blur-sm">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse border border-white/20"></div>
          {profile.isOnline ? "Online & Ready" : "Connecting..."}
        </div>
      </div>

      {/* Main Content (Shifted up to overlap banner) */}
      <div className="px-4 -mt-6 relative z-20 pb-8 flex-1">
        
        {/* Floating Action / Start Call Card */}
        <div 
          onClick={() => setShowDialer(true)}
          className="bg-[#1A1A1A] rounded-3xl p-6 shadow-xl mb-6 flex items-center justify-between cursor-pointer active:scale-95 transition-transform overflow-hidden relative group"
        >
          <div className="absolute -right-4 -top-4 w-24 h-24 bg-[#FFC107]/20 rounded-full blur-xl group-hover:bg-[#FFC107]/30 transition-colors"></div>
          <div>
            <h2 className="text-white font-bold text-xl mb-1">Make a Call</h2>
            <p className="text-slate-400 text-sm">Enter 8-digit virtual number</p>
          </div>
          <div className="w-14 h-14 bg-[#FFC107] rounded-full flex items-center justify-center shadow-lg shadow-[#FFC107]/30">
            <Phone className="w-6 h-6 text-[#1A1A1A] fill-[#1A1A1A]" />
          </div>
        </div>

        {/* Virtual Numbers Section */}
        <div className="bg-white/80 backdrop-blur-md rounded-3xl p-5 shadow-sm border border-slate-100 mb-6">
          <h3 className="font-bold text-[#1A1A1A] flex items-center gap-2 mb-4">
            <div className="w-8 h-8 bg-[#FFC107]/20 rounded-lg flex items-center justify-center">
              <Hash className="w-4 h-4 text-[#FFA000]" />
            </div>
            My Virtual Numbers
          </h3>
          
          {profile.virtualNumbers && profile.virtualNumbers.length > 0 ? (
            <div className="space-y-3">
              {profile.virtualNumbers.map((vn: VirtualNumber, idx: number) => (
                <div key={idx} className="bg-slate-50 border border-slate-100 rounded-2xl p-4 flex items-center justify-between hover:border-[#FFC107]/50 hover:bg-[#FFC107]/5 transition-all">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`text-[10px] uppercase tracking-widest font-black px-2 py-0.5 rounded-md ${vn.type === 'primary' ? 'bg-[#FFC107] text-[#1A1A1A]' : 'bg-slate-200 text-slate-600'}`}>
                        {vn.type}
                      </span>
                    </div>
                    <p className="font-mono text-2xl text-[#1A1A1A] tracking-wider font-bold">
                      {vn.number.slice(0, 4)}<span className="text-slate-300">-</span>{vn.number.slice(4)}
                    </p>
                  </div>
                  
                  <button 
                    onClick={() => copyToClipboard(vn.number)}
                    className="w-12 h-12 bg-white rounded-xl shadow-sm border border-slate-100 text-slate-400 hover:text-[#FFA000] flex items-center justify-center transition-colors active:scale-95"
                  >
                    <Copy className="w-5 h-5" />
                  </button>
                </div>
              ))}
            </div>
          ) : (
             <div className="p-4 bg-slate-50 border border-slate-100 rounded-xl text-slate-500 text-center text-sm font-medium">
               No virtual numbers assigned.
             </div>
          )}
        </div>

      </div>
      
      {/* Toast */}
      <div className={`absolute top-6 left-1/2 -translate-x-1/2 bg-[#1A1A1A] text-white px-6 py-3 rounded-full flex items-center gap-3 shadow-xl transition-all duration-300 z-50 ${toastMessage ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4 pointer-events-none'}`}>
        <CheckCircle2 className="w-5 h-5 text-[#FFC107]" />
        <span className="font-medium text-sm">{toastMessage}</span>
      </div>
    </div>
  );
}
