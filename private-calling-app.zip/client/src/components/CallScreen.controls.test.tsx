// @vitest-environment jsdom
import React from "react";
import { act, cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import CallScreen from "./CallScreen";
import { onSnapshot } from "firebase/firestore";

const mockState = vi.hoisted(() => ({
  listener: undefined as ((snapshot: any) => void) | undefined,
  mediaState: undefined as ((state: string) => void) | undefined,
  setMuted: vi.fn(),
  sendDtmf: vi.fn(() => true),
  close: vi.fn(),
  cleanup: vi.fn(),
  acceptIncoming: vi.fn(() => Promise.resolve()),
  transition: vi.fn(() => Promise.resolve({ success: true })),
}));

vi.mock("../firebase", () => ({ db: {} }));
vi.mock("firebase/firestore", () => ({ doc: vi.fn(() => ({})), onSnapshot: vi.fn((_ref, listener) => { mockState.listener = listener; return () => undefined; }) }));
vi.mock("../services/secureApi", () => ({ secureApi: { contacts: { list: { query: vi.fn(() => Promise.resolve([])) } }, calls: { transition: { mutate: mockState.transition } } } }));
vi.mock("../services/callMedia", () => ({
  CallMediaSession: class {
    constructor(_callId: string, _incoming: boolean, onState: (state: string) => void) { mockState.mediaState = onState; }
    acceptIncoming = mockState.acceptIncoming;
    beginOutgoing = vi.fn();
    setMuted = mockState.setMuted;
    sendDtmf = mockState.sendDtmf;
    close = mockState.close;
    cleanup = mockState.cleanup;
  },
}));
vi.mock("../utils/haptics", () => ({ hapticFeedback: { light: vi.fn(), medium: vi.fn() } }));
vi.mock("./CachedImage", () => ({ default: () => null }));

beforeEach(() => {
  vi.useFakeTimers();
  vi.clearAllMocks();
  mockState.listener = undefined;
  mockState.mediaState = undefined;
  Object.defineProperty(HTMLMediaElement.prototype, "setSinkId", { configurable: true, value: vi.fn(() => Promise.resolve()) });
  Object.defineProperty(navigator, "mediaDevices", { configurable: true, value: { selectAudioOutput: vi.fn(() => Promise.resolve({ deviceId: "speaker-device" })) } });
});

afterEach(() => { cleanup(); vi.useRealTimers(); });

async function connectIncomingCall() {
  render(<CallScreen callId="active-call" targetNumber="12345678" isIncoming onEndCall={vi.fn()} />);
  act(() => mockState.listener?.({ exists: () => true, data: () => ({ status: "ringing", offer: { type: "offer", sdp: "offer" } }) }));
  fireEvent.click(screen.getByRole("button", { name: "Accept call" }));
  fireEvent.click(screen.getByRole("button", { name: "Accept & connect" }));
  await act(async () => undefined);
  act(() => mockState.mediaState?.("connected"));
}

describe("real in-call controls", () => {
  it("renders the contained incoming interface and declines through the real terminal transition", async () => {
    render(<CallScreen callId="incoming-call" targetNumber="12345678" isIncoming onEndCall={vi.fn()} />);
    expect(screen.getByRole("region", { name: "Call screen" })).toBeTruthy();
    expect(screen.getByText("Incoming call")).toBeTruthy();
    expect(screen.getAllByText("1234-5678")).toHaveLength(2);
    expect(screen.getByRole("button", { name: "Accept call" })).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "Decline call" }));
    await act(async () => undefined);
    expect(mockState.transition).toHaveBeenCalledWith({ callId: "incoming-call", status: "rejected" });
    expect(screen.getByText("Call declined")).toBeTruthy();
  });

  it("renders the contained outgoing interface and cancels through the real terminal transition", async () => {
    render(<CallScreen callId="outgoing-call" targetNumber="12345678" onEndCall={vi.fn()} />);
    expect(screen.getByText("Calling…")).toBeTruthy();
    expect(screen.getByRole("dialog", { name: "Microphone permission" })).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "Cancel" }));
    await act(async () => undefined);
    expect(mockState.transition).toHaveBeenCalledWith({ callId: "outgoing-call", status: "cancelled" });
    expect(screen.getByText("Call cancelled")).toBeTruthy();
  });

  it("wires mute, speaker routing, compact keypad DTMF, and end call to active call state", async () => {
    await connectIncomingCall();

    fireEvent.click(screen.getByRole("button", { name: "Mute microphone" }));
    expect(mockState.setMuted).toHaveBeenCalledWith(true);
    expect(screen.getByRole("button", { name: "Unmute microphone" }).getAttribute("aria-pressed")).toBe("true");

    fireEvent.click(screen.getByRole("button", { name: "Toggle speaker output" }));
    await act(async () => undefined);
    expect((HTMLMediaElement.prototype as any).setSinkId).toHaveBeenCalledWith("speaker-device");
    expect(screen.getByRole("button", { name: "Toggle speaker output" }).getAttribute("aria-pressed")).toBe("true");

    fireEvent.click(screen.getByRole("button", { name: "Open in-call keypad" }));
    expect(screen.getByRole("dialog", { name: "In-call keypad" })).toBeTruthy();
    expect(screen.getAllByRole("button", { name: /Send tone/ })).toHaveLength(12);
    fireEvent.click(screen.getByRole("button", { name: "Send tone 5" }));
    expect(mockState.sendDtmf).toHaveBeenCalledWith("5");
    expect(screen.getByText("5", { selector: "p" })).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "Dismiss in-call keypad" }));
    expect(screen.getByRole("button", { name: "Open in-call keypad" }).getAttribute("aria-pressed")).toBe("false");

    fireEvent.click(screen.getByRole("button", { name: "End call" }));
    await act(async () => undefined);
    expect(mockState.close).toHaveBeenCalledWith("ended");
    expect(screen.getByText("Call ended")).toBeTruthy();
  });
});
