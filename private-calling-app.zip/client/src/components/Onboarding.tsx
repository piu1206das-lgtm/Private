import React from "react";
import { useState, useRef } from "react";
import { User as FirebaseUser } from "firebase/auth";
import { doc, getDoc, setDoc, serverTimestamp } from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { db, storage } from "../firebase";
import { UserProfile, VirtualNumber } from "../types";
import { Camera, Upload, AlertCircle, CheckCircle2 } from "lucide-react";
import { assignUniqueNumber } from "../services/numberService";
import { hashPin } from "../utils/crypto";

interface OnboardingProps {
  user: FirebaseUser;
  onComplete: (profile: UserProfile) => void;
}

export default function Onboarding({ user, onComplete }: OnboardingProps) {
  const [displayName, setDisplayName] = useState(user.displayName || "");
  const [pin, setPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string>(user.photoURL || "");
  
  const [isLoading, setIsLoading] = useState(false);
  const [loadingText, setLoadingText] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [showSuccessToast, setShowSuccessToast] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setPhotoFile(file);
      setPhotoPreview(URL.createObjectURL(file));
    }
  };

  const handlePinChange = (e: React.ChangeEvent<HTMLInputElement>, setter: (val: string) => void) => {
    const val = e.target.value.replace(/[^0-9]/g, "").slice(0, 4);
    setter(val);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading) return;
    setError(null);

    // Validation
    if (!displayName.trim()) {
      setError("Display Name is required");
      return;
    }
    if (pin.length !== 4) {
      setError("PIN must be exactly 4 digits");
      return;
    }
    if (pin !== confirmPin) {
      setError("PINs do not match");
      return;
    }

    setIsLoading(true);

    try {
      const existingProfile = await getDoc(doc(db, "users", user.uid));
      if (existingProfile.exists() && existingProfile.data().isOnboarded) {
        onComplete(existingProfile.data() as UserProfile);
        return;
      }

      let finalPhotoURL = user.photoURL || "";

      // Upload new photo if selected
      if (photoFile) {
        setLoadingText("Uploading profile photo...");
        const fileExt = photoFile.name.split(".").pop();
        const storageRef = ref(storage, `users/${user.uid}/profile_${Date.now()}.${fileExt}`);
        await uploadBytes(storageRef, photoFile);
        finalPhotoURL = await getDownloadURL(storageRef);
      }

      setLoadingText("Securing your master PIN...");
      // Hash PIN securely
      const pinHash = await hashPin(pin);

      setLoadingText("Generating unique virtual numbers...");
      // Assign unique numbers
      const primaryNum = await assignUniqueNumber(user.uid);
      const secondaryNum = await assignUniqueNumber(user.uid);

      const virtualNumbers: VirtualNumber[] = [
        { number: primaryNum, type: "primary", status: "active", createdAt: Date.now() },
        { number: secondaryNum, type: "secondary", status: "active", createdAt: Date.now() }
      ];

      setLoadingText("Saving profile...");
      const profileData: UserProfile = {
        uid: user.uid,
        displayName: displayName.trim(),
        email: user.email || "",
        photoURL: finalPhotoURL,
        pinHash,
        virtualNumbers,
        createdAt: Date.now(), // Fallback for local state, firestore uses serverTimestamp
        isOnboarded: true
      };

      // Save to Firestore
      await setDoc(doc(db, "users", user.uid), {
        ...profileData,
        createdAt: serverTimestamp()
      });

      // Show success toast briefly before completing
      setShowSuccessToast(true);
      setTimeout(() => {
        onComplete(profileData);
      }, 2000);

    } catch (err: any) {
      console.error("Error saving profile:", err);
      setError(err.message || "Failed to save profile. Please try again.");
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 py-12 px-4 sm:px-6 lg:px-8 relative">
      {/* Success Toast */}
      <div className={`fixed top-6 left-1/2 -translate-x-1/2 bg-slate-900 text-white px-6 py-3 rounded-full flex items-center gap-3 shadow-lg shadow-slate-900/20 transition-all duration-300 z-50 ${showSuccessToast ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4 pointer-events-none'}`}>
        <CheckCircle2 className="w-5 h-5 text-green-400" />
        <span className="font-medium">Your virtual numbers have been generated!</span>
      </div>

      <div className="max-w-xl mx-auto bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="px-8 py-6 border-b border-slate-100">
          <h2 className="text-2xl font-bold text-slate-900">Complete Your Profile</h2>
          <p className="text-slate-500 mt-1">Setup your caller identity and secure your account.</p>
        </div>

        <form onSubmit={handleSubmit} className="px-8 py-6 space-y-6">
          {error && (
            <div className="p-4 bg-red-50 border border-red-100 rounded-xl flex items-start gap-3 text-red-600">
              <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
              <p className="text-sm">{error}</p>
            </div>
          )}

          {/* Profile Picture Upload */}
          <div className="flex flex-col items-center">
            <div className="relative group cursor-pointer" onClick={() => fileInputRef.current?.click()}>
              {photoPreview ? (
                <img src={photoPreview} alt="Profile Preview" className="w-24 h-24 rounded-full object-cover ring-4 ring-slate-50" />
              ) : (
                <div className="w-24 h-24 rounded-full bg-slate-100 flex items-center justify-center ring-4 ring-slate-50">
                  <Camera className="w-8 h-8 text-slate-400" />
                </div>
              )}
              <div className="absolute inset-0 bg-black/40 rounded-full opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <Upload className="w-6 h-6 text-white" />
              </div>
            </div>
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handlePhotoChange} 
              accept="image/*" 
              className="hidden" 
            />
            <p className="text-sm text-slate-500 mt-2 font-medium">Upload Photo</p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Display Name <span className="text-red-500">*</span></label>
              <input 
                type="text" 
                required
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
                placeholder="John Doe"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">4-Digit PIN <span className="text-red-500">*</span></label>
                <input 
                  type="password" 
                  required
                  inputMode="numeric"
                  value={pin}
                  onChange={(e) => handlePinChange(e, setPin)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all text-center tracking-widest text-lg"
                  placeholder="••••"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Confirm PIN <span className="text-red-500">*</span></label>
                <input 
                  type="password" 
                  required
                  inputMode="numeric"
                  value={confirmPin}
                  onChange={(e) => handlePinChange(e, setConfirmPin)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all text-center tracking-widest text-lg"
                  placeholder="••••"
                />
              </div>
            </div>
            <p className="text-xs text-slate-500">This PIN acts as your master password for calling functions.</p>
          </div>

          <button
            type="submit"
            disabled={isLoading || showSuccessToast}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white px-6 py-3.5 rounded-xl font-medium transition-all active:scale-[0.98] disabled:opacity-70 disabled:pointer-events-none flex flex-col justify-center items-center h-14"
          >
            {isLoading ? (
              <>
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mb-1"></div>
                <span className="text-[10px] font-normal tracking-wide uppercase opacity-80">{loadingText}</span>
              </>
            ) : (
              <span>Complete Setup</span>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
