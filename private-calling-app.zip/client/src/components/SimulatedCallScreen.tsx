import React, { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { Check, Grid3X3, Mic, MicOff, Phone, PhoneIncoming, PhoneOff, PhoneOutgoing, UserRound, Volume2, VolumeX, X } from "lucide-react";
import { hapticFeedback } from "../utils/haptics";

export type SimulatedCallDirection = "outgoing" | "incoming";
export type SimulatedCallResult = { durationSeconds: number; direction: SimulatedCallDirection; endedAt: number };

type SimulatedCallScreenProps = {
  number: string;
  contactName?: string;
  direction?: SimulatedCallDirection;
  onEnd: (result: SimulatedCallResult) => void;
};

const keypadTones = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#"];

function formatNumber(number: string) {
  return number.length === 7 ? `${number.slice(0, 3)}-${number.slice(3)}` : `${number.slice(0, 4)}-${number.slice(4)}`;
}

function formatDuration(seconds: number) {
  return `${Math.floor(seconds / 60).toString().padStart(2, "0")}:${(seconds % 60).toString().padStart(2, "0")}`;
}

function initialsFor(identity: string) {
  const initials = identity.trim().split(/\s+/).map(part => part[0]).filter(Boolean).join("").slice(0, 2);
  return initials ? initials.toUpperCase() : "?";
}

function SimulationControl({ label, active, onClick, icon }: { label: string; active: boolean; onClick: () => void; icon: React.ReactNode }) {
  return <div className="flex min-w-0 flex-1 flex-col items-center gap-2"><motion.button type="button" whileTap={{ scale: 0.94 }} onClick={onClick} aria-label={label} aria-pressed={active} className={`ripple flex h-14 w-14 items-center justify-center rounded-[20px] border transition-colors ${active ? "border-amber-300 bg-amber-400 text-slate-950 shadow-lg shadow-amber-500/25" : "border-white/10 bg-white/10 text-white active:bg-white/20"}`}>{icon}</motion.button><span className={`truncate text-[11px] font-medium ${active ? "text-amber-200" : "text-slate-300"}`}>{label}</span></div>;
}

export default function SimulatedCallScreen({ number, contactName, direction = "outgoing", onEnd }: SimulatedCallScreenProps) {
  const [state, setState] = useState<"incoming" | "calling" | "connecting" | "connected">(direction === "incoming" ? "incoming" : "calling");
  const [duration, setDuration] = useState(0);
  const [muted, setMuted] = useState(false);
  const [speaker, setSpeaker] = useState(false);
  const [showKeypad, setShowKeypad] = useState(false);
  const [sentTones, setSentTones] = useState("");

  const status = useMemo(() => ({ incoming: "Incoming simulated call", calling: "Calling…", connecting: "Connecting…", connected: formatDuration(duration) })[state], [duration, state]);
  const identity = contactName || formatNumber(number);
  const connected = state === "connected";

  useEffect(() => {
    if (state !== "calling" && state !== "connecting") return;
    const timer = window.setTimeout(() => setState(state === "calling" ? "connecting" : "connected"), state === "calling" ? 850 : 950);
    return () => window.clearTimeout(timer);
  }, [state]);

  useEffect(() => {
    if (!connected) return;
    const timer = window.setInterval(() => setDuration(value => value + 1), 1000);
    return () => window.clearInterval(timer);
  }, [connected]);

  useEffect(() => {
    if (!connected) setShowKeypad(false);
  }, [connected]);

  const acceptIncoming = () => {
    hapticFeedback.success();
    setState("connecting");
  };

  const endCall = () => {
    hapticFeedback.medium();
    onEnd({ durationSeconds: duration, direction, endedAt: Date.now() });
  };

  const sendTone = (tone: string) => {
    setSentTones(current => `${current}${tone}`.slice(-16));
    hapticFeedback.light();
  };

  return <motion.section initial={{ opacity: 0, scale: 0.985 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.985 }} transition={{ type: "spring", stiffness: 360, damping: 34 }} className="absolute inset-0 z-[70] flex min-h-0 flex-col overflow-hidden bg-[#111827] text-white" data-testid="simulated-call-screen" aria-label="Simulated call screen">
    <div aria-hidden="true" className="pointer-events-none absolute -right-20 -top-24 h-80 w-80 rounded-full bg-amber-400/10 blur-3xl" />
    <div aria-hidden="true" className="pointer-events-none absolute -bottom-20 -left-24 h-72 w-72 rounded-full bg-orange-500/10 blur-3xl" />
    <header className="relative z-10 flex shrink-0 items-center justify-between px-5 pb-3 pt-[max(1.25rem,env(safe-area-inset-top,0px))]"><span className="inline-flex items-center gap-2 rounded-full border border-amber-300/25 bg-amber-400/10 px-3 py-1.5 text-[10px] font-bold tracking-[0.14em] text-amber-200">IN-APP SIMULATION</span><span className="text-xs font-medium text-slate-400">Demo calling flow</span></header>
    <main className="relative z-10 flex min-h-0 flex-1 flex-col items-center justify-center px-6 pb-4 pt-1 text-center">
      <div className="relative"><span aria-hidden="true" className="absolute -inset-4 rounded-full border border-white/10" /><span aria-hidden="true" className="absolute -inset-8 rounded-full border border-white/[0.04]" /><div className="relative flex h-32 w-32 items-center justify-center rounded-[44px] border border-white/10 bg-gradient-to-br from-slate-600 to-slate-800 shadow-2xl shadow-black/30"><span className="text-[38px] font-semibold tracking-tight text-white">{initialsFor(identity)}</span></div></div>
      <div className="mt-10 max-w-full"><h1 className="truncate text-[30px] font-semibold leading-tight tracking-tight text-white">{identity}</h1><p className="mt-2 font-mono text-[15px] tracking-[0.16em] text-slate-400">{formatNumber(number)}</p></div>
      <div className="mt-6 inline-flex min-h-8 items-center gap-2 rounded-full border border-white/10 bg-white/[0.08] px-3.5 py-1.5 text-[13px] font-semibold text-slate-100">{connected ? <Check className="h-3.5 w-3.5 text-emerald-300" /> : state === "incoming" ? <PhoneIncoming className="h-3.5 w-3.5" /> : <PhoneOutgoing className="h-3.5 w-3.5" />}<span>{status}</span></div>
      {connected && <p className="mt-2 text-xs font-medium text-emerald-300">Simulation connected</p>}
      {state === "connecting" && <p className="mt-3 text-[13px] text-slate-400">Connecting the simulated call…</p>}
    </main>
    <footer className="relative z-10 shrink-0 border-t border-white/[0.07] bg-slate-950/35 px-6 pb-[max(1.25rem,env(safe-area-inset-bottom,0px))] pt-5 backdrop-blur-sm">
      {state === "incoming" ? <div className="mx-auto flex max-w-sm items-start justify-around gap-8"><div className="flex flex-col items-center gap-2"><motion.button type="button" whileTap={{ scale: 0.94 }} onClick={endCall} aria-label="Decline simulated call" className="ripple flex h-16 w-16 items-center justify-center rounded-[22px] bg-red-500 text-white shadow-lg shadow-red-500/25 active:bg-red-600"><PhoneOff className="h-7 w-7" /></motion.button><span className="text-xs font-medium text-slate-300">Decline</span></div><div className="flex flex-col items-center gap-2"><motion.button type="button" whileTap={{ scale: 0.94 }} onClick={acceptIncoming} aria-label="Accept simulated call" className="ripple flex h-16 w-16 items-center justify-center rounded-[22px] bg-amber-400 text-slate-950 shadow-lg shadow-amber-500/25 active:bg-amber-300"><Phone className="h-7 w-7 fill-current" /></motion.button><span className="text-xs font-medium text-amber-200">Accept</span></div></div> : connected ? <div className="mx-auto flex w-full max-w-sm items-start justify-between gap-2"><SimulationControl label="Mute" active={muted} onClick={() => { setMuted(value => !value); hapticFeedback.light(); }} icon={muted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />} /><SimulationControl label="Speaker" active={speaker} onClick={() => { setSpeaker(value => !value); hapticFeedback.light(); }} icon={speaker ? <Volume2 className="h-5 w-5" /> : <VolumeX className="h-5 w-5" />} /><SimulationControl label="Keypad" active={showKeypad} onClick={() => { setShowKeypad(value => !value); hapticFeedback.light(); }} icon={<Grid3X3 className="h-5 w-5" />} /><div className="flex min-w-0 flex-1 flex-col items-center gap-2"><motion.button type="button" whileTap={{ scale: 0.94 }} onClick={endCall} aria-label="End simulated call" className="ripple flex h-14 w-14 items-center justify-center rounded-[20px] bg-red-500 text-white shadow-lg shadow-red-500/25 active:bg-red-600"><PhoneOff className="h-5 w-5" /></motion.button><span className="text-[11px] font-medium text-slate-300">End</span></div></div> : <div className="flex flex-col items-center gap-2"><motion.button type="button" whileTap={{ scale: 0.94 }} onClick={endCall} aria-label="Cancel simulated call" className="ripple flex h-16 w-16 items-center justify-center rounded-[22px] bg-red-500 text-white shadow-lg shadow-red-500/25 active:bg-red-600"><PhoneOff className="h-7 w-7" /></motion.button><span className="text-xs font-medium text-slate-300">Cancel</span></div>}
    </footer>
    <AnimatePresence>{showKeypad && connected && <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 z-[80] flex items-end bg-black/50 backdrop-blur-[1px]" onClick={() => setShowKeypad(false)}><motion.section role="dialog" aria-label="Simulated in-call keypad" initial={{ y: 300 }} animate={{ y: 0 }} exit={{ y: 300 }} transition={{ type: "spring", stiffness: 360, damping: 32 }} className="w-full rounded-t-[32px] border-t border-white/10 bg-slate-900 px-6 pb-[max(1.5rem,env(safe-area-inset-bottom,0px))] pt-3 shadow-2xl" onClick={(event) => event.stopPropagation()}><div className="mx-auto h-1 w-10 rounded-full bg-slate-600" /><div className="mb-4 mt-3 flex items-start justify-between gap-3"><div className="text-left"><h2 className="text-[16px] font-semibold text-white">In-call keypad</h2><p aria-label="Sent simulated keypad tones" className="mt-1 h-4 font-mono text-[12px] tracking-[0.22em] text-amber-200">{sentTones || " "}</p></div><button type="button" onClick={() => setShowKeypad(false)} aria-label="Dismiss simulated in-call keypad" className="ripple flex h-10 w-10 items-center justify-center rounded-full text-slate-300 active:bg-white/10"><X className="h-5 w-5" /></button></div><div className="mx-auto grid max-w-[272px] grid-cols-3 gap-x-5 gap-y-1">{keypadTones.map(tone => <motion.button type="button" whileTap={{ scale: 0.9 }} key={tone} onClick={() => sendTone(tone)} aria-label={`Send simulated tone ${tone}`} className="ripple h-12 rounded-2xl text-[26px] font-medium leading-none text-white active:bg-white/10">{tone}</motion.button>)}</div></motion.section></motion.div>}</AnimatePresence>
  </motion.section>;
}
