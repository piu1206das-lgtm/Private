import { User as FirebaseUser, signOut } from "firebase/auth";
import { UserProfile } from "../types";
import { User, Lock, Volume2, LogOut, ChevronRight } from "lucide-react";
import { auth, db } from "../firebase";
import { doc, updateDoc } from "firebase/firestore";

interface SettingsProps {
  user: FirebaseUser;
  profile: UserProfile;
  onOpenEditProfile: () => void;
  onOpenChangePin: () => void;
  onOpenAudioSettings: () => void;
}

export default function Settings({ user, profile, onOpenEditProfile, onOpenChangePin, onOpenAudioSettings }: SettingsProps) {
  const handleLogout = async () => {
    try {
      // Best effort set offline
      if (profile) {
        await updateDoc(doc(db, "users", profile.uid), { isOnline: false });
      }
      if (auth) {
        await signOut(auth);
      }
    } catch (error) {
      console.error("Error signing out:", error);
    }
  };

  const menuItems = [
    { icon: User, label: "Edit Profile", onClick: onOpenEditProfile, color: "bg-blue-100 text-blue-600" },
    { icon: Lock, label: "Change PIN", onClick: onOpenChangePin, color: "bg-purple-100 text-purple-600" },
    { icon: Volume2, label: "Audio & Video", onClick: onOpenAudioSettings, color: "bg-green-100 text-green-600" },
  ];

  return (
    <div className="flex-1 w-full flex flex-col bg-slate-50">
      <div className="bg-[#FFC107] px-6 pt-6 pb-12 rounded-b-[40px] shadow-sm relative z-10">
        <h1 className="text-3xl font-black text-[#1A1A1A]">Settings</h1>
        <p className="text-[#1A1A1A]/70 font-medium mt-1">Manage your account and preferences.</p>
      </div>

      <div className="px-4 -mt-6 relative z-20 flex-1 overflow-y-auto">
        <div className="bg-white rounded-3xl p-2 shadow-sm border border-slate-100 mb-6">
          <div className="p-4 flex items-center gap-4">
            <img src={profile.photoURL || `https://ui-avatars.com/api/?name=${profile.displayName}&background=random`} alt="Profile" className="w-16 h-16 rounded-2xl object-cover shadow-sm" />
            <div>
              <h2 className="font-bold text-lg text-[#1A1A1A]">{profile.displayName}</h2>
              <p className="text-sm text-slate-500">{user.email}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-3xl p-2 shadow-sm border border-slate-100 mb-6 space-y-1">
          {menuItems.map((item, idx) => {
            const Icon = item.icon;
            return (
              <button key={idx} onClick={item.onClick} className="w-full flex items-center justify-between p-4 hover:bg-slate-50 rounded-2xl transition-colors active:scale-[0.98]">
                <div className="flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${item.color}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="font-semibold text-[#1A1A1A]">{item.label}</span>
                </div>
                <ChevronRight className="w-5 h-5 text-slate-300" />
              </button>
            );
          })}
        </div>

        <button 
          onClick={handleLogout}
          className="w-full flex items-center justify-center gap-2 p-4 bg-red-50 text-red-600 hover:bg-red-100 rounded-3xl font-bold transition-all active:scale-[0.98] mb-8"
        >
          <LogOut className="w-5 h-5" />
          Log Out
        </button>
      </div>
    </div>
  );
}
