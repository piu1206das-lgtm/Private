/**
 * Style reminder — Android-native private calling: keep the amber signal accent,
 * quiet slate privacy backdrop, compact mobile card, and direct functional copy.
 */
import { signInWithPopup } from "firebase/auth";
import { auth, googleProvider } from "../firebase";
import { PhoneCall } from "lucide-react";
import { useState } from "react";

const LOGO_URL = "/manus-storage/private-calling-logo_dae2ba7e.png";
const LOGIN_ART_URL = "/manus-storage/private-calling-login-art_b0d23867.png";

export default function Login() {
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [logoAvailable, setLogoAvailable] = useState(true);

  const handleGoogleSignIn = async () => {
    if (!auth) {
      setError("Firebase is not configured for this app.");
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err: any) {
      console.error("Error signing in with Google:", err);
      if (err.code === "auth/unauthorized-domain") {
        setError(`Add ${window.location.hostname} to Firebase Authentication → Settings → Authorized domains, then refresh this page and try again.`);
      } else if (err.code === "auth/popup-closed-by-user") {
        setError("Sign-in was cancelled. You can try again when ready.");
      } else {
        setError(err.message || "Unable to sign in. Please try again.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 relative overflow-hidden">
      <img src={LOGIN_ART_URL} alt="" className="absolute inset-0 w-full h-full object-cover opacity-60" aria-hidden="true" />
      <div className="absolute inset-0 bg-slate-950/50" aria-hidden="true" />
      <main className="w-full max-w-md bg-white/95 backdrop-blur-xl rounded-2xl shadow-2xl overflow-hidden border border-white/30 relative z-10">
        <div className="px-8 pt-10 pb-8 text-center">
          <div className="mx-auto w-16 h-16 bg-[#FFC107] rounded-2xl flex items-center justify-center mb-6 shadow-lg shadow-amber-500/30 p-2.5">
            {logoAvailable ? (
              <img
                src={LOGO_URL}
                alt="Private Calling App"
                className="w-full h-full object-contain"
                onError={() => setLogoAvailable(false)}
              />
            ) : (
              <PhoneCall className="w-8 h-8 text-slate-950" aria-label="Private Calling App" />
            )}
          </div>
          <h1 className="text-2xl font-bold text-slate-900 mb-2">Private Calling</h1>
          <p className="text-slate-500 mb-8">Use your private virtual calling identity.</p>

          {error && <div className="mb-6 p-4 bg-red-50 border border-red-100 text-red-700 rounded-xl text-sm text-left" role="alert">{error}</div>}

          <button
            onClick={handleGoogleSignIn}
            disabled={isLoading}
            className="w-full flex items-center justify-center gap-3 bg-white border border-slate-200 hover:border-amber-400 hover:bg-amber-50 text-slate-700 px-6 py-3.5 rounded-xl font-medium transition-all active:scale-[0.98] disabled:opacity-70 disabled:pointer-events-none focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-500"
          >
            {isLoading ? (
              <div className="w-5 h-5 border-2 border-slate-300 border-t-amber-500 rounded-full animate-spin" aria-label="Signing in" />
            ) : (
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
              </svg>
            )}
            <span>{isLoading ? "Signing in…" : "Sign in with Google"}</span>
          </button>
        </div>
        <div className="bg-slate-50 px-8 py-4 border-t border-slate-100 text-center">
          <p className="text-xs text-slate-500">Secure authentication provided by Firebase</p>
        </div>
      </main>
    </div>
  );
}
