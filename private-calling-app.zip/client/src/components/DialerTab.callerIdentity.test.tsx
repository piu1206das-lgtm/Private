// @vitest-environment jsdom
import React from "react";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import DialerTab from "./DialerTab";

vi.mock("../utils/haptics", () => ({ hapticFeedback: { light: vi.fn(), heavy: vi.fn() } }));
vi.mock("./CachedImage", () => ({ default: () => null }));

afterEach(cleanup);

describe("Dialer caller identity", () => {
  it("uses the selected active temporary identity for a real seven-digit call without a PIN prompt", async () => {
    const onCall = vi.fn().mockResolvedValue(undefined);
    const { container } = render(<DialerTab
      profile={{ uid: "owner", displayName: "Owner", photoURL: "", virtualNumbers: [{ number: "87654321", type: "primary", status: "active" }] } as any}
      onCall={onCall}
      onGoToProfile={vi.fn()}
      callerIdentities={[{ number: "87654321", type: "permanent" }, { number: "7000001", type: "temporary", expiresAt: Date.now() + 60_000 }]}
    />);

    fireEvent.click(screen.getByRole("button", { name: "Change calling number" }));
    expect(screen.getByText(/Calling from temporary/)).toBeTruthy();
    const keypad = container.querySelectorAll(".grid button");
    for (const button of Array.from(keypad).slice(0, 7)) fireEvent.click(button);
    fireEvent.click(container.querySelector("button.w-14.h-14.bg-amber-500")!);
    await Promise.resolve();
    expect(onCall).toHaveBeenCalledWith("1234567", "7000001");
    expect(screen.queryByText("Enter Security PIN")).toBeNull();
  });
});
