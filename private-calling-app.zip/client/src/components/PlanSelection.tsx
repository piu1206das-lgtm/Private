import React, { useEffect, useRef, useState } from "react";
import { UserProfile } from "../types";
import {
  ArrowLeft, Search, MoreVertical,
  Check, ChevronRight, Music, Clock3, History, RotateCcw, CircleHelp, X,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { pageTransition, tapScale } from "../utils/animations";
import { hapticFeedback } from "../utils/haptics";
import VipNumberSearch from "./VipNumberSearch";
import { secureApi } from "../services/secureApi";
import { AudioTrimmer } from "./HelloTuneTab";

const RECHARGE_FRIEND_ICON_SRC = "/manus-storage/recharge-friend-icon_75c0f152.png";
const VIP_NUMBERS_ICON_SRC = "/manus-storage/vip-numbers-crown-icon_ac02359c.png";

interface PlanSelectionProps {
  profile: UserProfile;
  onClose: () => void;
  onOpenHelloTune: () => void;
}

type Category = "Recommended" | "Temporary" | "Long Validity" | "HelloTune";
type Plan = {
  planId: string;
  planName: string;
  price: number;
  validityValue: number;
  validityUnit: "hours" | "days";
  validity: string;
  benefits: readonly string[];
  categories: readonly Category[];
  label?: string;
  kind: "permanent" | "temporary-number";
  numberEntitlement: number;
  temporaryNumberEntitlement: number;
};

type Entitlement = {
  entitlementId: string;
  planId: string;
  planName: string;
  price: number;
  validity: string;
  benefits: readonly string[];
  status: "active" | "upcoming" | "expired";
  entitlementStart: number;
  entitlementExpiry: number;
};

type RechargeStatus = {
  serverTime: number;
  currentPlan: Entitlement | null;
  upcomingPlans: Entitlement[];
  activeTemporaryEntitlements: Array<Entitlement & { temporaryNumber: string }>;
  latestSuccessfulRecharge: { purchaseId: string; planId: string; planName: string; price: number; validity: string; fulfilledAt: number } | null;
};
type HelloTunePack = { id: string; name: string; price: number; validity: string };
type PreparedHelloTuneClip = { name: string; url: string; storagePath: string; clipStartSeconds: number; clipEndSeconds: number; clipDurationSeconds: number };
type PurchaseHistoryEntry = { purchaseId: string; type: "recharge" | "hellotune"; planName: string; price: number | null; validity: string | null; status: string; createdAt: number; fulfilledAt: number | null };

type FriendRechargeStage = "input" | "verify" | "confirm" | "payment-pending" | null;

const CATEGORIES: Array<Category | "All Plans"> = ["All Plans", "Recommended", "Temporary", "Long Validity", "HelloTune"];

function formatExpiry(timestamp: number) {
  return new Date(timestamp).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
}

export function RechargePlanCard({ plan, onSelect }: { plan: Plan; onSelect: () => void }) {
  return <motion.button whileTap={{ scale: 0.985 }} onClick={onSelect} className="w-full rounded-[18px] border border-slate-200/80 bg-white p-4 text-left shadow-[0_1px_2px_rgba(15,23,42,0.05)] active:bg-slate-50 ripple">
    <div className="flex items-start justify-between gap-4">
      <div className="min-w-0 flex-1">
        {plan.label && <span className="mb-1.5 inline-flex rounded-md bg-amber-500 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-white">{plan.label}</span>}
        <h3 className="truncate text-[16px] font-semibold leading-5 text-slate-900">{plan.planName}</h3>
        <div className="mt-3 flex flex-col gap-1.5">{plan.benefits.slice(0, 2).map((benefit, index) => <div key={index} className="flex min-w-0 items-start gap-2"><Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-600" /><span className="line-clamp-1 text-[13px] leading-5 text-slate-600">{benefit}</span></div>)}</div>
      </div>
      <div className="flex shrink-0 items-center gap-2 pl-1">
        <div className="text-right"><p className="text-[26px] font-semibold leading-7 tracking-tight text-slate-900">₹{plan.price}</p><p className="mt-1 text-[12px] font-semibold text-amber-700">{plan.validity}</p></div>
        <ChevronRight className="h-5 w-5 text-slate-400" />
      </div>
    </div>
  </motion.button>;
}

export function activeRechargePlan(status: RechargeStatus | null): Entitlement | null {
  return status?.currentPlan || status?.activeTemporaryEntitlements?.[0] || null;
}

export function matchesRechargeSearch(item: { name: string; price: number; validity: string; benefits?: readonly string[] }, query: string) {
  const normalized = query.trim().toLowerCase().replace("₹", "");
  if (!normalized) return true;
  return [item.name, String(item.price), item.validity, ...(item.benefits || [])].some(value => value.toLowerCase().includes(normalized));
}

export function ActiveHelloTuneCard({ profile, onManage }: { profile: UserProfile; onManage: () => void }) {
  const pass = profile.activeHelloTunePass;
  const tune = profile.helloTune;
  if (!pass || pass.expiresAt <= Date.now() || !tune) return null;
  return <button onClick={onManage} className="w-full rounded-[18px] border border-amber-100 bg-amber-50 p-4 text-left shadow-[0_1px_2px_rgba(15,23,42,0.04)] active:bg-amber-100 ripple"><div className="flex items-center gap-3"><div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-500 text-white"><Music className="h-5 w-5" /></div><div className="min-w-0 flex-1"><p className="text-[10px] font-bold uppercase tracking-[0.13em] text-amber-700">HelloTune active</p><p className="mt-0.5 truncate text-[15px] font-semibold text-slate-900">{tune.name || "Custom Audio"}</p><p className="mt-0.5 text-[12px] text-slate-600">Valid until {formatExpiry(pass.expiresAt)}</p></div><ChevronRight className="h-5 w-5 shrink-0 text-amber-700" /></div></button>;
}

export default function PlanSelection({ profile, onClose, onOpenHelloTune }: PlanSelectionProps) {
  const [activeCategory, setActiveCategory] = useState<Category | "All Plans">("All Plans");
  const [searchQuery, setSearchQuery] = useState("");
  const [plans, setPlans] = useState<Plan[]>([]);
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);
  const [rechargeStatus, setRechargeStatus] = useState<RechargeStatus | null>(null);
  const [catalogError, setCatalogError] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [showPurchaseConfirm, setShowPurchaseConfirm] = useState(false);
  const [checkoutNotice, setCheckoutNotice] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [showVipSearch, setShowVipSearch] = useState(false);
  const [overflowPanel, setOverflowPanel] = useState<"menu" | "history" | "help" | null>(null);
  const [purchaseHistory, setPurchaseHistory] = useState<PurchaseHistoryEntry[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [restoreNotice, setRestoreNotice] = useState("");
  const categoryRefs = useRef<Record<string, HTMLButtonElement | null>>({});
  const activePlanRef = useRef<HTMLElement | null>(null);
  const [friendStage, setFriendStage] = useState<FriendRechargeStage>(null);
  const [friendNumber, setFriendNumber] = useState("");
  const [friendTarget, setFriendTarget] = useState<string | null>(null);
  const [friendError, setFriendError] = useState("");
  const [isFriendProcessing, setIsFriendProcessing] = useState(false);
  const [helloTunePacks, setHelloTunePacks] = useState<HelloTunePack[]>([]);
  const [selectedHelloTunePack, setSelectedHelloTunePack] = useState<HelloTunePack | null>(null);
  const [preparedHelloTuneClip, setPreparedHelloTuneClip] = useState<PreparedHelloTuneClip | null>(null);

  const primaryNumber = profile.virtualNumbers?.find(vn => vn.type === "primary")?.number || "";
  const formattedNumber = primaryNumber.length === 8 ? `${primaryNumber.slice(0, 4)}-${primaryNumber.slice(4)}` : primaryNumber;

  const loadRechargeState = async () => {
    try {
      const [catalog, status, helloTuneCatalog] = await Promise.all([
        secureApi.recharge.catalog.query(),
        secureApi.recharge.status.query(),
        secureApi.helloTune.packs.query(),
      ]);
      setPlans([...catalog] as Plan[]);
      setRechargeStatus(status as RechargeStatus);
      setHelloTunePacks([...helloTuneCatalog] as HelloTunePack[]);
      setCatalogError("");
    } catch (error: any) {
      setCatalogError(error?.message || "Recharge details could not be loaded. Please try again.");
    }
  };

  useEffect(() => {
    void loadRechargeState();
    const refreshOnFocus = () => { void loadRechargeState(); };
    window.addEventListener("focus", refreshOnFocus);
    return () => window.removeEventListener("focus", refreshOnFocus);
  }, []);

  useEffect(() => {
    const tab = categoryRefs.current[activeCategory];
    const scrollContainer = tab?.parentElement?.parentElement;
    if (tab && scrollContainer) {
      scrollContainer.scrollTo({ left: Math.max(0, tab.offsetLeft - scrollContainer.clientWidth / 2 + tab.clientWidth / 2), behavior: "smooth" });
    }
  }, [activeCategory]);

  const isSearching = searchQuery.trim().length > 0;
  const filteredPlans = plans.filter(plan => {
    const matchesSearch = matchesRechargeSearch({ name: plan.planName, price: plan.price, validity: plan.validity, benefits: plan.benefits }, searchQuery);
    const matchesCategory = isSearching || (activeCategory === "All Plans" || (activeCategory !== "HelloTune" && plan.categories.includes(activeCategory)));
    return matchesSearch && matchesCategory;
  });
  // New HelloTune selection must begin in its dedicated Recharge category tab.
  // Generic Recharge search intentionally does not reveal pack cards or checkout entry points.
  const filteredHelloTunePacks: HelloTunePack[] = [];

  const openPurchaseHistory = async () => {
    setOverflowPanel("history");
    setHistoryLoading(true);
    try {
      setPurchaseHistory(await secureApi.recharge.purchaseHistory.query() as PurchaseHistoryEntry[]);
    } catch (error: any) {
      setRestoreNotice(error?.message || "Purchase history could not be loaded. Please try again.");
    } finally {
      setHistoryLoading(false);
    }
  };

  const restorePurchases = async () => {
    setOverflowPanel(null);
    setRestoreNotice("");
    try {
      await loadRechargeState();
      setRestoreNotice("Your verified Recharge and HelloTune purchases have been refreshed.");
      hapticFeedback.success();
    } catch {
      setRestoreNotice("Purchases could not be restored. Please try again.");
      hapticFeedback.error();
    }
  };

  const openCheckout = (checkoutUrl: string) => {
    const opened = window.open(checkoutUrl, "_blank", "noopener,noreferrer");
    if (!opened) window.location.assign(checkoutUrl);
  };

  const handlePurchase = async () => {
    if (!selectedPlan || isProcessing) return;
    setCheckoutNotice("");
    setIsProcessing(true);
    try {
      const response = await secureApi.recharge.createCheckout.mutate({ planId: selectedPlan.planId, requestId: crypto.randomUUID() });
      if (response.alreadyFulfilled) {
        await loadRechargeState();
        setCheckoutNotice("This verified payment was already fulfilled. Recharge status has been updated.");
        hapticFeedback.success();
      } else if (response.checkoutUrl) {
        openCheckout(response.checkoutUrl);
        setCheckoutNotice("Secure checkout opened. This plan will activate only after payment verification is received by the server.");
      }
    } catch (error: any) {
      setCheckoutNotice(error?.message || "Secure checkout could not be started. No plan was activated.");
      hapticFeedback.error();
    } finally {
      setIsProcessing(false);
    }
  };

  const handleHelloTuneCheckout = async () => {
    if (!selectedHelloTunePack || !preparedHelloTuneClip || isProcessing) return;
    setCheckoutNotice("");
    setIsProcessing(true);
    try {
      const response = await secureApi.helloTune.createCheckout.mutate({ packId: selectedHelloTunePack.id, requestId: crypto.randomUUID(), clip: preparedHelloTuneClip });
      if (response.checkoutUrl) {
        openCheckout(response.checkoutUrl);
        setCheckoutNotice("Secure checkout opened. The selected audio activates only after server payment verification.");
      }
    } catch (error: any) {
      setCheckoutNotice(error?.message || "Secure checkout could not be started. No HelloTune was activated.");
      hapticFeedback.error();
    } finally {
      setIsProcessing(false);
    }
  };

  const validateFriendNumber = async () => {
    const targetNumber = friendNumber.replace(/\D/g, "");
    if (!/^\d{8}$/.test(targetNumber)) {
      setFriendError("Enter a valid 8-digit permanent virtual number.");
      return;
    }
    setFriendError("");
    setIsFriendProcessing(true);
    try {
      await secureApi.recharge.validateFriendTarget.query({ targetNumber });
      setFriendTarget(targetNumber);
      setFriendStage("verify");
    } catch (error: any) {
      setFriendError(error?.message || "This virtual number cannot receive a recharge.");
    } finally {
      setIsFriendProcessing(false);
    }
  };

  const confirmFriendRecharge = async () => {
    if (!friendTarget || !selectedPlan || isFriendProcessing) return;
    setFriendError("");
    setIsFriendProcessing(true);
    try {
      const response = await secureApi.recharge.createFriendCheckout.mutate({
        targetNumber: friendTarget,
        planId: selectedPlan.planId,
        requestId: crypto.randomUUID(),
      });
      if (response.alreadyFulfilled) {
        setFriendStage("payment-pending");
        setFriendError("This verified payment was already fulfilled for the target number.");
        hapticFeedback.success();
      } else if (response.checkoutUrl) {
        openCheckout(response.checkoutUrl);
        setFriendStage("payment-pending");
      }
    } catch (error: any) {
      setFriendError(error?.message || "Secure checkout could not be started. No recharge was applied.");
    } finally {
      setIsFriendProcessing(false);
    }
  };

  const closeFriendFlow = () => {
    setFriendStage(null);
    setFriendNumber("");
    setFriendTarget(null);
    setFriendError("");
  };

  const renderFriendConfirmSheet = () => {
    if (friendStage !== "confirm" || !friendTarget || !selectedPlan) return null;
    return <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 z-[60] bg-slate-900/40 flex items-end" onClick={() => setFriendStage(null)}>
      <motion.div initial={{ y: 80 }} animate={{ y: 0 }} exit={{ y: 80 }} transition={{ type: "spring", damping: 28, stiffness: 280 }} className="w-full bg-white rounded-t-[28px] p-5 pb-7 safe-area-bottom" onClick={event => event.stopPropagation()}>
        <h2 className="text-[20px] font-semibold text-slate-900">Confirm Recharge</h2>
        <dl className="mt-5 divide-y divide-slate-100">
          <div className="py-3 flex justify-between gap-4"><dt className="text-slate-500">Target Number</dt><dd className="font-mono text-slate-900">{friendTarget.slice(0, 4)}-{friendTarget.slice(4)}</dd></div>
          <div className="py-3 flex justify-between gap-4"><dt className="text-slate-500">Selected Plan</dt><dd className="font-medium text-slate-900 text-right">{selectedPlan.planName}</dd></div>
          <div className="py-3 flex justify-between gap-4"><dt className="text-slate-500">Price</dt><dd className="font-medium text-slate-900">₹{selectedPlan.price}</dd></div>
          <div className="py-3 flex justify-between gap-4"><dt className="text-slate-500">Validity</dt><dd className="font-medium text-slate-900">{selectedPlan.validity}</dd></div>
        </dl>
        <p className="mt-4 text-[13px] leading-5 text-slate-500">The entitlement will be applied to this number only after the payment is verified by the server.</p>
        {friendError && <p role="alert" className="mt-3 text-[13px] text-red-600">{friendError}</p>}
        <div className="mt-5 flex gap-3"><button onClick={() => setFriendStage(null)} disabled={isFriendProcessing} className="flex-1 h-12 rounded-xl font-semibold text-slate-700 bg-slate-100 active:bg-slate-200 disabled:opacity-60">Cancel</button><button onClick={confirmFriendRecharge} disabled={isFriendProcessing} className="flex-1 h-12 rounded-xl font-semibold text-white bg-amber-500 active:bg-amber-600 disabled:opacity-60 ripple">{isFriendProcessing ? "Opening checkout..." : "Continue to secure payment"}</button></div>
      </motion.div>
    </motion.div>;
  };

  const renderFriendPaymentSheet = () => {
    if (friendStage !== "payment-pending" || !friendTarget || !selectedPlan) return null;
    return <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 z-[60] bg-slate-900/40 flex items-end">
      <motion.div initial={{ y: 80 }} animate={{ y: 0 }} exit={{ y: 80 }} transition={{ type: "spring", damping: 28, stiffness: 280 }} className="w-full bg-white rounded-t-[28px] p-5 pb-7 safe-area-bottom">
        <div className="w-12 h-12 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center"><Clock3 className="w-6 h-6" /></div>
        <h2 className="mt-4 text-[20px] font-semibold text-slate-900">Payment verification pending</h2>
        <p className="mt-2 text-[14px] leading-5 text-slate-500">Secure checkout was opened for {friendTarget.slice(0, 4)}-{friendTarget.slice(4)}. The plan activates only after verified payment confirmation.</p>
        <dl className="mt-5 divide-y divide-slate-100"><div className="py-3 flex justify-between gap-4"><dt className="text-slate-500">Plan</dt><dd className="font-medium text-slate-900 text-right">{selectedPlan.planName}</dd></div><div className="py-3 flex justify-between gap-4"><dt className="text-slate-500">Validity</dt><dd className="font-medium text-slate-900">{selectedPlan.validity}</dd></div></dl>
        {friendError && <p role="alert" className="mt-3 text-[13px] text-red-600">{friendError}</p>}
        <button onClick={() => { closeFriendFlow(); setSelectedPlan(null); }} className="mt-5 w-full h-12 rounded-xl font-semibold text-white bg-amber-500 active:bg-amber-600 ripple">Done</button>
      </motion.div>
    </motion.div>;
  };

  const renderOwnPurchaseConfirmSheet = () => {
    if (!showPurchaseConfirm || !selectedPlan) return null;
    return <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 z-[60] bg-slate-900/40 flex items-end" onClick={() => setShowPurchaseConfirm(false)}>
      <motion.div initial={{ y: 80 }} animate={{ y: 0 }} exit={{ y: 80 }} transition={{ type: "spring", damping: 28, stiffness: 280 }} className="w-full bg-white rounded-t-[28px] p-5 pb-7 safe-area-bottom" onClick={event => event.stopPropagation()}>
        <h2 className="text-[20px] font-semibold text-slate-900">Confirm Recharge</h2>
        <dl className="mt-5 divide-y divide-slate-100">
          <div className="py-3 flex justify-between gap-4"><dt className="text-slate-500">Selected Plan</dt><dd className="font-medium text-slate-900 text-right">{selectedPlan.planName}</dd></div>
          <div className="py-3 flex justify-between gap-4"><dt className="text-slate-500">Price</dt><dd className="font-medium text-slate-900">₹{selectedPlan.price}</dd></div>
          <div className="py-3 flex justify-between gap-4"><dt className="text-slate-500">Validity</dt><dd className="font-medium text-slate-900">{selectedPlan.validity}</dd></div>
        </dl>
        <p className="mt-4 text-[13px] leading-5 text-slate-500">Secure payment opens next. The entitlement activates only after the server verifies the payment.</p>
        <div className="mt-5 flex gap-3"><button onClick={() => setShowPurchaseConfirm(false)} disabled={isProcessing} className="flex-1 h-12 rounded-xl font-semibold text-slate-700 bg-slate-100 active:bg-slate-200 disabled:opacity-60">Cancel</button><button onClick={() => { setShowPurchaseConfirm(false); void handlePurchase(); }} disabled={isProcessing} className="flex-1 h-12 rounded-xl font-semibold text-white bg-amber-500 active:bg-amber-600 disabled:opacity-60 ripple">{isProcessing ? "Processing..." : "Continue to secure payment"}</button></div>
      </motion.div>
    </motion.div>;
  };

  if (showVipSearch) return <VipNumberSearch profile={profile} onClose={() => setShowVipSearch(false)} />;

  if (selectedHelloTunePack && !preparedHelloTuneClip) {
    return <AudioTrimmer profile={profile} onClose={() => setSelectedHelloTunePack(null)} onPrepared={async clip => setPreparedHelloTuneClip(clip)} />;
  }
  if (selectedHelloTunePack && preparedHelloTuneClip) {
    return <motion.div variants={pageTransition} initial="initial" animate="animate" exit="exit" className="recharge-purchase-surface absolute inset-0 z-50 flex flex-col bg-slate-50"><header className="h-14 px-4 bg-white border-b border-slate-100 flex items-center"><button onClick={() => setPreparedHelloTuneClip(null)} className="p-2 -ml-2 rounded-full text-slate-700 ripple"><ArrowLeft className="w-6 h-6" /></button><h1 className="ml-2 text-[18px] font-medium text-slate-900">Confirm HelloTune</h1></header><div className="flex-1 p-6"><p className="text-[11px] font-semibold uppercase tracking-wide text-amber-700">HelloTune Pack</p><h2 className="mt-1 text-2xl font-semibold text-slate-900">₹{selectedHelloTunePack.price} · {selectedHelloTunePack.validity}</h2><div className="mt-5 rounded-xl border border-slate-100 bg-white p-4"><p className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Selected audio</p><p className="mt-1 font-semibold text-slate-900 truncate">{preparedHelloTuneClip.name}</p><p className="text-sm text-slate-500">{preparedHelloTuneClip.clipDurationSeconds.toFixed(1)} seconds selected</p></div><p className="mt-5 text-sm text-slate-500">Payment opens next. This audio becomes active only after server-side payment verification.</p>{checkoutNotice && <p role="status" className="mt-4 rounded-xl bg-amber-50 p-3 text-sm text-amber-800">{checkoutNotice}</p>}</div><div className="p-4 bg-white border-t border-slate-100"><button onClick={() => void handleHelloTuneCheckout()} disabled={isProcessing} className="w-full h-14 rounded-xl bg-amber-500 text-white font-semibold ripple">{isProcessing ? "Opening checkout..." : "Continue to secure payment"}</button></div></motion.div>;
  }

  if (selectedPlan) {
    return <motion.div variants={pageTransition} initial="initial" animate="animate" exit="exit" className="recharge-purchase-surface absolute inset-0 bg-slate-50 flex flex-col z-50">
      <div className="flex items-center px-4 h-14 bg-white border-b border-slate-100 shrink-0"><button onClick={() => { hapticFeedback.light(); setCheckoutNotice(""); setSelectedPlan(null); }} className="p-2 -ml-2 rounded-full active:bg-slate-100 text-slate-700 ripple"><ArrowLeft className="w-6 h-6" /></button><h1 className="ml-2 text-[18px] font-medium text-slate-900 tracking-tight">Plan Details</h1></div>
      <div className="flex-1 overflow-y-auto bg-slate-50 pb-24"><div className="bg-white px-5 pb-5 pt-5 border-b border-slate-100"><p className="text-[11px] font-semibold uppercase tracking-[0.13em] text-amber-700">Selected plan</p><h2 className="mt-1 text-[24px] font-semibold leading-8 text-slate-900">{selectedPlan.planName}</h2><div className="mt-5 flex items-end justify-between"><div><p className="text-[11px] font-medium uppercase tracking-wider text-slate-500">Plan price</p><div className="mt-1 text-[36px] font-semibold leading-none tracking-tight text-slate-900">₹{selectedPlan.price}</div></div><div className="rounded-xl bg-amber-100 px-3 py-2 text-right"><p className="text-[10px] font-semibold uppercase tracking-wider text-amber-700">Validity</p><p className="mt-0.5 text-[14px] font-semibold text-slate-800">{selectedPlan.validity}</p></div></div></div><div className="space-y-3 p-4"><section className="rounded-[18px] border border-slate-200/80 bg-white p-4 shadow-[0_1px_2px_rgba(15,23,42,0.04)]"><p className="text-[11px] font-semibold uppercase tracking-[0.13em] text-slate-500">Validity</p><p className="mt-2 text-[17px] font-semibold text-slate-900">{selectedPlan.validity}</p></section><section className="rounded-[18px] border border-slate-200/80 bg-white p-4 shadow-[0_1px_2px_rgba(15,23,42,0.04)]"><h3 className="text-[11px] font-semibold uppercase tracking-[0.13em] text-slate-500">Benefits</h3><ul className="mt-4 space-y-3">{selectedPlan.benefits.map((benefit, index) => <li key={index} className="flex gap-3 items-start"><div className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-amber-100"><Check className="h-3.5 w-3.5 text-amber-600" /></div><span className="text-[14px] leading-5 text-slate-700">{benefit}</span></li>)}</ul></section>{checkoutNotice && <p role="status" className="rounded-xl border border-amber-100 bg-amber-50 px-4 py-3 text-[13px] leading-5 text-amber-800">{checkoutNotice}</p>}</div></div>
      <div className="absolute bottom-0 left-0 right-0 border-t border-slate-200 bg-white p-4 safe-area-bottom"><motion.button whileTap={!isProcessing ? tapScale : undefined} onClick={() => friendTarget ? setFriendStage("confirm") : setShowPurchaseConfirm(true)} disabled={isProcessing || isFriendProcessing} className="flex h-14 w-full items-center justify-center rounded-xl bg-amber-500 text-[16px] font-semibold text-white shadow-[0_6px_16px_rgba(236,152,0,0.22)] transition-colors active:bg-amber-600 disabled:opacity-70 ripple">{isProcessing || isFriendProcessing ? "Processing..." : friendTarget ? "Continue" : "Select this plan"}</motion.button></div>
      <AnimatePresence>{renderOwnPurchaseConfirmSheet()}{renderFriendConfirmSheet()}{renderFriendPaymentSheet()}</AnimatePresence>
    </motion.div>;
  }

  const currentPlan = activeRechargePlan(rechargeStatus);
  const latestRecharge = rechargeStatus?.latestSuccessfulRecharge || null;
  const upcomingPlans = rechargeStatus?.upcomingPlans || [];
  const temporaryEntitlements = rechargeStatus?.activeTemporaryEntitlements || [];

  return <motion.div variants={pageTransition} initial="initial" animate="animate" exit="exit" className="recharge-purchase-surface absolute inset-0 bg-slate-50 flex flex-col z-40 overflow-hidden">
    <header className="h-14 px-4 bg-white border-b border-slate-100 flex items-center shrink-0 z-30"><button onClick={() => { hapticFeedback.light(); onClose(); }} className="min-w-12 min-h-12 -ml-2 flex items-center justify-center rounded-full active:bg-slate-100 text-slate-700 ripple" aria-label="Back"><ArrowLeft className="w-6 h-6" /></button>{showSearch ? <input type="search" autoFocus placeholder="Search plans and packs" className="flex-1 ml-1 bg-transparent outline-none text-[16px] text-slate-900" value={searchQuery} onChange={event => setSearchQuery(event.target.value)} /> : <h1 className="ml-1 text-[18px] font-medium text-slate-900 tracking-tight flex-1">Recharge</h1>}<button onClick={() => { if (showSearch) { setShowSearch(false); setSearchQuery(""); } else setShowSearch(true); }} className="min-w-12 min-h-12 flex items-center justify-center rounded-full active:bg-slate-100 text-slate-700 ripple" aria-label="Search plans"><Search className="w-5 h-5" /></button><button onClick={() => setOverflowPanel(current => current === "menu" ? null : "menu")} aria-expanded={overflowPanel === "menu"} className="min-w-12 min-h-12 -mr-2 flex items-center justify-center rounded-full active:bg-slate-100 text-slate-700 ripple" aria-label="More recharge options"><MoreVertical className="w-5 h-5" /></button></header>
    <div className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden overscroll-contain">
      <section className="border-b border-slate-100 bg-white px-5 pb-3 pt-4"><p className="text-[12px] font-semibold uppercase tracking-[0.12em] text-slate-500">Your Permanent Virtual Number</p><p className="mt-1 text-[22px] font-mono tracking-wide text-slate-900">{formattedNumber}</p>{temporaryEntitlements.map(entitlement => <div key={entitlement.entitlementId} className="mt-3 border-t border-slate-100 pt-3"><p className="text-[11px] font-semibold uppercase tracking-[0.1em] text-amber-700">Active Temporary Number</p><p className="mt-1 text-[17px] font-mono tracking-wide text-slate-900">{entitlement.temporaryNumber.slice(0, 3)}-{entitlement.temporaryNumber.slice(3)}</p><p className="mt-1 text-[12px] text-slate-500">Active until {formatExpiry(entitlement.entitlementExpiry)} · {entitlement.validity}</p></div>)}</section>
      <section ref={activePlanRef} className="bg-white px-5 py-3 border-b border-slate-100"><p className="text-[11px] font-semibold uppercase tracking-wide text-amber-700">Active Plan</p>{latestRecharge ? <><p className="mt-1 text-[15px] font-semibold text-slate-900">Last Recharge: {latestRecharge.planName}</p><p className="text-[13px] text-slate-500">₹{latestRecharge.price} • {latestRecharge.validity} • {formatExpiry(latestRecharge.fulfilledAt)}</p><button onClick={() => setSelectedPlan(plans.find(plan => plan.planId === latestRecharge.planId) || null)} className="mt-2 text-[13px] font-semibold text-amber-700">View details →</button></> : <><p className="mt-1 text-[15px] font-semibold text-slate-900">No active plan</p><p className="text-[13px] text-slate-500">Choose a plan to get started.</p></>}{restoreNotice && <p role="status" className="mt-3 rounded-lg bg-amber-50 px-3 py-2 text-[12px] leading-4 text-amber-800">{restoreNotice}</p>}</section>
      <section className="bg-white px-4 py-2 border-b border-slate-100">
        <button onClick={() => { setFriendError(""); setFriendStage("input"); }} className="w-full min-h-12 px-2 flex items-center gap-3 text-left rounded-xl active:bg-slate-50 ripple"><div className="w-9 h-9 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center shrink-0"><img src={RECHARGE_FRIEND_ICON_SRC} alt="" aria-hidden="true" draggable={false} className="w-5 h-5 object-contain" /></div><div className="flex-1 min-w-0"><p className="text-[15px] font-semibold text-slate-900">Recharge for a friend</p><p className="text-[12px] text-slate-500 truncate">Recharge a virtual number for someone else.</p></div><ChevronRight className="w-5 h-5 text-slate-300" /></button>
        <button onClick={() => { hapticFeedback.light(); setShowVipSearch(true); }} className="w-full min-h-11 px-2 flex items-center gap-3 text-left rounded-xl active:bg-amber-50 ripple"><div className="w-9 h-9 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center shrink-0"><img src={VIP_NUMBERS_ICON_SRC} alt="" aria-hidden="true" draggable={false} className="w-5 h-5 object-contain" /></div><div className="flex-1 min-w-0"><p className="text-[14px] font-medium text-slate-800">VIP Numbers</p><p className="text-[12px] text-slate-500 truncate">Find a memorable virtual number</p></div><ChevronRight className="w-5 h-5 text-slate-300" /></button>
      </section>
      <div className="sticky top-0 z-20 bg-white border-b border-slate-200 shadow-[0_2px_5px_rgba(15,23,42,0.06)]"><div className="overflow-x-auto no-scrollbar"><div className="flex min-w-max gap-2 px-4 py-2 snap-x">{CATEGORIES.map(category => <button ref={element => { categoryRefs.current[category] = element; }} key={category} onClick={() => { hapticFeedback.light(); setActiveCategory(category); setSearchQuery(""); setShowSearch(false); }} className={`snap-start whitespace-nowrap min-h-10 px-4 rounded-full text-[14px] font-medium transition-colors ${activeCategory === category ? "bg-amber-100 text-amber-700" : "bg-slate-100 text-slate-600 active:bg-slate-200"}`}>{category}</button>)}</div></div></div>
      <div className="px-4 pt-3 pb-8">{isSearching ? <div className="flex flex-col gap-2.5">{filteredPlans.map(plan => <RechargePlanCard key={plan.planId} plan={plan} onSelect={() => { hapticFeedback.medium(); setCheckoutNotice(""); setSelectedPlan(plan); }} />)}{filteredHelloTunePacks.map(pack => <button key={pack.id} onClick={() => { setCheckoutNotice(""); setPreparedHelloTuneClip(null); setSelectedHelloTunePack(pack); }} className="w-full rounded-[18px] border border-slate-200/80 bg-white p-4 text-left shadow-[0_1px_2px_rgba(15,23,42,0.05)] ripple"><div className="flex items-center justify-between"><div><p className="text-[10px] font-bold uppercase tracking-[0.13em] text-amber-700">HelloTune Pack</p><h3 className="mt-0.5 font-semibold text-slate-900">{pack.name}</h3><p className="mt-1 text-sm font-semibold text-amber-700">{pack.validity}</p></div><div className="flex items-center gap-2"><span className="text-[26px] font-semibold tracking-tight text-slate-900">₹{pack.price}</span><ChevronRight className="h-5 w-5 text-slate-400" /></div></div></button>)}{filteredPlans.length === 0 && filteredHelloTunePacks.length === 0 && <p className="rounded-xl border border-slate-200 bg-white px-4 py-5 text-center text-sm text-slate-500">No Recharge plans or packs match your search.</p>}</div> : activeCategory === "HelloTune" ? <div className="flex flex-col gap-2.5"><ActiveHelloTuneCard profile={profile} onManage={onOpenHelloTune} />{helloTunePacks.map(pack => <button key={pack.id} onClick={() => { setCheckoutNotice(""); setPreparedHelloTuneClip(null); setSelectedHelloTunePack(pack); }} className="w-full bg-white rounded-[18px] p-4 shadow-[0_1px_2px_rgba(15,23,42,0.05)] border border-slate-200/80 text-left ripple"><div className="flex justify-between"><div><h3 className="font-semibold text-slate-900">HelloTune Pack</h3><p className="mt-1 text-sm font-semibold text-amber-700">{pack.validity}</p></div><span className="text-[26px] font-semibold tracking-tight text-slate-900">₹{pack.price}</span></div></button>)}</div> : catalogError ? <div role="alert" className="rounded-xl border border-red-100 bg-red-50 px-4 py-3 text-[13px] text-red-700">{catalogError}</div> : <div className="flex flex-col gap-2.5">{filteredPlans.map(plan => <RechargePlanCard key={plan.planId} plan={plan} onSelect={() => { hapticFeedback.medium(); setCheckoutNotice(""); setSelectedPlan(plan); }} />)}</div>}</div>
    </div>
    <AnimatePresence>{friendStage === "input" && <motion.div initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }} transition={{ type: "spring", damping: 26, stiffness: 250 }} className="absolute inset-0 z-50 bg-slate-50 flex flex-col"><header className="h-14 px-4 bg-white border-b border-slate-100 flex items-center shrink-0"><button onClick={closeFriendFlow} className="min-w-12 min-h-12 -ml-2 flex items-center justify-center rounded-full active:bg-slate-100 text-slate-700 ripple" aria-label="Back"><ArrowLeft className="w-6 h-6" /></button><h2 className="ml-1 text-[18px] font-medium text-slate-900">Recharge for a friend</h2></header><div className="flex-1 overflow-y-auto px-5 pt-6"><p className="text-[15px] text-slate-600">Recharge a virtual number for someone else.</p><label className="block mt-6 text-[13px] font-semibold text-slate-700">Enter virtual number</label><input inputMode="numeric" autoFocus maxLength={8} value={friendNumber} onChange={event => { setFriendNumber(event.target.value.replace(/\D/g, "")); setFriendError(""); }} placeholder="XXXX XXXX" className="mt-2 w-full h-14 px-4 rounded-xl border border-slate-200 bg-white font-mono text-[20px] tracking-wide text-slate-900 outline-none focus:border-amber-500" />{friendError && <p role="alert" className="mt-3 text-[13px] text-red-600">{friendError}</p>}</div><div className="p-4 bg-white border-t border-slate-100 safe-area-bottom"><button onClick={validateFriendNumber} disabled={isFriendProcessing} className="w-full h-14 rounded-xl bg-amber-500 text-white font-semibold active:bg-amber-600 disabled:opacity-60 ripple">{isFriendProcessing ? "Verifying..." : "Continue"}</button></div></motion.div>}{friendStage === "verify" && friendTarget && <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 z-[60] bg-slate-900/40 flex items-end" onClick={closeFriendFlow}><motion.div initial={{ y: 80 }} animate={{ y: 0 }} exit={{ y: 80 }} transition={{ type: "spring", damping: 28, stiffness: 280 }} className="w-full bg-white rounded-t-[28px] p-5 pb-7 safe-area-bottom" onClick={event => event.stopPropagation()}><h2 className="text-[20px] font-semibold text-slate-900">Recharge this number?</h2><p className="mt-3 text-[24px] font-mono tracking-wide text-slate-900">{friendTarget.slice(0, 4)}-{friendTarget.slice(4)}</p><p className="mt-2 text-[14px] text-slate-500">Please verify the number before continuing.</p><div className="mt-6 flex gap-3"><button onClick={closeFriendFlow} className="flex-1 h-12 rounded-xl font-semibold text-slate-700 bg-slate-100 active:bg-slate-200">Cancel</button><button onClick={() => setFriendStage(null)} className="flex-1 h-12 rounded-xl font-semibold text-white bg-amber-500 active:bg-amber-600 ripple">Continue</button></div></motion.div></motion.div>}{renderFriendConfirmSheet()}{renderFriendPaymentSheet()}</AnimatePresence>
    <AnimatePresence>{overflowPanel === "menu" && <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.16 }} className="absolute right-3 top-12 z-[55] w-60 overflow-hidden rounded-2xl border border-slate-200 bg-white py-1 shadow-xl"><button onClick={() => { setOverflowPanel(null); activePlanRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }); }} className="flex min-h-12 w-full items-center gap-3 px-4 text-left text-[14px] font-medium text-slate-800 active:bg-slate-50"><Clock3 className="h-5 w-5 text-amber-700" />Active Plans</button><button onClick={() => void openPurchaseHistory()} className="flex min-h-12 w-full items-center gap-3 px-4 text-left text-[14px] font-medium text-slate-800 active:bg-slate-50"><History className="h-5 w-5 text-amber-700" />Purchase History</button><button onClick={() => void restorePurchases()} className="flex min-h-12 w-full items-center gap-3 px-4 text-left text-[14px] font-medium text-slate-800 active:bg-slate-50"><RotateCcw className="h-5 w-5 text-amber-700" />Restore Purchases</button><button onClick={() => setOverflowPanel("help")} className="flex min-h-12 w-full items-center gap-3 px-4 text-left text-[14px] font-medium text-slate-800 active:bg-slate-50"><CircleHelp className="h-5 w-5 text-amber-700" />Help &amp; Recharge Info</button></motion.div>}{overflowPanel === "history" && <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 z-[60] flex items-end bg-slate-900/40" onClick={() => setOverflowPanel(null)}><motion.section initial={{ y: 80 }} animate={{ y: 0 }} exit={{ y: 80 }} transition={{ type: "spring", damping: 28, stiffness: 280 }} className="max-h-[80%] w-full rounded-t-[28px] bg-white p-5 pb-7 safe-area-bottom" onClick={event => event.stopPropagation()}><div className="flex items-center justify-between"><h2 className="text-[20px] font-semibold text-slate-900">Purchase History</h2><button onClick={() => setOverflowPanel(null)} className="flex h-10 w-10 items-center justify-center rounded-full text-slate-600 active:bg-slate-100" aria-label="Close purchase history"><X className="h-5 w-5" /></button></div><div className="mt-4 max-h-80 space-y-2 overflow-y-auto">{historyLoading ? <p className="py-6 text-center text-sm text-slate-500">Loading purchases…</p> : purchaseHistory.length ? purchaseHistory.map(entry => <div key={entry.purchaseId} className="rounded-xl border border-slate-100 px-4 py-3"><div className="flex items-start justify-between gap-3"><div><p className="font-medium text-slate-900">{entry.planName}</p><p className="mt-1 text-[12px] text-slate-500">{entry.validity || "Details unavailable"} · {new Date(entry.createdAt).toLocaleDateString()}</p></div><div className="text-right"><p className="font-semibold text-slate-900">{entry.price === null ? "—" : `₹${entry.price}`}</p><p className="mt-1 text-[11px] font-medium uppercase text-amber-700">{entry.status.replaceAll("_", " ")}</p></div></div></div>) : <p className="py-6 text-center text-sm text-slate-500">No Recharge purchases yet.</p>}</div></motion.section></motion.div>}{overflowPanel === "help" && <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 z-[60] flex items-end bg-slate-900/40" onClick={() => setOverflowPanel(null)}><motion.section initial={{ y: 80 }} animate={{ y: 0 }} exit={{ y: 80 }} transition={{ type: "spring", damping: 28, stiffness: 280 }} className="w-full rounded-t-[28px] bg-white p-5 pb-7 safe-area-bottom" onClick={event => event.stopPropagation()}><div className="flex items-center justify-between"><h2 className="text-[20px] font-semibold text-slate-900">Help &amp; Recharge Info</h2><button onClick={() => setOverflowPanel(null)} className="flex h-10 w-10 items-center justify-center rounded-full text-slate-600 active:bg-slate-100" aria-label="Close recharge help"><X className="h-5 w-5" /></button></div><p className="mt-4 text-sm leading-6 text-slate-600">Choose a plan, review its price and validity, then continue to secure payment. A Recharge or HelloTune entitlement activates only after the server verifies payment. Use Restore Purchases to refresh verified purchases on this device.</p></motion.section></motion.div>}</AnimatePresence>
  </motion.div>;
}
