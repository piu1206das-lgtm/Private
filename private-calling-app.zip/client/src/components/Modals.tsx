import { useState } from "react";
import { UserProfile, AudioSettings } from "../types";
import { doc, updateDoc } from "firebase/firestore";
import { db } from "../firebase";
import { X, CheckCircle2, AlertCircle } from "lucide-react";
import { changePin } from "../services/backend";
import { motion } from "motion/react";
import { dialogTransition, tapScale } from "../utils/animations";
import { hapticFeedback } from "../utils/haptics";

export function Toast({ message, type = "success", onClose }: { message: string, type?: "success" | "error", onClose: () => void }) {
  return (
    <div className="fixed top-12 left-1/2 -translate-x-1/2 z-[100] animate-in slide-in-from-top-4 fade-in duration-300">
      <div className={`flex items-center gap-2 px-4 py-3 rounded-full shadow-lg ${type === 'success' ? 'bg-[#1A1A1A] text-white' : 'bg-red-500 text-white'}`}>
        {type === 'success' ? <CheckCircle2 className="w-5 h-5 text-[#FFC107]" /> : <AlertCircle className="w-5 h-5" />}
        <span className="text-sm font-medium">{message}</span>
        <button onClick={onClose} className="ml-2 opacity-70 hover:opacity-100"><X className="w-4 h-4" /></button>
      </div>
    </div>
  );
}

// EDIT PROFILE MODAL
export function EditProfileModal({ profile, onClose, onSuccess }: { profile: UserProfile, onClose: () => void, onSuccess: (p: Partial<UserProfile>) => void }) {
  const [name, setName] = useState(profile.displayName);
  const [bio, setBio] = useState(profile.bio);
  const [loading, setLoading] = useState(false);

  const handleSave = async () => {
    setLoading(true);
    try {
      await updateDoc(doc(db, "users", profile.uid), { displayName: name, bio });
      onSuccess({ displayName: name, bio });
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-[60] flex items-end sm:items-center justify-center p-0 sm:p-4">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0" onClick={onClose}></motion.div>
      <motion.div variants={dialogTransition} initial="initial" animate="animate" exit="exit" className="bg-white w-full max-w-md sm:rounded-3xl rounded-t-3xl overflow-hidden relative z-10">
        <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-[#FFC107]">
          <h3 className="font-bold text-[#1A1A1A] text-lg">Edit Profile</h3>
          <button onClick={onClose} className="p-2 bg-black/10 rounded-full hover:bg-black/20"><X className="w-5 h-5 text-black" /></button>
        </div>
        <div className="p-6 space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Display Name</label>
            <input value={name} onChange={e => setName(e.target.value)} className="w-full p-3 bg-slate-50 rounded-xl border-none focus:ring-2 focus:ring-[#FFC107] transition-all" />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Bio</label>
            <textarea value={bio} onChange={e => setBio(e.target.value)} rows={3} className="w-full p-3 bg-slate-50 rounded-xl border-none focus:ring-2 focus:ring-[#FFC107] transition-all resize-none" />
          </div>
          <button onClick={handleSave} disabled={loading} className="w-full py-4 bg-[#1A1A1A] text-white rounded-xl font-bold mt-4 hover:bg-black active:scale-95 transition-all">
            {loading ? "Saving..." : "Save Changes"}
          </button>
        </div>
      </motion.div>
    </div>
  );
}

// CHANGE PIN MODAL
export function ChangePinModal({ profile, onClose, onSuccess }: { profile: UserProfile, onClose: () => void, onSuccess: () => void }) {
  const [currentPin, setCurrentPin] = useState("");
  const [newPin, setNewPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSave = async () => {
    setError("");
    if (currentPin.length !== 4 || newPin.length !== 4 || confirmPin.length !== 4) {
      return setError("Each PIN must contain 4 digits.");
    }
    if (newPin !== confirmPin) return setError("New PIN entries do not match.");
    setLoading(true);
    try {
      const result = await changePin(profile.uid, currentPin, newPin);
      if (!result.success) {
        setError(result.error || "Unable to update PIN.");
        return;
      }
      onSuccess();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-[60] flex items-end sm:items-center justify-center p-0 sm:p-4">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0" onClick={onClose}></motion.div>
      <motion.div variants={dialogTransition} initial="initial" animate="animate" exit="exit" className="bg-white w-full max-w-md sm:rounded-3xl rounded-t-3xl overflow-hidden relative z-10">
        <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-[#FFC107]">
          <h3 className="font-bold text-[#1A1A1A] text-lg">Change PIN</h3>
          <button onClick={onClose} className="p-2 bg-black/10 rounded-full hover:bg-black/20"><X className="w-5 h-5 text-black" /></button>
        </div>
        <div className="p-6 space-y-4">
          {error && <div className="p-3 bg-red-50 text-red-600 rounded-lg text-sm">{error}</div>}
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Current 4-Digit PIN</label>
            <input type="password" inputMode="numeric" autoComplete="current-password" maxLength={4} value={currentPin} onChange={e => setCurrentPin(e.target.value.replace(/[^0-9]/g, ""))} className="w-full p-3 bg-slate-50 rounded-xl border-none focus:ring-2 focus:ring-[#FFC107] text-center tracking-widest text-xl" />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">New 4-Digit PIN</label>
            <input type="password" inputMode="numeric" autoComplete="new-password" maxLength={4} value={newPin} onChange={e => setNewPin(e.target.value.replace(/[^0-9]/g, ""))} className="w-full p-3 bg-slate-50 rounded-xl border-none focus:ring-2 focus:ring-[#FFC107] text-center tracking-widest text-xl" />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Confirm New PIN</label>
            <input type="password" inputMode="numeric" autoComplete="new-password" maxLength={4} value={confirmPin} onChange={e => setConfirmPin(e.target.value.replace(/[^0-9]/g, ""))} className="w-full p-3 bg-slate-50 rounded-xl border-none focus:ring-2 focus:ring-[#FFC107] text-center tracking-widest text-xl" />
          </div>
          <button onClick={handleSave} disabled={loading} className="w-full py-4 bg-[#1A1A1A] text-white rounded-xl font-bold mt-4 hover:bg-black active:scale-95 transition-all">
            {loading ? "Updating..." : "Update PIN"}
          </button>
        </div>
      </motion.div>
    </div>
  );
}

// AUDIO SETTINGS MODAL
export function AudioSettingsModal({ profile, onClose, onSuccess }: { profile: UserProfile, onClose: () => void, onSuccess: (s: AudioSettings) => void }) {
  const [quality, setQuality] = useState<"Auto" | "HD">(profile.audioSettings?.quality || "Auto");
  const [nc, setNc] = useState(profile.audioSettings?.noiseCancellation ?? true);
  const [loading, setLoading] = useState(false);

  const handleSave = async () => {
    setLoading(true);
    const settings: AudioSettings = { speaker: "default", mic: "default", quality, noiseCancellation: nc };
    try {
      await updateDoc(doc(db, "users", profile.uid), { audioSettings: settings });
      onSuccess(settings);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-[60] flex items-end sm:items-center justify-center p-0 sm:p-4">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0" onClick={onClose}></motion.div>
      <motion.div variants={dialogTransition} initial="initial" animate="animate" exit="exit" className="bg-white w-full max-w-md sm:rounded-3xl rounded-t-3xl overflow-hidden relative z-10">
        <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-[#FFC107]">
          <h3 className="font-bold text-[#1A1A1A] text-lg">Audio Settings</h3>
          <button onClick={onClose} className="p-2 bg-black/10 rounded-full hover:bg-black/20"><X className="w-5 h-5 text-black" /></button>
        </div>
        <div className="p-6 space-y-6">
          
          <div className="flex items-center justify-between">
            <div>
              <p className="font-bold text-[#1A1A1A]">Call Quality</p>
              <p className="text-xs text-slate-500">HD uses more bandwidth</p>
            </div>
            <div className="flex bg-slate-100 p-1 rounded-xl">
              <button onClick={() => setQuality("Auto")} className={`px-4 py-1.5 rounded-lg text-sm font-bold transition-all ${quality === 'Auto' ? 'bg-white shadow text-[#1A1A1A]' : 'text-slate-500'}`}>Auto</button>
              <button onClick={() => setQuality("HD")} className={`px-4 py-1.5 rounded-lg text-sm font-bold transition-all ${quality === 'HD' ? 'bg-white shadow text-[#1A1A1A]' : 'text-slate-500'}`}>HD</button>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="font-bold text-[#1A1A1A]">Noise Cancellation</p>
              <p className="text-xs text-slate-500">Filter background noise</p>
            </div>
            <button onClick={() => setNc(!nc)} className={`w-12 h-6 rounded-full transition-all relative ${nc ? 'bg-[#FFC107]' : 'bg-slate-300'}`}>
              <div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-all shadow ${nc ? 'left-6' : 'left-0.5'}`} />
            </button>
          </div>

          <button onClick={handleSave} disabled={loading} className="w-full py-4 bg-[#1A1A1A] text-white rounded-xl font-bold mt-4 hover:bg-black active:scale-95 transition-all">
            {loading ? "Saving..." : "Save Preferences"}
          </button>
        </div>
      </motion.div>
    </div>
  );
}
