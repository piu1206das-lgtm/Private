import { useState, useEffect } from "react";
import { Wifi, Signal, Battery } from "lucide-react";

export default function AndroidStatusBar() {
  const [time, setTime] = useState("");

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="w-full h-7 bg-[#FFC107] flex items-center justify-between px-4 text-black/80 text-[11px] font-medium z-50">
      <div>{time}</div>
      <div className="flex items-center gap-1.5">
        <Wifi className="w-3.5 h-3.5" />
        <Signal className="w-3.5 h-3.5" />
        <Battery className="w-4 h-4" />
      </div>
    </div>
  );
}
