import React from "react";
import { Phone, Users, Settings, Wallet } from "lucide-react";
import { motion } from "motion/react";
import { hapticFeedback } from "../utils/haptics";

export type TabType = "dialer" | "contacts" | "recharge" | "profile";

interface BottomNavProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
}

export default function BottomNav({ activeTab, onTabChange }: BottomNavProps) {
  const navItems = [
    { id: "dialer" as TabType, icon: Phone, label: "Dialer" },
    { id: "contacts" as TabType, icon: Users, label: "Contacts" },
    { id: "recharge" as TabType, icon: Wallet, label: "Recharge" },
    { id: "profile" as TabType, icon: Settings, label: "Profile" }
  ];

  return (
    <div className="bottom-navigation-safe-area w-full max-w-full box-border bg-white flex flex-none shrink-0 justify-evenly items-center border-t border-slate-100/50 relative z-40">
      {navItems.map(({ id, icon: Icon, label }) => {
        const isActive = activeTab === id;
        return (
          <button
            key={id}
            onClick={() => {
              if (!isActive) hapticFeedback.light();
              onTabChange(id);
            }}
            className="relative flex flex-1 min-w-0 max-w-20 flex-col items-center justify-center h-14 outline-none select-none tap-highlight-transparent group"
          >
            <div className="relative flex items-center justify-center w-16 h-8 rounded-full overflow-hidden">
               {isActive && (
                 <motion.div 
                   layoutId="bottomNavIndicator"
                   className="absolute inset-0 bg-amber-100 rounded-full"
                   transition={{ type: "spring", stiffness: 400, damping: 30 }}
                 />
               )}
               <Icon className={`w-5 h-5 relative z-10 transition-colors duration-200 ${isActive ? 'text-amber-700 fill-amber-700/20' : 'text-slate-500 group-active:scale-95'}`} strokeWidth={isActive ? 2.5 : 2} />
            </div>
            <span className={`text-[12px] font-medium mt-1 tracking-wide transition-colors duration-200 ${isActive ? 'text-amber-800 font-semibold' : 'text-slate-500'}`}>
              {label}
            </span>
          </button>
        );
      })}
    </div>
  );
}
