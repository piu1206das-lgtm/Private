import { useState, useEffect } from "react";
import { Phone, Delete, ArrowLeft, ShieldAlert } from "lucide-react";
import { UserProfile } from "../types";
import PinPadModal from "./PinPadModal";
import { detectVPN } from "../utils/vpnCheck";
import { doc, getDoc } from "firebase/firestore";
import { db } from "../firebase";

interface DialerProps {
  profile: UserProfile;
  onBack: () => void;
  onCall: (targetNumber: string) => void;
}

export default function Dialer({ profile, onBack, onCall }: DialerProps) {
  const [number, setNumber] = useState("");
  const [showPinPad, setShowPinPad] = useState(false);
  const [showVpnWarning, setShowVpnWarning] = useState(false);
  const [isCheckingDb, setIsCheckingDb] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  useEffect(() => {
    detectVPN().then(isVpn => {
      if (isVpn) setShowVpnWarning(true);
    });
  }, []);

  const handleKeyPress = (digit: string) => {
    if (number.length < 8) {
      setNumber(prev => prev + digit);
      setErrorMsg("");
    }
  };

  const handleDelete = () => {
    setNumber(prev => prev.slice(0, -1));
    setErrorMsg("");
  };

  const handleCallClick = async () => {
    if (number.length === 8) {
      setIsCheckingDb(true);
      setErrorMsg("");
      try {
        // Query assigned_numbers to find the user
        const numDoc = await getDoc(doc(db, "assigned_numbers", number));
        if (numDoc.exists()) {
          // Number found, show PIN pad
          setShowPinPad(true);
        } else {
          setErrorMsg("Number not found");
        }
      } catch (err) {
        console.error(err);
        setErrorMsg("Network error");
      } finally {
        setIsCheckingDb(false);
      }
    }
  };

  return (
    <div className="flex-1 bg-white flex flex-col z-20">
      
      {/* VPN Warning Modal */}
      {showVpnWarning && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white max-w-sm w-full rounded-[32px] p-6 shadow-2xl">
            <div className="w-12 h-12 bg-amber-100 text-[#FFA000] rounded-full flex items-center justify-center mb-4">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-[#1A1A1A] mb-2">VPN Detected</h3>
            <p className="text-slate-500 text-sm mb-6 leading-relaxed">
              Please deactivate your VPN otherwise your call may not be connected optimally. Peer-to-peer WebRTC connections often fail through VPN tunnels.
            </p>
            <button 
              onClick={() => setShowVpnWarning(false)}
              className="w-full py-4 bg-slate-100 hover:bg-slate-200 text-[#1A1A1A] rounded-2xl font-bold transition-all active:scale-95"
            >
              Continue Anyway
            </button>
          </div>
        </div>
      )}

      {/* PIN Pad Modal Overlay */}
      {showPinPad && (
        <PinPadModal callerUid="dummy_for_mock_dialer" 
          targetNumber={number}
          onSuccess={() => {
            setShowPinPad(false);
            onCall(number);
          }}
          onCancel={() => setShowPinPad(false)}
        />
      )}

      {/* Header */}
      <div className="w-full p-4 flex items-center gap-4 bg-white sticky top-0 z-10">
        <button onClick={onBack} className="p-3 text-[#1A1A1A] hover:bg-slate-100 rounded-full transition-colors active:scale-95">
          <ArrowLeft className="w-6 h-6" />
        </button>
      </div>

      <div className="flex-1 flex flex-col items-center w-full px-6 pb-6 pt-4">
        
        {/* Number Display */}
        <div className="flex-1 w-full flex flex-col items-center justify-center min-h-[140px]">
          <h2 className={`text-[42px] sm:text-[50px] tracking-widest font-mono font-light text-[#1A1A1A] h-16 flex items-center justify-center transition-all ${number.length > 0 ? 'scale-100 opacity-100' : 'scale-95 opacity-30'}`}>
            {number.length > 0 ? (
              <span>{number.slice(0, 4)}{number.length > 4 ? <span className="text-slate-300 mx-1">-</span> : ''}{number.slice(4)}</span>
            ) : (
              "0000-0000"
            )}
          </h2>
          {errorMsg ? (
            <div className="text-sm text-red-500 font-bold tracking-widest uppercase mt-4 animate-in fade-in slide-in-from-top-2">
              {errorMsg}
            </div>
          ) : (
            <div className="text-[10px] text-slate-400 font-bold tracking-widest uppercase mt-4">
              Enter 8-digit Virtual Number
            </div>
          )}
        </div>

        {/* Keypad */}
        <div className="w-full max-w-[300px] grid grid-cols-3 gap-x-4 gap-y-4 mb-8">
          {[
            { num: '1', letters: '' }, { num: '2', letters: 'ABC' }, { num: '3', letters: 'DEF' },
            { num: '4', letters: 'GHI' }, { num: '5', letters: 'JKL' }, { num: '6', letters: 'MNO' },
            { num: '7', letters: 'PQRS' }, { num: '8', letters: 'TUV' }, { num: '9', letters: 'WXYZ' },
            { num: '*', letters: '' }, { num: '0', letters: '+' }, { num: '#', letters: '' }
          ].map((key) => (
            <button
              key={key.num}
              onClick={() => handleKeyPress(key.num)}
              className="w-20 h-20 sm:w-24 sm:h-24 rounded-full flex flex-col justify-center items-center hover:bg-slate-100 active:bg-slate-200 transition-all mx-auto group relative overflow-hidden"
            >
              {/* Ripple effect trick */}
              <div className="absolute inset-0 bg-[#FFC107] opacity-0 group-active:opacity-20 transition-opacity"></div>
              <span className="text-3xl font-medium text-[#1A1A1A] group-active:scale-90 transition-transform">{key.num}</span>
              {key.letters && <span className="text-[10px] font-bold text-slate-400 tracking-widest group-active:scale-90 transition-transform">{key.letters}</span>}
            </button>
          ))}
        </div>

        {/* Action Row */}
        <div className="w-full flex items-center justify-between px-8">
          <div className="w-16"></div>
          
          <button
            disabled={number.length !== 8 || isCheckingDb}
            onClick={handleCallClick}
            className="w-20 h-20 bg-[#FFC107] rounded-full flex items-center justify-center shadow-lg shadow-[#FFC107]/40 transition-all active:scale-95 disabled:opacity-50 disabled:active:scale-100 disabled:shadow-none"
          >
            {isCheckingDb ? (
              <div className="w-8 h-8 border-4 border-black/20 border-t-black rounded-full animate-spin"></div>
            ) : (
              <Phone className="w-8 h-8 text-[#1A1A1A] fill-[#1A1A1A]" />
            )}
          </button>
          
          <div className="w-16 flex justify-end">
            <button
              onClick={handleDelete}
              disabled={number.length === 0}
              className="w-16 h-16 rounded-full flex items-center justify-center text-slate-400 hover:text-[#1A1A1A] hover:bg-slate-100 active:bg-slate-200 transition-colors disabled:opacity-0"
            >
              <Delete className="w-6 h-6" />
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
