import React, { useState, useEffect } from 'react';
import { Phone, Delete, UserX, Clock, LayoutGrid, RotateCcw, X, ChevronDown, ChevronRight, PhoneIncoming, PhoneMissed, PhoneOutgoing, Search } from 'lucide-react';
import { UserProfile } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { hapticFeedback } from '../utils/haptics';
import { tapScale, listStagger, listItemFade } from '../utils/animations';
import CachedImage from './CachedImage';
import PinPadModal from './PinPadModal';

interface DialerTabProps {
  profile: UserProfile;
  onCall: (number: string, callerNumber?: string) => Promise<void>;
  onGoToProfile: () => void;
  recentCalls?: RecentCall[];
  onSimulateIncoming?: () => void;
  callerIdentities?: CallerIdentity[];
}

export type RecentCall = { id: string; name: string; number: string; time: string; type: "missed" | "outgoing" | "incoming"; photo?: string };
export type CallerIdentity = { number: string; type: "permanent" | "temporary"; expiresAt?: number };
const RECENT_CALLS: RecentCall[] = [];

export default function DialerTab({ profile, onCall, onGoToProfile, recentCalls = RECENT_CALLS, onSimulateIncoming, callerIdentities = [] }: DialerTabProps) {
  const [number, setNumber] = useState('');
  const [showPinPad, setShowPinPad] = useState(false);
  const [showKeypad, setShowKeypad] = useState(true);
  const [isCalling, setIsCalling] = useState(false);
  const [historyQuery, setHistoryQuery] = useState('');
  const [selectedCall, setSelectedCall] = useState<RecentCall | null>(null);
  const [selectedCallerNumber, setSelectedCallerNumber] = useState<string | null>(null);
  const fallbackCallerIdentity = profile.virtualNumbers?.find(item => item.type === "primary" && item.status === "active")?.number;
  const availableCallerIdentities = callerIdentities.length ? callerIdentities : fallbackCallerIdentity ? [{ number: fallbackCallerIdentity, type: "permanent" as const }] : [];
  const selectedCallerIdentity = availableCallerIdentities.find(identity => identity.number === selectedCallerNumber) || availableCallerIdentities[0];

  const handleKeyPress = (key: string) => {
    if (number.length < 8) {
      setNumber(prev => prev + key);
      hapticFeedback.light();
    }
  };

  const handleDelete = () => {
    setNumber(prev => prev.slice(0, -1));
    hapticFeedback.light();
  };

  const handleCallClick = async () => {
    if (isCalling || (number.length !== 8 && number.length !== 7)) return;

    hapticFeedback.heavy();
    if (number.length === 7) {
      // Temporary numbers don't require PIN
      setIsCalling(true);
      try {
        await onCall(number, selectedCallerIdentity?.number);
      } finally {
        setIsCalling(false);
      }
    } else {
      setShowPinPad(true);
    }
  };

  const formatNumber = (num: string) => {
    if (num.length === 0) return "";
    if (num.length <= 4) return num;
    if (num.length === 7) return `${num.slice(0, 3)}-${num.slice(3)}`;
    return `${num.slice(0, 4)}-${num.slice(4)}`;
  };

  const normalizedHistoryQuery = historyQuery.trim().toLowerCase();
  const visibleRecentCalls = recentCalls.filter((call) =>
    !normalizedHistoryQuery
    || call.name.toLowerCase().includes(normalizedHistoryQuery)
    || call.number.includes(normalizedHistoryQuery)
  );

  const callTypeMeta = (type: RecentCall['type']) => {
    if (type === 'missed') return { label: 'Missed', Icon: PhoneMissed, accent: 'text-red-500', iconSurface: 'bg-red-50 text-red-500' };
    if (type === 'incoming') return { label: 'Incoming', Icon: PhoneIncoming, accent: 'text-emerald-600', iconSurface: 'bg-emerald-50 text-emerald-600' };
    return { label: 'Outgoing', Icon: PhoneOutgoing, accent: 'text-amber-700', iconSurface: 'bg-amber-50 text-amber-700' };
  };

  const openCallDetails = (call: RecentCall) => {
    setSelectedCall(call);
    setShowKeypad(false);
  };

  const useNumberFromDetails = () => {
    if (!selectedCall) return;
    setNumber(selectedCall.number);
    setSelectedCall(null);
    setShowKeypad(true);
  };

  return (
    <div className="flex-1 w-full bg-white flex flex-col relative overflow-hidden">
      {/* PIN Pad Modal Overlay */}
      {showPinPad && (
        <PinPadModal
          callerUid={profile.uid} 
          targetNumber={number}
          onSuccess={async () => {
            setShowPinPad(false);
            setIsCalling(true);
            try {
              await onCall(number, selectedCallerIdentity?.number);
            } finally {
              setIsCalling(false);
            }
          }}
          onCancel={() => setShowPinPad(false)}
        />
      )}

      {/* Top Header */}
      <div className="px-6 pt-12 pb-4 flex items-center justify-between z-10 bg-white shadow-[0_1px_3px_rgba(0,0,0,0.02)] border-b border-slate-100">
        <div className="min-w-0"><h1 className="text-[22px] font-semibold text-slate-900 tracking-tight">Phone</h1>{selectedCallerIdentity && <button type="button" onClick={() => { if (availableCallerIdentities.length < 2) return; const index = availableCallerIdentities.findIndex(identity => identity.number === selectedCallerIdentity.number); setSelectedCallerNumber(availableCallerIdentities[(index + 1) % availableCallerIdentities.length]?.number || null); hapticFeedback.light(); }} className={`mt-1 flex max-w-full items-center gap-1.5 rounded-lg text-left text-[11px] font-medium ${availableCallerIdentities.length > 1 ? "text-amber-700 active:bg-amber-50" : "text-slate-500"}`} aria-label={availableCallerIdentities.length > 1 ? "Change calling number" : "Calling number"}><span>Calling from {selectedCallerIdentity.type === "temporary" ? "temporary" : "permanent"}</span><span className="font-mono">{formatNumber(selectedCallerIdentity.number)}</span>{availableCallerIdentities.length > 1 && <ChevronDown className="h-3.5 w-3.5" />}</button>}</div>
        <button onClick={onGoToProfile} className="w-8 h-8 rounded-full overflow-hidden border border-slate-200 shadow-sm active:scale-95 transition-transform ripple">
          <CachedImage 
            src={profile.photoURL || `https://ui-avatars.com/api/?name=${profile.displayName}&background=f1f5f9&color=475569`} 
            alt="Profile" 
            className="w-full h-full object-cover" 
          />
        </button>
      </div>

      {/* Compact Call History (visible behind or when keypad is hidden) */}
      <div 
        className="flex-1 overflow-y-auto bg-white relative"
        onScroll={() => setShowKeypad(false)}
        onTouchMove={() => setShowKeypad(false)}
      >
        <div className="sticky top-0 z-10 border-b border-slate-100 bg-white/95 px-4 pb-2 pt-3 backdrop-blur-sm">
          <div className="mb-2 flex items-center justify-between">
            <h2 className="text-[15px] font-semibold tracking-tight text-slate-800">Call history</h2>
            {recentCalls.length > 0 && <span className="text-[11px] font-medium text-slate-400">{visibleRecentCalls.length} of {recentCalls.length}</span>}
          </div>
          <label className="flex h-9 items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3 transition-colors focus-within:border-amber-300 focus-within:bg-white">
            <Search className="h-4 w-4 shrink-0 text-slate-400" aria-hidden="true" />
            <input
              aria-label="Search call history"
              value={historyQuery}
              onChange={(event) => setHistoryQuery(event.target.value)}
              placeholder="Search name or number"
              className="min-w-0 flex-1 bg-transparent text-[13px] text-slate-700 outline-none placeholder:text-slate-400"
            />
          </label>
        </div>

        {recentCalls.length > 0 ? (
          visibleRecentCalls.length > 0 ? (
            <div data-testid="call-history-list" className="divide-y divide-slate-100">
              {visibleRecentCalls.map(call => {
                const meta = callTypeMeta(call.type);
                const CallIcon = meta.Icon;
                return (
                  <button
                    type="button"
                    key={call.id}
                    onClick={() => openCallDetails(call)}
                    aria-label={`Open call details for ${call.name}`}
                    className="ripple flex h-[64px] w-full items-center gap-3 px-4 text-left transition-colors active:bg-slate-50"
                  >
                    <div className={`h-9 w-9 shrink-0 overflow-hidden rounded-full flex items-center justify-center ${call.photo ? 'bg-slate-100' : meta.iconSurface}`}>
                      {call.photo ? (
                        <CachedImage src={call.photo} className="h-full w-full object-cover" />
                      ) : (
                        <CallIcon className="h-[18px] w-[18px]" strokeWidth={2.2} />
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <h4 className={`truncate text-[14px] font-semibold leading-5 ${call.type === 'missed' ? 'text-red-500' : 'text-slate-800'}`}>{call.name || formatNumber(call.number)}</h4>
                      <div className="flex min-w-0 items-center gap-1.5">
                        <CallIcon className={`h-3 w-3 shrink-0 ${meta.accent}`} strokeWidth={2.25} aria-hidden="true" />
                        <p className="truncate font-mono text-[11px] tracking-wide text-slate-500">{formatNumber(call.number)}</p>
                        <span className={`shrink-0 text-[10px] font-medium ${meta.accent}`}>{meta.label}</span>
                      </div>
                    </div>
                    <span className="shrink-0 text-right text-[11px] font-medium text-slate-400">{call.time}</span>
                    <ChevronRight className="h-4 w-4 shrink-0 text-slate-300" aria-hidden="true" />
                  </button>
                );
              })}
            </div>
          ) : (
            <div className="flex min-h-36 flex-col items-center justify-center px-6 text-center">
              <Search className="mb-2 h-5 w-5 text-slate-300" aria-hidden="true" />
              <p className="text-[13px] font-medium text-slate-500">No matching calls</p>
              <p className="mt-0.5 text-[11px] text-slate-400">Try a different name or number.</p>
            </div>
          )
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center h-full text-slate-400">
            <Clock className="w-12 h-12 mb-4 opacity-20" />
            <p>No recent calls</p>
            {onSimulateIncoming && <button onClick={onSimulateIncoming} className="mt-4 rounded-full border border-slate-200 bg-white px-4 py-2 text-[12px] font-semibold text-slate-600 shadow-sm active:bg-slate-50">Simulate incoming call</button>}
          </div>
        )}
      </div>

      <AnimatePresence>
        {selectedCall && (() => {
          const meta = callTypeMeta(selectedCall.type);
          const CallIcon = meta.Icon;
          return (
            <motion.div
              data-testid="call-history-details"
              className="absolute inset-0 z-40 flex items-end bg-slate-900/20"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedCall(null)}
            >
              <motion.section
                role="dialog"
                aria-label="Call details"
                className="w-full rounded-t-[28px] bg-white px-5 pb-6 pt-3 shadow-2xl"
                initial={{ y: 48 }}
                animate={{ y: 0 }}
                exit={{ y: 48 }}
                transition={{ type: 'spring', stiffness: 360, damping: 30 }}
                onClick={(event) => event.stopPropagation()}
              >
                <div className="mx-auto mb-4 h-1 w-9 rounded-full bg-slate-200" />
                <div className="flex items-start gap-3">
                  <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-full ${selectedCall.photo ? 'overflow-hidden bg-slate-100' : meta.iconSurface}`}>
                    {selectedCall.photo ? <CachedImage src={selectedCall.photo} className="h-full w-full object-cover" /> : <CallIcon className="h-5 w-5" strokeWidth={2.25} />}
                  </div>
                  <div className="min-w-0 flex-1">
                    <h3 className="truncate text-[17px] font-semibold text-slate-900">{selectedCall.name || formatNumber(selectedCall.number)}</h3>
                    <p className="mt-0.5 font-mono text-[13px] tracking-wide text-slate-500">{formatNumber(selectedCall.number)}</p>
                  </div>
                  <button onClick={() => setSelectedCall(null)} aria-label="Close call details" className="-mr-2 -mt-1 rounded-full p-2 text-slate-400 active:bg-slate-100">
                    <X className="h-5 w-5" />
                  </button>
                </div>
                <div className="my-5 grid grid-cols-2 gap-3 border-y border-slate-100 py-4 text-[12px]">
                  <div>
                    <p className="text-slate-400">Call type</p>
                    <p className={`mt-1 flex items-center gap-1 font-semibold ${meta.accent}`}><CallIcon className="h-3.5 w-3.5" />{meta.label}</p>
                  </div>
                  <div>
                    <p className="text-slate-400">Time / date</p>
                    <p className="mt-1 font-semibold text-slate-700">{selectedCall.time}</p>
                  </div>
                </div>
                <button onClick={useNumberFromDetails} className="ripple flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-amber-500 text-[13px] font-semibold text-white shadow-sm shadow-amber-500/20 active:scale-[0.98] transition-transform">
                  <Phone className="h-4 w-4 fill-white" /> Use number in Dialer
                </button>
              </motion.section>
            </motion.div>
          );
        })()}
      </AnimatePresence>

      {/* Floating Action Button (to show keypad if hidden) */}
      {!showKeypad && (
        <button 
          onClick={() => setShowKeypad(true)}
          aria-label="Show Dial Pad"
          className="!absolute bottom-[max(1.5rem,env(safe-area-inset-bottom,0px))] left-[max(1.5rem,env(safe-area-inset-left,0px))] w-14 h-14 bg-amber-500 rounded-[16px] flex items-center justify-center shadow-lg shadow-amber-500/20 active:scale-95 transition-transform ripple z-20 text-white"
        >
          <LayoutGrid className="w-6 h-6" />
        </button>
      )}

      {/* Keypad Surface */}
      <div 
        className={`bg-white z-30 transition-transform duration-300 ease-out border-t border-slate-100 shadow-[0_-4px_20px_rgba(0,0,0,0.03)] flex flex-col ${showKeypad ? 'translate-y-0' : 'translate-y-[calc(100%+24px)] absolute bottom-0 left-0 right-0'}`}
      >
        {/* Number Display */}
        <div className="h-16 flex items-center justify-center relative px-5 w-full shrink-0">
           <h2 className={`text-[30px] font-mono tracking-widest text-slate-800 font-light w-full text-center leading-none ${number.length === 0 ? 'opacity-0' : ''}`}>
             <AnimatePresence mode="popLayout">
               {number.split('').map((char, i) => (
                 <motion.span 
                   key={i} 
                   initial={{ opacity: 0, y: 10, scale: 0.9 }} 
                   animate={{ opacity: 1, y: 0, scale: 1 }} 
                   exit={{ opacity: 0, y: -10, scale: 0.9 }}
                   transition={{ duration: 0.15 }}
                   className="inline-block"
                 >
                   {i === 4 ? '-' + char : char}
                 </motion.span>
               ))}
             </AnimatePresence>
             {number.length === 0 && '0'}
           </h2>
           <motion.button 
             whileTap={tapScale}
             onClick={handleDelete}
             onContextMenu={(e) => { e.preventDefault(); setNumber(''); hapticFeedback.medium(); }} // Long press to clear
             className={`absolute right-3 p-3 rounded-full active:bg-slate-100 transition-colors text-slate-400 ripple select-none tap-highlight-transparent ${number.length > 0 ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
           >
             <Delete className="w-6 h-6" />
           </motion.button>
        </div>

        {/* Keypad Grid */}
        <div className="px-5 pb-3 pt-0">
          <div className="grid grid-cols-3 gap-y-0.5 gap-x-2 max-w-[240px] mx-auto">
            {[
              { num: '1', letters: '' }, { num: '2', letters: 'ABC' }, { num: '3', letters: 'DEF' },
              { num: '4', letters: 'GHI' }, { num: '5', letters: 'JKL' }, { num: '6', letters: 'MNO' },
              { num: '7', letters: 'PQRS' }, { num: '8', letters: 'TUV' }, { num: '9', letters: 'WXYZ' },
              { num: '*', letters: '' }, { num: '0', letters: '+' }, { num: '#', letters: '' }
            ].map((key) => (
              <motion.button
                whileTap={tapScale}
                key={key.num}
                onClick={() => handleKeyPress(key.num)}
                className="h-12 rounded-2xl flex flex-col justify-center items-center active:bg-slate-100 transition-colors ripple select-none tap-highlight-transparent"
              >
                <span className="text-[26px] font-normal text-slate-800 leading-none">{key.num}</span>
                {key.letters && <span className="text-[8px] font-semibold text-slate-400 tracking-[0.1em] mt-0.5">{key.letters}</span>}
              </motion.button>
            ))}
          </div>
          
          <div className="flex items-center justify-between mt-2 max-w-[240px] mx-auto px-2">
             <button 
               onClick={() => setShowKeypad(false)}
               className="p-2.5 text-slate-400 active:bg-slate-100 rounded-full transition-colors ripple select-none tap-highlight-transparent"
               aria-label="Hide keypad"
             >
                <X className="w-6 h-6" />
             </button>
             
             <button 
               disabled={isCalling || (number.length !== 8 && number.length !== 7)}
               onClick={handleCallClick}
               className="w-14 h-14 bg-amber-500 rounded-full flex items-center justify-center shadow-lg shadow-amber-500/20 active:scale-95 transition-all disabled:opacity-50 disabled:shadow-none ripple select-none tap-highlight-transparent"
             >
               <Phone className="w-7 h-7 text-white fill-white" />
             </button>

             <div className="w-11"></div> {/* Spacer for centering */}
          </div>
        </div>
      </div>
    </div>
  );
}
