import { UserProfile } from "../types";
import { 
  ArrowLeft, ChevronRight, Copy, Check, Crown, Eye, EyeOff,
  PhoneCall, ShieldCheck, Hash, Settings, 
  HelpCircle, LogOut, Trash2, Edit2, MinusCircle, 
  Bell, Music, MonitorSmartphone, Ban, RefreshCw, 
  Activity, Smartphone, Globe, HardDrive, Info, ShieldAlert,
  FileText, History, PhoneForwarded, Wallet, CreditCard,
  Shield
} from "lucide-react";
import CachedImage from "./CachedImage";
import { motion, AnimatePresence } from "motion/react";
import { pageTransition, tapScale, dialogTransition } from "../utils/animations";
import { hapticFeedback } from "../utils/haptics";
import PlanSelection from "./PlanSelection";
import React, { useState, useEffect, useRef } from "react";
import { auth, db } from "../firebase";
import { deleteUser } from "firebase/auth";
import { doc, deleteDoc, updateDoc, setDoc } from "firebase/firestore";
import { secureApi } from "../services/secureApi";
import { scheduleCallingPinMask } from "../utils/callingPinVisibility";

interface ProfileTabProps {
  onOpenBlockedUsers: () => void;
  onOpenNotificationSettings: () => void;
  onToggleDND: (enabled: boolean) => void;
  profile: UserProfile;
  onOpenChangePin: () => void;
  onOpenEditProfile: () => void;
  onOpenDevices: () => void;
  onOpenNumberChange: () => void;
  onOpenHelloTune: () => void;
}

type SubView = 'main' | 'recharge' | 'calling' | 'security' | 'virtual_number' | 'vip' | 'app_settings' | 'help';

export default function ProfileTab({ 
  profile, onOpenChangePin, onOpenEditProfile, onOpenDevices, 
  onOpenNumberChange, onOpenHelloTune, onOpenBlockedUsers, 
  onOpenNotificationSettings, onToggleDND 
}: ProfileTabProps) {
  
  const [currentView, setCurrentView] = useState<SubView>('main');
  const [copiedNum, setCopiedNum] = useState(false);
  const [showLogout, setShowLogout] = useState(false);
  const [showDelete, setShowDelete] = useState(false);
  const [now, setNow] = useState(Date.now());
  const [visibleCallingPin, setVisibleCallingPin] = useState<string | null>(null);
  const [isPinRevealLoading, setIsPinRevealLoading] = useState(false);
  const pinHideTimer = useRef<number | null>(null);

  useEffect(() => {
    const interval = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => () => {
    if (pinHideTimer.current) window.clearTimeout(pinHideTimer.current);
  }, []);

  const primaryNum = profile?.virtualNumbers?.find(n => n.type === 'primary')?.number || "No Number";

  const handleCopyNum = () => {
    navigator.clipboard.writeText(primaryNum);
    setCopiedNum(true);
    setTimeout(() => setCopiedNum(false), 2000);
  };

  const hideCallingPin = () => {
    if (pinHideTimer.current) window.clearTimeout(pinHideTimer.current);
    pinHideTimer.current = null;
    setVisibleCallingPin(null);
  };

  const toggleCallingPin = async () => {
    if (visibleCallingPin) {
      hideCallingPin();
      return;
    }
    setIsPinRevealLoading(true);
    try {
      const { pin } = await secureApi.pin.revealOwn.mutate({});
      setVisibleCallingPin(pin);
      pinHideTimer.current = scheduleCallingPinMask(hideCallingPin);
    } catch {
      alert("Your Calling PIN could not be revealed. You can still change or reset it.");
    } finally {
      setIsPinRevealLoading(false);
    }
  };

  const handleLogout = () => {
    auth.signOut();
  };

  const handleDeleteAccount = async () => {
    if (auth.currentUser) {
      try {
        await deleteDoc(doc(db, "users", profile.uid));
        await deleteUser(auth.currentUser);
      } catch (err) {
        console.error("Failed to delete account", err);
        alert("Failed to delete account. You may need to re-authenticate.");
      }
    }
  };

  const Header = ({ title }: { title: string }) => (
    <div className="flex items-center px-4 pt-12 pb-4 bg-slate-50 sticky top-0 z-20 border-b border-slate-200 shadow-sm">
      <button onClick={() => setCurrentView('main')} className="p-2 -ml-2 rounded-full active:bg-slate-200 transition-colors ripple select-none tap-highlight-transparent text-slate-700">
        <ArrowLeft className="w-6 h-6" />
      </button>
      <h1 className="text-[20px] font-medium text-slate-900 ml-2">{title}</h1>
    </div>
  );

  const SectionTitle = ({ title }: { title: string }) => (
    <div className="px-6 py-3 bg-slate-50 border-b border-slate-100 flex items-center">
      <h3 className="text-[13px] font-semibold tracking-wider text-amber-700 uppercase">{title}</h3>
    </div>
  );

  const ListItem = ({ icon: Icon, title, subtitle, onClick, value, badge, isDestructive, hideArrow }: any) => (
    <button 
      onClick={onClick}
      className="w-full flex items-center px-6 py-4 bg-white active:bg-slate-100 transition-colors text-left ripple select-none tap-highlight-transparent relative"
    >
      <Icon className={`w-6 h-6 mr-4 flex-shrink-0 ${isDestructive ? 'text-red-500' : 'text-slate-500'}`} />
      <div className="flex-1 min-w-0 pr-4">
        <div className="flex items-center gap-2">
          <p className={`text-[16px] font-normal truncate ${isDestructive ? 'text-red-600' : 'text-slate-900'}`}>{title}</p>
          {badge && <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-700 uppercase tracking-wide">{badge}</span>}
        </div>
        {subtitle && <p className="text-[14px] text-slate-500 truncate mt-0.5">{subtitle}</p>}
      </div>
      <div className="flex items-center gap-3 flex-shrink-0">
        {value}
        {!hideArrow && !isDestructive && <ChevronRight className="w-5 h-5 text-slate-300" />}
      </div>
    </button>
  );

  const renderRecharge = () => {
    return <PlanSelection profile={profile} onClose={() => setCurrentView('main')} onOpenHelloTune={onOpenHelloTune} />;
  };

  const renderCalling = () => (
    <div className="flex-1 flex flex-col bg-slate-50 overflow-y-auto animate-in fade-in duration-200">
      <Header title="Calling Settings" />
      <div className="divide-y divide-slate-100 bg-white border-b border-slate-200">
        <ListItem 
          icon={MinusCircle} 
          title="Do Not Disturb" 
          subtitle="Block incoming calls"
          onClick={() => {
            const current = profile.dndEnabled;
            onToggleDND(!current);
            alert(`Do Not Disturb turned ${!current ? 'ON' : 'OFF'}`);
          }}
          value={
            <div className={`w-10 h-6 rounded-full transition-colors flex items-center px-1 ${profile.dndEnabled ? 'bg-amber-500' : 'bg-slate-200'}`}>
              <div className={`w-4 h-4 bg-white rounded-full transition-transform ${profile.dndEnabled ? 'translate-x-4' : 'translate-x-0'}`}></div>
            </div>
          }
          hideArrow={true}
        />
        <ListItem 
          icon={Bell} 
          title="Call Notifications" 
          subtitle="Ringtone, vibration"
          onClick={onOpenNotificationSettings}
        />
        <ListItem 
          icon={PhoneForwarded} 
          title="Call Waiting" 
          subtitle="Unavailable on current plan"
          onClick={() => alert("Call Waiting configuration is currently under development.")}
        />
        <ListItem 
          icon={History} 
          title="Call History" 
          onClick={() => alert("Call History is currently under development.")}
        />
      </div>
    </div>
  );

  const renderSecurity = () => (
    <div className="flex-1 flex flex-col bg-slate-50 overflow-y-auto animate-in fade-in duration-200">
      <Header title="Security & Privacy" />
      <div className="divide-y divide-slate-100 bg-white border-b border-slate-200">
        <ListItem 
          icon={MonitorSmartphone} 
          title="Logged-in Devices" 
          subtitle="Manage active sessions"
          onClick={onOpenDevices}
        />
        <ListItem 
          icon={ShieldCheck} 
          title="Account Security" 
          subtitle="Status is Good"
          onClick={() => alert("Security status is currently good. Advanced settings in development.")}
          value={<span className="text-emerald-600 font-semibold text-[14px]">Good</span>}
        />
        <ListItem 
          icon={Ban} 
          title="Blocked Users" 
          onClick={onOpenBlockedUsers}
        />
        <ListItem 
          icon={Activity} 
          title="Recent Activity" 
          onClick={() => alert("Recent Activity logs are currently under development.")}
        />
      </div>
    </div>
  );

  const renderVirtualNumber = () => (
    <div className="flex-1 flex flex-col bg-slate-50 overflow-y-auto animate-in fade-in duration-200">
      <Header title="Virtual Number" />
      <div className="divide-y divide-slate-100 bg-white border-b border-slate-200">
        <ListItem 
          icon={RefreshCw} 
          title="Change Virtual Number" 
          onClick={onOpenNumberChange}
        />
        {(profile?.virtualNumbers || []).map(vn => (
          <ListItem 
            key={vn.number}
            icon={vn.type === 'vip' ? Crown : Hash} 
            title={`${vn.number.slice(0,4)}-${vn.number.slice(4)}`}
            subtitle={vn.type === 'primary' ? 'Primary Number' : (vn.type === 'secondary' ? 'Secondary Number' : (vn.type === 'vip' ? 'VIP Number' : 'Virtual Number'))}
            onClick={() => alert(`Number details: ${vn.number.slice(0,4)}-${vn.number.slice(4)}\n\nUse the system share or copy functions.`)}
            badge={vn.type === 'vip' ? 'Owned' : (vn.type === 'primary' ? 'Active' : '')}
          />
        ))}
      </div>
    </div>
  );

  const renderAppSettings = () => (
    <div className="flex-1 flex flex-col bg-slate-50 overflow-y-auto animate-in fade-in duration-200">
      <Header title="App Settings" />
      <div className="divide-y divide-slate-100 bg-white border-b border-slate-200">
        <ListItem 
          icon={Smartphone} 
          title="Appearance" 
          subtitle="System Default"
          onClick={() => alert("Appearance settings are currently under development.")}
        />
        <ListItem 
          icon={Globe} 
          title="Language" 
          subtitle="English"
          onClick={() => alert("Language options are currently under development.")}
        />
        <ListItem 
          icon={HardDrive} 
          title="Data & Storage" 
          onClick={() => alert("Storage usage metrics are currently under development.")}
        />
      </div>
    </div>
  );

  const renderHelp = () => (
    <div className="flex-1 flex flex-col bg-slate-50 overflow-y-auto animate-in fade-in duration-200">
      <Header title="Help & Legal" />
      <div className="divide-y divide-slate-100 bg-white border-b border-slate-200">
        <ListItem 
          icon={HelpCircle} 
          title="Help & Support" 
          onClick={() => alert("Help and Support center is currently under development.")}
        />
        <ListItem 
          icon={ShieldAlert} 
          title="Report a Problem" 
          onClick={() => alert("Problem reporting is currently under development.")}
        />
        <ListItem 
          icon={FileText} 
          title="Privacy Policy" 
          onClick={() => alert("Privacy Policy is currently under development.")}
        />
        <ListItem 
          icon={FileText} 
          title="Terms of Service" 
          onClick={() => alert("Terms of Service is currently under development.")}
        />
        <ListItem 
          icon={Info} 
          title="About" 
          subtitle="Version 1.0.0"
          onClick={() => alert("App version 1.0.0.")}
        />
      </div>
    </div>
  );

  if (currentView !== 'main') {
    return (
      <AnimatePresence mode="wait">
      <motion.div key={currentView} variants={pageTransition} initial="initial" animate="animate" exit="exit" className="flex-1 flex flex-col relative bg-slate-50 z-10 h-full w-full absolute inset-0">
        {currentView === 'recharge' && renderRecharge()}
        {currentView === 'calling' && renderCalling()}
        {currentView === 'security' && renderSecurity()}
        {currentView === 'virtual_number' && renderVirtualNumber()}
        {currentView === 'app_settings' && renderAppSettings()}
        {currentView === 'help' && renderHelp()}
      </motion.div>
      </AnimatePresence>
    );
  }

  return (
    <div className="flex-1 w-full bg-slate-50 flex flex-col relative overflow-hidden">
      
      <AnimatePresence>
      {showLogout && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={() => setShowLogout(false)}></motion.div>
          <motion.div variants={dialogTransition} initial="initial" animate="animate" exit="exit" className="bg-white rounded-2xl p-6 max-w-sm w-full shadow-2xl relative z-10">
            <h3 className="text-xl font-bold text-slate-900 mb-2">Log out?</h3>
            <p className="text-slate-500 mb-6 text-sm">You will need your current Calling PIN to log back in.</p>
            <div className="flex justify-end gap-3">
              <motion.button whileTap={tapScale} onClick={() => { hapticFeedback.light(); setShowLogout(false); }} className="px-5 py-2.5 rounded-full font-medium text-slate-700 active:bg-slate-100 ripple">Cancel</motion.button>
              <motion.button whileTap={tapScale} onClick={() => { hapticFeedback.medium(); handleLogout(); }} className="px-5 py-2.5 rounded-full font-medium text-white bg-amber-500 active:bg-amber-600 ripple">Log out</motion.button>
            </div>
          </motion.div>
        </div>
      )}
      </AnimatePresence>

      <AnimatePresence>
      {showDelete && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={() => setShowDelete(false)}></motion.div>
          <motion.div variants={dialogTransition} initial="initial" animate="animate" exit="exit" className="bg-white rounded-2xl p-6 max-w-sm w-full shadow-2xl relative z-10">
            <h3 className="text-xl font-bold text-slate-900 mb-2">Delete Account?</h3>
            <p className="text-slate-500 mb-6 text-sm">This action is permanent and cannot be undone.</p>
            <div className="flex justify-end gap-3">
              <motion.button whileTap={tapScale} onClick={() => { hapticFeedback.light(); setShowDelete(false); }} className="px-5 py-2.5 rounded-full font-medium text-slate-700 active:bg-slate-100 ripple">Cancel</motion.button>
              <motion.button whileTap={tapScale} onClick={() => { hapticFeedback.heavy(); handleDeleteAccount(); }} className="px-5 py-2.5 rounded-full font-medium text-white bg-red-500 active:bg-red-600 ripple">Delete</motion.button>
            </div>
          </motion.div>
        </div>
      )}
      </AnimatePresence>

      <div className="flex-1 overflow-y-auto pb-24">
        {/* Android Native Header / Identity */}
        <div className="bg-white px-6 pt-16 pb-8 border-b border-slate-200">
          <div className="flex items-center gap-6">
            <div className="relative">
              <div className="w-20 h-20 rounded-full overflow-hidden bg-slate-100 border border-slate-200">
                <CachedImage 
                  src={profile.photoURL || `https://ui-avatars.com/api/?name=${profile.displayName}&background=f8f9fc&color=475569`} 
                  className="w-full h-full object-cover" 
                />
              </div>
              {profile.isVIP && (
                <div className="absolute -bottom-1 -right-1 bg-slate-900 text-amber-400 w-7 h-7 rounded-full flex items-center justify-center border-2 border-white">
                  <Crown className="w-3 h-3" />
                </div>
              )}
            </div>
            
            <div className="flex-1 min-w-0">
              <h2 className="text-[24px] font-normal text-slate-900 truncate mb-1">{profile.displayName}</h2>
              <button onClick={onOpenEditProfile} className="text-[14px] text-amber-600 font-medium active:text-amber-700">
                Edit Profile
              </button>
            </div>
          </div>
          
          <div className="mt-8 grid grid-cols-1 gap-3 min-[560px]:grid-cols-2 min-[560px]:gap-4">
            <div className="min-w-0 rounded-xl border border-slate-100/50 bg-slate-50 p-4">
              <p className="mb-2 truncate text-[11px] font-bold uppercase tracking-widest text-slate-500">Virtual Number</p>
              <div className="flex min-w-0 items-center gap-2">
                 <p title={primaryNum} className="min-w-0 flex-1 truncate whitespace-nowrap text-[18px] font-mono tracking-wide text-slate-900">{primaryNum}</p>
                 <button onClick={handleCopyNum} className="ripple flex h-9 w-9 shrink-0 items-center justify-center rounded-full p-2 text-slate-400 transition-colors active:bg-slate-200" aria-label="Copy virtual number">
                   {copiedNum ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                 </button>
              </div>
            </div>
            
            <div className="min-w-0 rounded-xl border border-slate-100/50 bg-slate-50 p-4">
              <p className="mb-2 truncate text-[11px] font-bold uppercase tracking-widest text-slate-500">Calling PIN</p>
              <div className="flex min-w-0 items-center gap-3">
                 <div className="min-w-0 flex-1">
                   <AnimatePresence mode="wait" initial={false}>
                     <motion.p key={visibleCallingPin || "masked"} initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }} transition={{ duration: 0.16 }} className="truncate whitespace-nowrap text-[18px] font-mono tracking-widest text-slate-900">{visibleCallingPin || "••••••••"}</motion.p>
                   </AnimatePresence>
                   <p className="mt-1 line-clamp-2 text-[11px] leading-4 text-slate-500">{visibleCallingPin ? "Hides automatically in 5 seconds" : "Protected — tap the eye to reveal briefly"}</p>
                 </div>
                 <div className="flex shrink-0 items-center gap-1">
                   <button onClick={() => void toggleCallingPin()} disabled={isPinRevealLoading} className="ripple flex h-9 w-9 items-center justify-center rounded-full p-2 text-slate-400 transition-colors active:bg-slate-200 disabled:opacity-50" aria-label={visibleCallingPin ? "Hide calling PIN" : "Reveal calling PIN"}>
                     {isPinRevealLoading ? <span className="block w-4 h-4 rounded-full border-2 border-slate-300 border-t-amber-500 animate-spin" /> : visibleCallingPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                   </button>
                   <button onClick={onOpenChangePin} className="ripple flex h-9 w-9 items-center justify-center rounded-full p-2 text-slate-400 transition-colors active:bg-slate-200" aria-label="Change calling PIN">
                     <Edit2 className="w-4 h-4" />
                   </button>
                 </div>
              </div>
            </div>
          </div>
          {profile.activeTemporaryNumber?.status === "active" && profile.activeTemporaryNumber.expiresAt > now && <div className="mt-3 rounded-xl border border-amber-100 bg-amber-50/60 px-4 py-3"><p className="text-[11px] font-bold uppercase tracking-widest text-amber-700">Active Temporary Number</p><p className="mt-1 font-mono text-[17px] tracking-wide text-slate-900">{profile.activeTemporaryNumber.number.slice(0, 3)}-{profile.activeTemporaryNumber.number.slice(3)}</p><p className="mt-1 text-[11px] leading-4 text-slate-600">Active until {new Date(profile.activeTemporaryNumber.expiresAt).toLocaleString()}</p></div>}
        </div>

        {/* Settings List */}
        <div className="mt-4 bg-white border-y border-slate-200 divide-y divide-slate-100">
          <ListItem 
            icon={Wallet} 
            title="Recharge" 
            onClick={() => setCurrentView('recharge')}
          />
          <ListItem 
            icon={PhoneCall} 
            title="Calling" 
            onClick={() => setCurrentView('calling')}
          />
          <ListItem 
            icon={Shield} 
            title="Security" 
            onClick={() => setCurrentView('security')}
          />
          <ListItem 
            icon={Hash} 
            title="Virtual Number" 
            onClick={() => setCurrentView('virtual_number')}
          />
        </div>

        <div className="mt-6 bg-white border-y border-slate-200 divide-y divide-slate-100">
          <ListItem 
            icon={Settings} 
            title="App Settings" 
            onClick={() => setCurrentView('app_settings')}
          />
          <ListItem 
            icon={HelpCircle} 
            title="Help & Legal" 
            onClick={() => setCurrentView('help')}
          />
        </div>
        
        <div className="mt-6 mb-8 bg-white border-y border-slate-200 divide-y divide-slate-100">
          <ListItem 
            icon={LogOut} 
            title="Log Out" 
            onClick={() => setShowLogout(true)}
            hideArrow={true}
          />
          <ListItem 
            icon={Trash2} 
            title="Delete Account" 
            onClick={() => setShowDelete(true)}
            isDestructive={true}
            hideArrow={true}
          />
        </div>
        
      </div>
    </div>
  );
}
