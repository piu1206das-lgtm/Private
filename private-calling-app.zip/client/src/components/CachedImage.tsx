import React, { useState, useEffect } from "react";

interface CachedImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string;
  className?: string;
  alt?: string;
}

export default function CachedImage({ src, ...props }: CachedImageProps) {
  const [cachedSrc, setCachedSrc] = useState<string | null>(null);
  
  useEffect(() => {
    if (!src) return;
    const cacheKey = `img_cache_${src}`;
    const cached = localStorage.getItem(cacheKey);
    if (cached) {
      setCachedSrc(cached);
      return;
    }
    setCachedSrc(src);
  }, [src]);

  return <img src={cachedSrc || src} {...props} />;
}
