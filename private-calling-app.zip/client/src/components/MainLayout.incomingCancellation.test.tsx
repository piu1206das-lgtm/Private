// @vitest-environment jsdom
import React from "react";
import { act, cleanup, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { onSnapshot } from "firebase/firestore";
import MainLayout from "./MainLayout";

vi.mock("../firebase", () => ({ db: {} }));
vi.mock("firebase/firestore", () => ({ collection: vi.fn(() => ({})), query: vi.fn(() => ({ kind: "ringing-query" })), where: vi.fn(() => ({})), doc: vi.fn(() => ({ kind: "call-document" })), onSnapshot: vi.fn(() => () => undefined), updateDoc: vi.fn() }));
vi.mock("../services/secureApi", () => ({ secureApi: { contacts: { list: { query: vi.fn(() => Promise.resolve([])) } }, calls: { transition: { mutate: vi.fn() } } } }));
vi.mock("../services/backend", () => ({ blockUser: vi.fn(), reportUser: vi.fn(), startCallSession: vi.fn(), unblockUser: vi.fn(), updateCallSession: vi.fn(), updateDND: vi.fn(), getPinCooldown: vi.fn(() => Promise.resolve(0)), validatePinAndRecordAttempt: vi.fn() }));
vi.mock("../services/callMedia", () => ({ CallMediaSession: vi.fn() }));
vi.mock("../utils/haptics", () => ({ hapticFeedback: { light: vi.fn(), medium: vi.fn(), heavy: vi.fn(), success: vi.fn(), error: vi.fn() } }));
vi.mock("./BottomNav", () => ({ default: () => null }));
vi.mock("./ContactsTab", () => ({ default: () => null }));
vi.mock("./ProfileTab", () => ({ default: () => null }));
vi.mock("./PlanSelection", () => ({ default: () => null }));
vi.mock("./HelloTuneTab", () => ({ default: () => null }));
vi.mock("./Modals", () => ({ EditProfileModal: () => null, ChangePinModal: () => null, Toast: () => null }));
vi.mock("./ProfileModals", () => ({ DevicesModal: () => null, NumberChangeRequestModal: () => null, BlockedUsersModal: () => null, NotificationSettingsModal: () => null, ReportModal: () => null }));
vi.mock("./CachedImage", () => ({ default: () => null }));

const profile = { uid: "receiver", displayName: "Receiver", virtualNumbers: [], dndEnabled: false } as any;

beforeEach(() => vi.useFakeTimers());
afterEach(() => { cleanup(); vi.useRealTimers(); });

describe("incoming alert terminal synchronization", () => {
  it("keeps an accepted incoming call visible when ringing clears, then closes only after a terminal call record", () => {
    let ringingListener: ((snapshot: any) => void) | undefined;
    let callListener: ((snapshot: any) => void) | undefined;
    vi.mocked(onSnapshot).mockImplementation((reference: any, listener) => {
      if (reference.kind === "ringing-query") ringingListener = listener as (snapshot: any) => void;
      else callListener = listener as (snapshot: any) => void;
      return () => undefined;
    });
    render(<MainLayout user={{} as any} profile={profile} onProfileUpdate={vi.fn()} />);
    act(() => ringingListener?.({ empty: false, docs: [{ id: "call-1", data: () => ({ callerNumber: "12345678", receiverNumber: "87654321" }) }] }));
    expect(screen.getByText("Incoming call")).toBeTruthy();
    act(() => ringingListener?.({ empty: true, docs: [] }));
    expect(screen.getByText("Incoming call")).toBeTruthy();
    act(() => callListener?.({ exists: () => true, data: () => ({ status: "connecting" }) }));
    expect(screen.getByText("Connecting…")).toBeTruthy();
    act(() => callListener?.({ exists: () => true, data: () => ({ status: "cancelled" }) }));
    expect(screen.getByText("Call cancelled")).toBeTruthy();
    act(() => vi.advanceTimersByTime(1500));
    expect(screen.queryByText("Call cancelled")).toBeNull();
  });
});
