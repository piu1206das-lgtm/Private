import { UserProfile, DeviceSession, HelloTune } from "../types";
import { X, Save, Bell, ShieldCheck, MonitorSmartphone, RefreshCw, Ban, AlertCircle, Unlock, Info, Smartphone, Video, Loader2, Search } from "lucide-react";
import React, { useState } from "react";
import { auth, db } from "../firebase";
import { updateDoc, doc, arrayRemove, serverTimestamp } from "firebase/firestore";
import { hashPin } from "../utils/crypto";
import CachedImage from "./CachedImage";
import { motion } from "motion/react";
import { bottomSheetTransition, dialogTransition, tapScale } from "../utils/animations";
import { hapticFeedback } from "../utils/haptics";
import type { ReportCategory } from "../services/backend";
import { shouldDismissBottomSheet } from "../utils/bottomSheetGestures";

// Base Bottom Sheet Wrapper
export const BottomSheet = ({ children, onClose, title, icon: Icon, description, dragToDismiss = false }: any) => (
  <div className="fixed inset-0 z-[100] flex flex-col justify-end">
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm" onClick={onClose}></motion.div>
    <motion.div data-testid="bottom-sheet" data-drag-dismiss={dragToDismiss ? "true" : "false"} variants={bottomSheetTransition} initial="initial" animate="animate" exit="exit" drag={dragToDismiss ? "y" : false} dragConstraints={{ top: 0, bottom: 0 }} dragElastic={{ top: 0, bottom: 0.34 }} dragMomentum={false} dragSnapToOrigin={dragToDismiss} onDragEnd={(_, info) => { if (dragToDismiss && shouldDismissBottomSheet(info.offset.y, info.velocity.y)) onClose(); }} className="bg-slate-50 w-full rounded-t-[32px] shadow-2xl relative z-10 flex flex-col max-h-[90vh] overflow-hidden touch-pan-y">
      
      {/* Handle */}
      <div className="w-full flex justify-center pt-4 pb-2">
        <div className="w-12 h-1.5 bg-slate-200 rounded-full"></div>
      </div>

      {/* Header */}
      <div className="px-6 pb-4 border-b border-slate-100 flex items-start justify-between shrink-0 bg-slate-50">
        <div className="flex gap-4 items-center">
          {Icon && (
            <div className="w-12 h-12 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center shrink-0">
               <Icon className="w-6 h-6" />
            </div>
          )}
          <div>
            <h2 className="text-xl font-bold text-slate-900">{title}</h2>
            {description && <p className="text-sm font-medium text-slate-500 mt-0.5">{description}</p>}
          </div>
        </div>
        <motion.button aria-label="Close sheet" whileTap={tapScale} onClick={() => { hapticFeedback.light(); onClose(); }} className="p-2 bg-slate-200/50 rounded-full text-slate-500 hover:bg-slate-200 transition-colors ripple">
          <X className="w-5 h-5" />
        </motion.button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto bg-slate-50">
         {children}
      </div>
    </motion.div>
  </div>
);


export function DevicesModal({ profile, onClose, onLogoutDevice }: { profile: UserProfile, onClose: () => void, onLogoutDevice: (s: DeviceSession) => void }) {
  return (
    <BottomSheet title="Logged-in Devices" description="Manage active sessions" icon={MonitorSmartphone} onClose={onClose}>
      <div className="p-5 space-y-4">
        {profile.sessions?.map(session => (
          <div key={session.sessionId} className="bg-white p-4 rounded-3xl shadow-sm border border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center shrink-0">
                <Smartphone className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="font-bold text-slate-900">{session.deviceName}</p>
                <p className="text-xs font-medium text-slate-400 mt-0.5 flex gap-2">
                  <span>{new Date(session.lastActive).toLocaleDateString()}</span>
                  {session.sessionId === localStorage.getItem("current_session_id") && (
                     <span className="text-green-600 bg-green-50 px-2 py-0.5 rounded-md font-bold">This Device</span>
                  )}
                </p>
              </div>
            </div>
            {session.sessionId !== localStorage.getItem("current_session_id") && (
              <button 
                onClick={() => onLogoutDevice(session)}
                className="px-4 py-2 bg-slate-100 hover:bg-red-50 text-slate-700 hover:text-red-600 rounded-full text-sm font-bold transition-colors active:scale-95 ripple"
              >
                Logout
              </button>
            )}
          </div>
        ))}
        {(!profile.sessions || profile.sessions.length === 0) && (
          <div className="text-center p-8 text-slate-400">
             <p className="font-medium">No active sessions found.</p>
          </div>
        )}
      </div>
    </BottomSheet>
  );
}

export function NumberChangeRequestModal({ profile, onClose, onRequest }: { profile: UserProfile, onClose: () => void, onRequest: (reason: string) => void }) {
  const [reason, setReason] = useState("");
  return (
    <BottomSheet title="Change Number" description="Request a new 8-digit identity" icon={RefreshCw} onClose={onClose}>
      <div className="p-6 pb-12">
        <div className="bg-amber-50 border border-amber-100 p-4 rounded-2xl flex gap-3 mb-6">
          <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <p className="text-sm text-amber-800 font-medium leading-relaxed">
            Changing your number will disconnect you from all existing contacts. They will not be notified.
          </p>
        </div>
        
        <label className="block text-sm font-bold text-slate-700 mb-2 px-1">Reason for change</label>
        <textarea 
          value={reason}
          onChange={e => setReason(e.target.value)}
          placeholder="e.g. Getting too many spam calls..."
          className="w-full h-32 bg-white border border-slate-200 rounded-2xl p-4 outline-none focus:border-amber-400 focus:ring-4 focus:ring-amber-400/10 transition-all text-[15px] resize-none mb-6 shadow-sm"
        />

        <button 
          onClick={() => { onRequest(reason); onClose(); }}
          disabled={!reason.trim()}
          className="w-full h-14 bg-amber-500 hover:bg-amber-600 disabled:bg-slate-200 disabled:text-slate-400 text-white rounded-full flex items-center justify-center font-bold shadow-lg shadow-amber-500/20 active:scale-95 transition-all ripple"
        >
          Submit Request
        </button>
      </div>
    </BottomSheet>
  );
}



export function BlockedUsersModal({ profile, onClose, onUnblock }: { profile: UserProfile, onClose: () => void, onUnblock: (u: any) => void }) {
  const list = profile.blockedUsersList || [];
  return (
    <BottomSheet title="Blocked Callers" description={`${list.length || 0} numbers blocked`} icon={Ban} onClose={onClose}>
      <div className="p-5 pb-10">
        {!list || list.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mb-4">
              <ShieldCheck className="w-10 h-10 text-slate-300" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-1">No Blocked Callers</h3>
            <p className="text-slate-500 font-medium">Your blocklist is empty.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {list.map((u: any, i: number) => (
              <div key={i} className="bg-white p-4 rounded-3xl shadow-sm border border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-red-50 rounded-full flex items-center justify-center shrink-0">
                    <Ban className="w-6 h-6 text-red-500" />
                  </div>
                  <div>
                    <p className="font-bold text-slate-900">{u.label || "Blocked caller"}</p>
                    <p className="text-[11px] font-mono text-slate-400 mt-0.5 truncate max-w-[120px]">
                      {u.number.slice(0, 4)}-{u.number.slice(4)} · {new Date(u.date).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <button 
                  onClick={() => {
                    if (confirm(`Unblock ${u.number.slice(0, 4)}-${u.number.slice(4)}?`)) onUnblock(u);
                  }}
                  className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-700 rounded-full text-sm font-bold transition-colors flex items-center gap-2 ripple"
                >
                  <Unlock className="w-4 h-4" /> Unblock
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </BottomSheet>
  );
}

export function NotificationSettingsModal({ profile, onClose, onSave }: { profile: UserProfile, onClose: () => void, onSave: (s: any) => void }) {
  const [vibrate, setVibrate] = useState(profile.notificationSettings?.vibrate ?? true);
  const [sound, setSound] = useState(profile.notificationSettings?.sound ?? true);
  const [ringtone, setRingtone] = useState(profile.notificationSettings?.ringtone ?? true);
  const Toggle = ({ enabled, onChange, label }: { enabled: boolean; onChange: (next: boolean) => void; label: string }) => (
    <motion.button type="button" aria-label={label} aria-pressed={enabled} whileTap={{ scale: 0.92 }} transition={{ type: "spring", stiffness: 600, damping: 26 }} onClick={() => { hapticFeedback.light(); onChange(!enabled); }} className="w-12 h-6 rounded-full relative overflow-hidden ripple focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 focus-visible:ring-offset-2">
      <motion.span aria-hidden="true" className="absolute inset-0 rounded-full" animate={{ backgroundColor: enabled ? "#f59e0b" : "#e2e8f0" }} transition={{ duration: 0.18, ease: "easeOut" }} />
      <motion.span aria-hidden="true" className="absolute left-1 top-1 w-4 h-4 rounded-full bg-white shadow-sm" animate={{ x: enabled ? 24 : 0 }} transition={{ type: "spring", stiffness: 560, damping: 32, mass: 0.55 }} />
    </motion.button>
  );

  return (
    <BottomSheet title="Notifications" description="Customize alerts" icon={Bell} onClose={onClose} dragToDismiss>
      <div className="p-6 pb-12 space-y-4">
        
        <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-100 flex items-center justify-between">
          <div>
            <h4 className="font-bold text-slate-900">Vibrate on Ring</h4>
            <p className="text-xs font-medium text-slate-500 mt-0.5">Haptic feedback for calls</p>
          </div>
          <Toggle enabled={vibrate} onChange={setVibrate} label="Toggle vibrate on ring" />
        </div>

        <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-100 flex items-center justify-between">
          <div>
            <h4 className="font-bold text-slate-900">Notification Sound</h4>
            <p className="text-xs font-medium text-slate-500 mt-0.5">Sound for missed calls, etc.</p>
          </div>
          <Toggle enabled={sound} onChange={setSound} label="Toggle notification sound" />
        </div>
        
        <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-100 flex items-center justify-between">
          <div>
            <h4 className="font-bold text-slate-900">Play Ringtone</h4>
            <p className="text-xs font-medium text-slate-500 mt-0.5">Sound for incoming calls</p>
          </div>
          <Toggle enabled={ringtone} onChange={setRingtone} label="Toggle play ringtone" />
        </div>

        <button 
          onClick={() => { onSave({ vibrate, sound, ringtone }); onClose(); }}
          className="w-full h-14 mt-4 bg-amber-500 hover:bg-amber-600 text-white rounded-full flex items-center justify-center font-bold shadow-lg shadow-amber-500/20 active:scale-95 transition-all ripple"
        >
          Save Preferences
        </button>
      </div>
    </BottomSheet>
  );
}

export function ReportModal({ targetNumber, onClose, onSubmit }: { targetNumber: string, onClose: () => void, onSubmit: (category: ReportCategory, description: string) => Promise<void> }) {
  const [category, setCategory] = useState<ReportCategory | "">("");
  const [description, setDescription] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState("");
  const categories: { value: ReportCategory; label: string }[] = [
    { value: "spam", label: "Spam" },
    { value: "harassment", label: "Harassment" },
    { value: "scam", label: "Scam" },
    { value: "abuse", label: "Abuse" },
    { value: "other", label: "Other" },
  ];

  const handleSubmit = async () => {
    if (!category || isSubmitting) return;
    setError("");
    setIsSubmitting(true);
    try {
      await onSubmit(category, description);
      onClose();
    } catch (submissionError: any) {
      setError(submissionError?.message || "Unable to submit this report.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <BottomSheet title="Report number" description={`Report ${targetNumber.slice(0,4)}-${targetNumber.slice(4)}`} icon={AlertCircle} onClose={onClose}>
      <div className="p-6 pb-12">
        <label className="block text-sm font-bold text-slate-700 mb-2 px-1">Why are you reporting this number?</label>
        <div className="flex flex-wrap gap-2 mb-4">
          {categories.map((item) => (
            <button
              key={item.value}
              type="button"
              onClick={() => setCategory(item.value)}
              className={`px-3 py-2 rounded-full text-sm font-semibold border transition-colors ${category === item.value ? "bg-red-500 border-red-500 text-white" : "bg-white border-slate-200 text-slate-600 hover:border-red-200"}`}
            >
              {item.label}
            </button>
          ))}
        </div>
        <label className="block text-sm font-bold text-slate-700 mb-2 px-1">Additional details (optional)</label>
        <textarea 
          value={description}
          onChange={e => setDescription(e.target.value)}
          placeholder="Harassment, spam, inappropriate behavior..."
          className="w-full h-32 bg-white border border-slate-200 rounded-2xl p-4 outline-none focus:border-red-400 focus:ring-4 focus:ring-red-400/10 transition-all text-[15px] resize-none mb-6 shadow-sm"
        />

        <button 
          onClick={handleSubmit}
          disabled={!category || isSubmitting}
          className="w-full h-14 bg-red-500 hover:bg-red-600 disabled:bg-slate-200 disabled:text-slate-400 text-white rounded-full flex items-center justify-center font-bold shadow-lg shadow-red-500/20 active:scale-95 transition-all ripple"
        >
          {isSubmitting ? "Submitting…" : "Submit Report"}
        </button>
        {error && <p className="mt-3 text-sm text-red-600" role="alert">{error}</p>}
      </div>
    </BottomSheet>
  );
}
