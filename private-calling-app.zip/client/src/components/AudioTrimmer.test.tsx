// @vitest-environment jsdom
import React from "react";
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { AudioTrimmer } from "./HelloTuneTab";
import * as helloTuneClip from "../services/helloTuneClip";

const authProbe = vi.hoisted(() => ({ currentUser: { getIdToken: vi.fn(async () => "test-token") } }));
vi.mock("../firebase", () => ({ auth: authProbe, db: null }));
vi.mock("../services/secureApi", () => ({ secureApi: { helloTune: { activate: { mutate: vi.fn() }, remove: { mutate: vi.fn() } } } }));
vi.mock("../utils/haptics", () => ({ hapticFeedback: { light: vi.fn(), success: vi.fn(), error: vi.fn() } }));

class MetadataAudio {
  duration = 75;
  currentTime = 0;
  ended = false;
  onloadedmetadata: (() => void) | null = null;
  onerror: (() => void) | null = null;
  constructor() { queueMicrotask(() => this.onloadedmetadata?.()); }
}

afterEach(() => { cleanup(); vi.unstubAllGlobals(); vi.restoreAllMocks(); });

describe("HelloTune audio editor", () => {
  it("shows a 40-second default clip with two independently adjustable visible handles", async () => {
    vi.spyOn(HTMLMediaElement.prototype, "pause").mockImplementation(() => undefined);
    vi.stubGlobal("Audio", MetadataAudio);
    vi.stubGlobal("URL", { createObjectURL: vi.fn(() => "blob:hello-tune"), revokeObjectURL: vi.fn() });
    const { container } = render(<AudioTrimmer profile={{ uid: "test", helloTune: undefined } as any} onClose={vi.fn()} />);
    const input = container.querySelector('input[type="file"]') as HTMLInputElement;
    fireEvent.change(input, { target: { files: [new File(["audio"], "song.mp3", { type: "audio/mpeg" })] } });
    await waitFor(() => expect(screen.getByText("Selected: 40.0s / Max 40s")).toBeTruthy());
    const start = screen.getByRole("slider", { name: "Selection start" });
    const end = screen.getByRole("slider", { name: "Selection end" });
    expect(start.tagName).toBe("BUTTON");
    expect(end.tagName).toBe("BUTTON");
    fireEvent.keyDown(start, { key: "ArrowRight" });
    await waitFor(() => expect(screen.getByText("Selected: 39.5s / Max 40s")).toBeTruthy());
  });

  it("shows an honest processing error and retries the same selected clip", async () => {
    vi.spyOn(HTMLMediaElement.prototype, "pause").mockImplementation(() => undefined);
    vi.spyOn(console, "error").mockImplementation(() => undefined);
    vi.stubGlobal("Audio", MetadataAudio);
    vi.stubGlobal("URL", { createObjectURL: vi.fn(() => "blob:hello-tune"), revokeObjectURL: vi.fn() });
    const processor = vi.spyOn(helloTuneClip, "createHelloTuneClip").mockRejectedValue(new Error("Selected clip could not be decoded."));
    const { container } = render(<AudioTrimmer profile={{ uid: "test", helloTune: undefined } as any} onClose={vi.fn()} />);
    fireEvent.change(container.querySelector('input[type="file"]') as HTMLInputElement, { target: { files: [new File(["audio"], "song.mp3", { type: "audio/mpeg" })] } });
    await waitFor(() => expect(screen.getByText("Selected: 40.0s / Max 40s")).toBeTruthy());
    fireEvent.click(screen.getByRole("button", { name: "Confirm & Activate" }));
    await waitFor(() => expect(screen.getByRole("alert").textContent).toContain("Selected clip could not be decoded."));
    fireEvent.click(screen.getByRole("button", { name: "Retry" }));
    await waitFor(() => expect(processor).toHaveBeenCalledTimes(2));
  });
});
