// @vitest-environment jsdom
import React from "react";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { NotificationSettingsModal } from "./ProfileModals";

vi.mock("../firebase", () => ({ auth: null, db: null }));
vi.mock("../utils/haptics", () => ({ hapticFeedback: { light: vi.fn() } }));

afterEach(cleanup);

const profile: any = { notificationSettings: { vibrate: true, sound: false, ringtone: true } };

describe("Notification Settings interactions", () => {
  it("toggles each setting immediately and saves the changed values", () => {
    const onSave = vi.fn();
    render(<NotificationSettingsModal profile={profile} onClose={vi.fn()} onSave={onSave} />);

    expect(screen.getByTestId("bottom-sheet").getAttribute("data-drag-dismiss")).toBe("true");
    expect(screen.getByRole("button", { name: "Toggle vibrate on ring" }).getAttribute("aria-pressed")).toBe("true");
    expect(screen.getByRole("button", { name: "Toggle notification sound" }).getAttribute("aria-pressed")).toBe("false");
    fireEvent.click(screen.getByRole("button", { name: "Toggle vibrate on ring" }));
    fireEvent.click(screen.getByRole("button", { name: "Toggle notification sound" }));
    fireEvent.click(screen.getByRole("button", { name: "Save Preferences" }));

    expect(onSave).toHaveBeenCalledWith({ vibrate: false, sound: true, ringtone: true });
  });

  it("retains the existing X close action while marking only Notifications as drag-dismissible", () => {
    const onClose = vi.fn();
    render(<NotificationSettingsModal profile={profile} onClose={onClose} onSave={vi.fn()} />);
    fireEvent.click(screen.getByRole("button", { name: /close/i }));
    expect(onClose).toHaveBeenCalledTimes(1);
  });
});
