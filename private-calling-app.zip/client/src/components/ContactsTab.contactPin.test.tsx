// @vitest-environment jsdom
import React from "react";
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import ContactsTab from "./ContactsTab";
import { secureApi } from "../services/secureApi";

vi.mock("../services/secureApi", () => ({
  secureApi: {
    contacts: { list: { query: vi.fn() }, add: { mutate: vi.fn() }, update: { mutate: vi.fn() }, remove: { mutate: vi.fn() }, authorizeSavedPin: { mutate: vi.fn() } },
    privacy: { blockStatus: { query: vi.fn() } },
  },
}));
vi.mock("../utils/haptics", () => ({ hapticFeedback: { light: vi.fn(), medium: vi.fn(), success: vi.fn() } }));
vi.mock("./PinPadModal", () => ({ default: () => <div data-testid="calling-pin-prompt" /> }));

afterEach(cleanup);
beforeEach(() => vi.clearAllMocks());

const profile: any = { uid: "owner", displayName: "Owner", email: "owner@example.invalid", photoURL: "", pinHash: "", virtualNumbers: [], createdAt: 1, isOnboarded: true };
const props = (onCallInitiate = vi.fn().mockResolvedValue(undefined)) => ({ profile, onCallInitiate, onBlockContact: vi.fn(), onUnblockContact: vi.fn(), onReportContact: vi.fn() });

describe("saved contact Calling PIN behavior", () => {
  it("opens the existing PIN prompt for an 8-digit permanent contact without a saved PIN", async () => {
    vi.mocked(secureApi.contacts.list.query).mockResolvedValue([{ id: "permanent", name: "Permanent", number: "12345678", hasCallingPin: false }] as never);
    render(<ContactsTab {...props()} />);
    fireEvent.click(await screen.findByRole("button", { name: "Call Permanent" }));
    expect(screen.getByTestId("calling-pin-prompt")).toBeTruthy();
  });

  it("calls a 7-digit temporary contact without a PIN prompt even when legacy PIN metadata exists", async () => {
    const onCallInitiate = vi.fn().mockResolvedValue(undefined);
    vi.mocked(secureApi.contacts.list.query).mockResolvedValue([{ id: "temporary", name: "Temporary", number: "1234567", hasCallingPin: true }] as never);
    render(<ContactsTab {...props(onCallInitiate)} />);
    fireEvent.click(await screen.findByRole("button", { name: "Call Temporary" }));
    await waitFor(() => expect(onCallInitiate).toHaveBeenCalledWith("1234567"));
    expect(screen.queryByTestId("calling-pin-prompt")).toBeNull();
  });
});
