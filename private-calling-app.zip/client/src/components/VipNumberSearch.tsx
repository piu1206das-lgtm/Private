import React, { useState } from "react";
import { UserProfile } from "../types";
import { ArrowLeft, Crown, Check, Search, X, Sparkles, Clock3 } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { pageTransition } from "../utils/animations";
import { hapticFeedback } from "../utils/haptics";
import { secureApi } from "../services/secureApi";

interface VipNumberSearchProps {
  profile: UserProfile;
  onClose: () => void;
}

type VipSearchResult = {
  number: string;
  available: boolean;
  tier?: string;
  price?: number;
  score?: number;
  patterns?: Array<{ code: string; label: string }>;
  configurationVersion?: string;
};

function formatNumber(number: string) {
  return `${number.slice(0, 4)}-${number.slice(4)}`;
}

export default function VipNumberSearch({ profile, onClose }: VipNumberSearchProps) {
  void profile;
  const [searchInput, setSearchInput] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [searchResult, setSearchResult] = useState<VipSearchResult | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [statusMessage, setStatusMessage] = useState("");

  const formatInput = (value: string) => {
    const raw = value.replace(/\D/g, "").slice(0, 8);
    return raw.length > 4 ? `${raw.slice(0, 4)}-${raw.slice(4)}` : raw;
  };

  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearchInput(formatInput(event.target.value));
    setSearchResult(null);
    setStatusMessage("");
  };

  const clearInput = () => {
    setSearchInput("");
    setSearchResult(null);
    setStatusMessage("");
    hapticFeedback.light();
  };

  const checkAvailability = async () => {
    const raw = searchInput.replace(/\D/g, "");
    if (raw.length !== 8) return;
    hapticFeedback.medium();
    setIsSearching(true);
    setStatusMessage("");
    try {
      const result = await secureApi.vip.search.query({ number: raw });
      setSearchResult(result as VipSearchResult);
    } catch (error: any) {
      setSearchResult(null);
      setStatusMessage(error?.message || "Availability could not be checked. Please try again.");
      hapticFeedback.error();
    } finally {
      setIsSearching(false);
    }
  };

  const openCheckout = (checkoutUrl: string) => {
    const opened = window.open(checkoutUrl, "_blank", "noopener,noreferrer");
    if (!opened) window.location.assign(checkoutUrl);
  };

  const claimNumber = async () => {
    if (!searchResult?.available || isProcessing) return;
    hapticFeedback.light();
    setIsProcessing(true);
    setStatusMessage("");
    try {
      const response = await secureApi.vip.createCheckout.mutate({ number: searchResult.number, requestId: crypto.randomUUID() });
      if (response.alreadyFulfilled) {
        setStatusMessage("This verified VIP purchase was already fulfilled.");
        hapticFeedback.success();
      } else if (response.checkoutUrl) {
        openCheckout(response.checkoutUrl);
        setStatusMessage("Secure checkout opened. This number is assigned only after the server verifies payment.");
      }
    } catch (error: any) {
      setStatusMessage(error?.message || "Secure VIP checkout could not be started. This number was not assigned.");
      hapticFeedback.error();
      if (String(error?.message || "").toLowerCase().includes("unavailable")) setSearchResult({ number: searchResult.number, available: false });
    } finally {
      setIsProcessing(false);
    }
  };

  return <motion.div variants={pageTransition} initial="initial" animate="animate" exit="exit" className="absolute inset-0 bg-slate-50 flex flex-col z-[60]">
    <div className="flex items-center px-4 h-14 bg-white border-b border-slate-100 shrink-0"><button onClick={() => { hapticFeedback.light(); onClose(); }} className="p-2 -ml-2 rounded-full active:bg-slate-100 text-slate-700 ripple"><ArrowLeft className="w-6 h-6" /></button><h1 className="ml-2 text-[18px] font-medium text-slate-900 tracking-tight">Search your VIP number</h1></div>
    <div className="flex-1 overflow-y-auto px-6 py-8">
      <p className="text-sm text-slate-500 mb-6 text-center">Enter an 8-digit combination to check availability and its server-calculated VIP value.</p>
      <div className="relative mb-6"><input type="text" autoFocus value={searchInput} onChange={handleInputChange} placeholder="XXXX-XXXX" className="w-full h-16 bg-white border-2 border-slate-200 rounded-2xl text-center text-3xl font-mono text-slate-900 tracking-widest focus:border-amber-500 outline-none transition-colors placeholder:text-slate-300" />{searchInput.length > 0 && <button onClick={clearInput} className="absolute right-4 top-1/2 -translate-y-1/2 p-1.5 rounded-full bg-slate-100 text-slate-500 active:bg-slate-200"><X className="w-5 h-5" /></button>}</div>
      <button disabled={searchInput.replace(/\D/g, "").length !== 8 || isSearching} onClick={checkAvailability} className="w-full h-14 bg-slate-900 text-white rounded-xl font-semibold text-[16px] shadow-sm active:bg-slate-800 transition-colors disabled:opacity-50 disabled:bg-slate-300 flex items-center justify-center ripple mb-5">{isSearching ? "Checking..." : "Check Availability"}</button>
      {statusMessage && <p role="status" className="mb-5 rounded-xl border border-amber-100 bg-amber-50 px-4 py-3 text-[13px] leading-5 text-amber-800">{statusMessage}</p>}
      <AnimatePresence>{searchResult && <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>{searchResult.available ? <div className="bg-white rounded-2xl p-6 border-2 border-emerald-500 shadow-sm text-center"><div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-3"><Check className="w-6 h-6 text-emerald-600" /></div><h3 className="text-xl font-bold text-emerald-600 mb-1">Available</h3><p className="text-2xl font-mono text-slate-900 mb-6 tracking-widest">{formatNumber(searchResult.number)}</p><div className="flex justify-between items-center bg-slate-50 p-4 rounded-xl mb-3"><div className="text-left"><p className="text-xs text-slate-500 uppercase tracking-widest font-bold mb-1">VIP Level</p><p className="font-semibold text-amber-600 flex items-center gap-1.5"><Crown className="w-4 h-4" />{searchResult.tier}</p></div><div className="text-right"><p className="text-xs text-slate-500 uppercase tracking-widest font-bold mb-1">Server price</p><p className="text-xl font-light text-slate-900 leading-none">₹{searchResult.price}</p></div></div><div className="rounded-xl bg-slate-50 px-4 py-3 text-left mb-6"><div className="flex items-center justify-between gap-3"><p className="text-xs text-slate-500 uppercase tracking-widest font-bold">Pattern analysis</p><p className="font-semibold text-slate-800">Score {searchResult.score}/100</p></div><div className="mt-2 flex flex-wrap gap-1.5">{searchResult.patterns?.length ? searchResult.patterns.map(pattern => <span key={pattern.code} className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2 py-1 text-[11px] font-medium text-amber-800"><Sparkles className="w-3 h-3" />{pattern.label}</span>) : <span className="text-[13px] text-slate-500">No strong pattern detected.</span>}</div></div><button onClick={claimNumber} disabled={isProcessing} className="w-full h-14 bg-amber-500 text-white rounded-xl font-semibold text-[16px] shadow-sm active:bg-amber-600 transition-colors disabled:opacity-70 flex items-center justify-center ripple">{isProcessing ? "Opening checkout..." : "Continue to secure payment"}</button><p className="text-xs text-slate-400 mt-4 px-2 leading-relaxed">Availability, tier and price are rechecked by the server before checkout. Number assignment occurs only after verified payment.</p></div> : <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm text-center"><div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-3"><X className="w-6 h-6 text-slate-400" /></div><h3 className="text-xl font-bold text-slate-700 mb-1">Unavailable</h3><p className="text-xl font-mono text-slate-500 mb-2 opacity-50 tracking-widest">{formatNumber(searchResult.number)}</p><p className="text-sm text-slate-500">This number is unavailable.</p></div>}</motion.div>}</AnimatePresence>
    </div>
  </motion.div>;
}
