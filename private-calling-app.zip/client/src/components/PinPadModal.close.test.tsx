// @vitest-environment jsdom
import React from "react";
import { act, cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import PinPadModal from "./PinPadModal";
import { getPinCooldown, validatePinAndRecordAttempt } from "../services/backend";

vi.mock("../services/backend", () => ({ getPinCooldown: vi.fn(), validatePinAndRecordAttempt: vi.fn() }));
vi.mock("../utils/haptics", () => ({ hapticFeedback: { light: vi.fn(), medium: vi.fn(), success: vi.fn(), error: vi.fn() } }));

afterEach(cleanup);

beforeEach(() => {
  vi.clearAllMocks();
  vi.mocked(getPinCooldown).mockResolvedValue(0);
});

describe("Security PIN close action", () => {
  it("is visible, clears temporary input, and cancels without validating a partial PIN", () => {
    const onCancel = vi.fn();
    const { container } = render(<PinPadModal callerUid="caller" targetNumber="12345678" onSuccess={vi.fn()} onCancel={onCancel} />);
    fireEvent.click(screen.getByRole("button", { name: "1" }));
    expect(container.querySelectorAll(".bg-slate-800")).toHaveLength(1);
    fireEvent.click(screen.getByRole("button", { name: "Close security PIN" }));
    expect(onCancel).toHaveBeenCalledTimes(1);
    expect(validatePinAndRecordAttempt).not.toHaveBeenCalled();
    expect(container.querySelectorAll(".bg-slate-800")).toHaveLength(0);
  });

  it("preserves the existing dismiss cancellation path without validating entered digits", () => {
    const onCancel = vi.fn();
    const { container } = render(<PinPadModal callerUid="caller" targetNumber="12345678" onSuccess={vi.fn()} onCancel={onCancel} />);
    fireEvent.click(screen.getByRole("button", { name: "2" }));
    fireEvent.click(container.querySelector(".backdrop-blur-sm")!);
    expect(onCancel).toHaveBeenCalledTimes(1);
    expect(validatePinAndRecordAttempt).not.toHaveBeenCalled();
    expect(container.querySelectorAll(".bg-slate-800")).toHaveLength(0);
  });

  it("prevents an in-flight verification response from succeeding after close", async () => {
    let resolveAttempt!: (result: { success: boolean }) => void;
    vi.mocked(validatePinAndRecordAttempt).mockReturnValue(new Promise(resolve => { resolveAttempt = resolve; }) as never);
    const onSuccess = vi.fn();
    render(<PinPadModal callerUid="caller" targetNumber="12345678" onSuccess={onSuccess} onCancel={vi.fn()} />);
    for (const digit of ["1", "2", "3", "4"]) fireEvent.click(screen.getByRole("button", { name: digit }));
    expect(validatePinAndRecordAttempt).toHaveBeenCalledWith("caller", "12345678", "1234");
    fireEvent.click(screen.getByRole("button", { name: "Close security PIN" }));
    await act(async () => { resolveAttempt({ success: true }); });
    await new Promise(resolve => setTimeout(resolve, 350));
    expect(onSuccess).not.toHaveBeenCalled();
  });
});
