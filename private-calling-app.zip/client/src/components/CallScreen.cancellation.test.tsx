// @vitest-environment jsdom
import React from "react";
import { act, cleanup, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import CallScreen from "./CallScreen";
import { onSnapshot } from "firebase/firestore";

vi.mock("../firebase", () => ({ db: {} }));
vi.mock("firebase/firestore", () => ({ doc: vi.fn(() => ({})), onSnapshot: vi.fn(() => () => undefined) }));
vi.mock("../services/secureApi", () => ({ secureApi: { contacts: { list: { query: vi.fn(() => Promise.resolve([])) } }, calls: { transition: { mutate: vi.fn() } } } }));
vi.mock("../services/callMedia", () => ({ CallMediaSession: vi.fn(), }));
vi.mock("../utils/haptics", () => ({ hapticFeedback: { light: vi.fn() } }));
vi.mock("./CachedImage", () => ({ default: () => null }));

class TestUtterance {
  lang = "";
  rate = 0;
  pitch = 0;
  constructor(public text: string) {}
}

beforeEach(() => {
  vi.useFakeTimers();
  vi.stubGlobal("SpeechSynthesisUtterance", TestUtterance);
});
afterEach(() => { cleanup(); vi.useRealTimers(); vi.unstubAllGlobals(); });

describe("incoming call cancellation synchronization", () => {
  it("stops the receiver ringing immediately when the caller-cancelled record arrives", () => {
    let listener: ((snapshot: any) => void) | undefined;
    vi.mocked(onSnapshot).mockImplementation((_ref, callback) => { listener = callback as (snapshot: any) => void; return () => undefined; });
    const onEndCall = vi.fn();
    render(<CallScreen callId="ringing-call" targetNumber="12345678" isIncoming onEndCall={onEndCall} />);
    expect(screen.getByText("Incoming call")).toBeTruthy();
    act(() => listener?.({ exists: () => true, data: () => ({ status: "cancelled" }) }));
    expect(screen.getByText("Call cancelled")).toBeTruthy();
    act(() => vi.advanceTimersByTime(1500));
    expect(onEndCall).toHaveBeenCalledTimes(1);
  });

  it("announces a repeated terminal call snapshot only once", () => {
    let listener: ((snapshot: any) => void) | undefined;
    const speak = vi.fn();
    const cancel = vi.fn();
    vi.stubGlobal("speechSynthesis", { speak, cancel });
    vi.mocked(onSnapshot).mockImplementation((_ref, callback) => { listener = callback as (snapshot: any) => void; return () => undefined; });

    render(<CallScreen callId="ringing-call" targetNumber="12345678" isIncoming onEndCall={vi.fn()} />);
    act(() => listener?.({ exists: () => true, data: () => ({ status: "cancelled" }) }));
    act(() => listener?.({ exists: () => true, data: () => ({ status: "cancelled" }) }));

    expect(speak).toHaveBeenCalledTimes(1);
    expect((speak.mock.calls[0]?.[0] as TestUtterance).text).toBe("The call was cancelled.");

    cleanup();
    expect(cancel).toHaveBeenCalled();
  });
});
