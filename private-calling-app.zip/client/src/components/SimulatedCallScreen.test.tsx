// @vitest-environment jsdom
import React from "react";
import { act, cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import SimulatedCallScreen from "./SimulatedCallScreen";

vi.mock("../utils/haptics", () => ({ hapticFeedback: { light: vi.fn(), medium: vi.fn(), success: vi.fn() } }));

beforeEach(() => vi.useFakeTimers());
afterEach(() => { cleanup(); vi.useRealTimers(); });

describe("SimulatedCallScreen", () => {
  it("progresses an outgoing in-app simulation from Calling to Connecting to Connected and returns its result on end", () => {
    const onEnd = vi.fn();
    render(<SimulatedCallScreen number="12345678" onEnd={onEnd} />);
    expect(screen.getByText("IN-APP SIMULATION")).toBeTruthy();
    expect(screen.getByText("Calling…")).toBeTruthy();
    act(() => vi.advanceTimersByTime(850));
    expect(screen.getByText("Connecting…")).toBeTruthy();
    act(() => vi.advanceTimersByTime(950));
    expect(screen.getByText("00:00")).toBeTruthy();
    act(() => vi.advanceTimersByTime(1000));
    expect(screen.getByText("00:01")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "End simulated call" }));
    expect(onEnd).toHaveBeenCalledWith(expect.objectContaining({ durationSeconds: 1, direction: "outgoing" }));
  });

  it("offers incoming simulation acceptance and provides mute, speaker, and keypad controls", () => {
    render(<SimulatedCallScreen number="1234567" direction="incoming" onEnd={vi.fn()} />);
    expect(screen.getByText("Incoming simulated call")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "Accept simulated call" }));
    act(() => vi.advanceTimersByTime(1800));
    fireEvent.click(screen.getByRole("button", { name: "Mute" }));
    expect(screen.getByRole("button", { name: "Mute" }).getAttribute("aria-pressed")).toBe("true");
    fireEvent.click(screen.getByRole("button", { name: "Speaker" }));
    expect(screen.getByRole("button", { name: "Speaker" }).getAttribute("aria-pressed")).toBe("true");
    fireEvent.click(screen.getByRole("button", { name: "Keypad" }));
    expect(screen.getByRole("dialog", { name: "Simulated in-call keypad" })).toBeTruthy();
    expect(screen.getAllByRole("button", { name: /Send simulated tone/ })).toHaveLength(12);
    fireEvent.click(screen.getByRole("button", { name: "Send simulated tone #" }));
    expect(screen.getByLabelText("Sent simulated keypad tones").textContent).toContain("#");
    fireEvent.click(screen.getByRole("button", { name: "Dismiss simulated in-call keypad" }));
  });
});
