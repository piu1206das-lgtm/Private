import { UserProfile } from "../types";
import { X, Ban, Unlock } from "lucide-react";
import { updateDoc, doc } from "firebase/firestore";
import { db } from "../firebase";

interface BlockedUsersModalProps {
  onClose: () => void;
  profile: UserProfile;
}

export default function BlockedUsersModal({ onClose, profile }: BlockedUsersModalProps) {
  const handleUnblock = async (hashToUnblock: string) => {
    if (navigator.vibrate) navigator.vibrate(20);
    const updated = (profile.blockedHashes || []).filter(h => h !== hashToUnblock);
    await updateDoc(doc(db, "users", profile.uid), { blockedHashes: updated });
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end">
      <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm transition-opacity" onClick={onClose}></div>
      <div className="bg-slate-50 w-full h-[85vh] rounded-t-[32px] shadow-2xl relative z-10 animate-in slide-in-from-bottom-8 duration-300 flex flex-col overflow-hidden">
        
        {/* Header */}
        <div className="bg-white px-6 pt-6 pb-4 border-b border-slate-100 flex items-center justify-between shrink-0">
          <div className="w-12 h-1.5 bg-slate-200 rounded-full absolute top-3 left-1/2 -translate-x-1/2"></div>
          <div>
            <h2 className="text-xl font-bold text-slate-900">Blocked Callers</h2>
            <p className="text-sm font-medium text-slate-500">{profile.blockedHashes?.length || 0} devices blocked</p>
          </div>
          <button onClick={onClose} className="p-2 bg-slate-100 rounded-full text-slate-500 hover:bg-slate-200 transition-colors ripple">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {!profile.blockedHashes || profile.blockedHashes.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-48 text-center">
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mb-4">
                <Ban className="w-8 h-8 text-slate-300" />
              </div>
              <p className="text-slate-500 font-medium">No blocked callers</p>
            </div>
          ) : (
            <div className="space-y-3">
              {profile.blockedHashes.map(hash => (
                <div key={hash} className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-red-50 rounded-full flex items-center justify-center shrink-0">
                      <Ban className="w-6 h-6 text-red-500" />
                    </div>
                    <div>
                      <p className="font-bold text-slate-900">Anonymous Caller</p>
                      <p className="text-xs font-mono text-slate-400 mt-0.5 truncate max-w-[120px]">
                        ID: {hash.slice(0, 8)}...
                      </p>
                    </div>
                  </div>
                  <button 
                    onClick={() => handleUnblock(hash)}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-700 rounded-full text-sm font-bold transition-colors flex items-center gap-2 ripple"
                  >
                    <Unlock className="w-4 h-4" /> Unblock
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
