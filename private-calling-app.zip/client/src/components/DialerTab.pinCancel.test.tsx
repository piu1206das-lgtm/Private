// @vitest-environment jsdom
import React from "react";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import DialerTab from "./DialerTab";
import { getPinCooldown, validatePinAndRecordAttempt } from "../services/backend";

vi.mock("../services/backend", () => ({ getPinCooldown: vi.fn(), validatePinAndRecordAttempt: vi.fn() }));
vi.mock("../utils/haptics", () => ({ hapticFeedback: { light: vi.fn(), medium: vi.fn(), heavy: vi.fn(), success: vi.fn(), error: vi.fn() } }));
vi.mock("./CachedImage", () => ({ default: () => null }));

afterEach(cleanup);
beforeEach(() => { vi.clearAllMocks(); vi.mocked(getPinCooldown).mockResolvedValue(0); });

describe("Dialer Security PIN return path", () => {
  it("returns to the dialer after cancel, clearing the PIN prompt without validation", () => {
    const { container } = render(<DialerTab profile={{ uid: "owner", displayName: "Owner", virtualNumbers: [] } as any} onCall={vi.fn()} onGoToProfile={vi.fn()} />);
    const keypadButtons = container.querySelectorAll(".grid button");
    for (const button of Array.from(keypadButtons).slice(0, 8)) fireEvent.click(button);
    fireEvent.click(container.querySelector("button.w-14.h-14.bg-amber-500")!);
    expect(screen.getByText("Enter Security PIN")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "Close security PIN" }));
    expect(screen.queryByText("Enter Security PIN")).toBeNull();
    expect(validatePinAndRecordAttempt).not.toHaveBeenCalled();
  });
});
