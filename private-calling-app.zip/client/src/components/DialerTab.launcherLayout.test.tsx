// @vitest-environment jsdom
import React from "react";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import DialerTab from "./DialerTab";
import BottomNav from "./BottomNav";

vi.mock("../utils/haptics", () => ({ hapticFeedback: { light: vi.fn(), heavy: vi.fn() } }));
vi.mock("./PinPadModal", () => ({ default: () => null }));

afterEach(cleanup);
const profile: any = { uid: "owner", displayName: "Owner", photoURL: "", virtualNumbers: [] };

describe("Dial Pad floating launcher layout", () => {
  it.each([320, 360, 412, 480])("keeps the floating shortcut inside the left and bottom device insets on a %ipx Android viewport", (width) => {
    Object.defineProperty(window, "innerWidth", { configurable: true, value: width });
    render(<DialerTab profile={profile} onCall={vi.fn()} onGoToProfile={vi.fn()} />);
    fireEvent.click(screen.getByRole("button", { name: "Hide keypad" }));
    const launcher = screen.getByRole("button", { name: "Show Dial Pad" });
    expect(launcher.className).toContain("!absolute");
    expect(launcher.className).toContain("bottom-[max(1.5rem,env(safe-area-inset-bottom,0px))]");
    expect(launcher.className).toContain("left-[max(1.5rem,env(safe-area-inset-left,0px))]");
    expect(launcher.className).not.toContain("right-6");
    cleanup();
  });

  it("keeps Bottom Navigation as a full-width non-shrinking safe-area sibling", () => {
    render(<BottomNav activeTab="dialer" onTabChange={vi.fn()} />);
    const navigation = screen.getByRole("button", { name: "Dialer" }).parentElement;
    expect(navigation?.className).toContain("bottom-navigation-safe-area");
    expect(navigation?.className).toContain("w-full");
    expect(navigation?.className).toContain("flex-none");
    expect(navigation?.className).toContain("shrink-0");
    expect(screen.getByRole("button", { name: "Dialer" }).className).toContain("min-w-0");
  });
});
