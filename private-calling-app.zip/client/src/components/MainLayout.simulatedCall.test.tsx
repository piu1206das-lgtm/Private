// @vitest-environment jsdom
import React from "react";
import { act, cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import MainLayout from "./MainLayout";
import { onSnapshot } from "firebase/firestore";
import { startCallSession } from "../services/backend";

vi.mock("../firebase", () => ({ db: {} }));
vi.mock("firebase/firestore", () => ({ collection: vi.fn(() => ({})), query: vi.fn(() => ({})), where: vi.fn(() => ({})), onSnapshot: vi.fn(() => () => undefined), doc: vi.fn(() => ({})), updateDoc: vi.fn() }));
vi.mock("../services/backend", () => ({ blockUser: vi.fn(), reportUser: vi.fn(), startCallSession: vi.fn(), unblockUser: vi.fn(), updateCallSession: vi.fn(), updateDND: vi.fn(), getPinCooldown: vi.fn(() => Promise.resolve(0)), validatePinAndRecordAttempt: vi.fn() }));
vi.mock("../utils/haptics", () => ({ hapticFeedback: { light: vi.fn(), medium: vi.fn(), heavy: vi.fn(), success: vi.fn(), error: vi.fn() } }));
vi.mock("./BottomNav", () => ({ default: () => <div data-testid="bottom-nav" /> }));
vi.mock("./CallScreen", () => ({ default: ({ targetNumber, onEndCall }: { targetNumber: string; onEndCall: () => void }) => <div data-testid="incoming-call-alert">{targetNumber}<button onClick={onEndCall}>End real call</button></div> }));
vi.mock("./ContactsTab", () => ({ default: () => null }));
vi.mock("./ProfileTab", () => ({ default: () => null }));
vi.mock("./PlanSelection", () => ({ default: () => null }));
vi.mock("./HelloTuneTab", () => ({ default: () => null }));
vi.mock("./Modals", () => ({ EditProfileModal: () => null, ChangePinModal: () => null, Toast: () => null }));
vi.mock("./ProfileModals", () => ({ DevicesModal: () => null, NumberChangeRequestModal: () => null, BlockedUsersModal: () => null, NotificationSettingsModal: () => null, ReportModal: () => null }));
vi.mock("./CachedImage", () => ({ default: () => null }));

const profile = { uid: "owner", displayName: "Owner", virtualNumbers: [{ number: "87654321", type: "primary", status: "active" }], dndEnabled: false } as any;

beforeEach(() => {
  vi.useFakeTimers();
  vi.mocked(startCallSession).mockResolvedValue("real-call-id");
});
afterEach(() => { cleanup(); vi.useRealTimers(); });

describe("MainLayout in-app call simulation", () => {
  it("routes a standard Dialer call through the real Firebase CallScreen using the active permanent caller identity", async () => {
    const { container } = render(<MainLayout user={{} as any} profile={profile} onProfileUpdate={vi.fn()} />);
    const keypad = container.querySelectorAll(".grid button");
    for (const button of Array.from(keypad).slice(0, 7)) fireEvent.click(button);
    fireEvent.click(container.querySelector("button.w-14.h-14.bg-amber-500")!);
    await act(async () => { await Promise.resolve(); });
    expect(screen.getByTestId("incoming-call-alert")).toBeTruthy();
    expect(startCallSession).toHaveBeenCalledWith("owner", "87654321", "1234567", expect.any(String));
    expect(screen.getByTestId("incoming-call-alert").textContent).toContain("1234567");
    expect(screen.queryByTestId("bottom-nav")).toBeNull();
    fireEvent.click(screen.getByRole("button", { name: "End real call" }));
    expect(screen.queryByTestId("incoming-call-alert")).toBeNull();
    expect(screen.getByTestId("bottom-nav")).toBeTruthy();
  });

  it("launches the reachable labelled incoming simulation and records its decline", () => {
    render(<MainLayout user={{} as any} profile={profile} onProfileUpdate={vi.fn()} />);
    fireEvent.click(screen.getByRole("button", { name: "Simulate incoming call" }));
    expect(screen.getByText("Incoming simulated call")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "Decline simulated call" }));
    expect(screen.getByText("Simulated call")).toBeTruthy();
  });

  it("opens the existing incoming-call alert when the Firestore listener receives a ringing record", () => {
    let receiverListener: ((snapshot: any) => void) | undefined;
    vi.mocked(onSnapshot).mockImplementation((_query, listener) => { receiverListener = listener as (snapshot: any) => void; return () => undefined; });
    render(<MainLayout user={{} as any} profile={profile} onProfileUpdate={vi.fn()} />);
    act(() => receiverListener?.({ empty: false, docs: [{ id: "ringing-call", data: () => ({ callerNumber: "12345678", receiverNumber: "87654321" }) }] }));
    expect(screen.getByTestId("incoming-call-alert").textContent).toContain("12345678");
  });
});
