/**
 * Style reminder — preserve the focused Android-style app shell: tabs, sheets,
 * and full-screen call state remain primary while privacy actions stay contextual.
 */
import { doc, updateDoc, collection, query, where, onSnapshot } from "firebase/firestore";
import { blockUser, reportUser, startCallSession, unblockUser, updateCallSession, updateDND } from "../services/backend";
import { db } from "../firebase";
import React, { useState, useEffect } from "react";
import { User as FirebaseUser } from "firebase/auth";
import { UserProfile } from "../types";
import { AnimatePresence, motion } from "motion/react";
import { pageTransition } from "../utils/animations";
import CallScreen from "./CallScreen";
import BottomNav, { TabType } from "./BottomNav";
import { EditProfileModal, ChangePinModal, Toast } from "./Modals";
import { DevicesModal, NumberChangeRequestModal, BlockedUsersModal, NotificationSettingsModal, ReportModal } from "./ProfileModals";
import DialerTab from "./DialerTab";
import SimulatedCallScreen, { type SimulatedCallDirection, type SimulatedCallResult } from "./SimulatedCallScreen";
import type { RecentCall } from "./DialerTab";
import { simulatedHistoryEntry } from "../utils/simulatedCallHistory";
import ContactsTab from "./ContactsTab";
import ProfileTab from "./ProfileTab";
import PlanSelection from "./PlanSelection";
import HelloTuneTab from "./HelloTuneTab";
import { getOrCreateDeviceId } from "../utils/device";
import { isOwnedVirtualNumber } from "../utils/callingGuards";

interface MainLayoutProps {
  user: FirebaseUser;
  profile: UserProfile;
  onProfileUpdate: (updated: Partial<UserProfile>) => void;
}

export type ViewState = TabType | "call";

export default function MainLayout({ user, profile, onProfileUpdate }: MainLayoutProps) {
  const [currentView, setCurrentView] = useState<ViewState>("dialer");
  const [activeCall, setActiveCall] = useState<{ id: string, targetNumber: string, isIncoming: boolean, receiverNumber?: string, initialState?: "busy" | "failed", initialMessage?: string } | null>(null);
  const [simulatedCall, setSimulatedCall] = useState<{ number: string; direction: SimulatedCallDirection } | null>(null);
  const [simulatedCallHistory, setSimulatedCallHistory] = useState<RecentCall[]>([]);

  // Modals & Toasts state
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [showChangePin, setShowChangePin] = useState(false);
  const [showDevices, setShowDevices] = useState(false);
  const [showNumberChange, setShowNumberChange] = useState(false);
  const [showHelloTune, setShowHelloTune] = useState(false);
  const [showBlockedUsers, setShowBlockedUsers] = useState(false);
  const [showNotificationSettings, setShowNotificationSettings] = useState(false);
  const [reportNumber, setReportNumber] = useState<string | null>(null);
  const [toast, setToast] = useState<{ message: string, type?: "success" | "error" } | null>(null);

  const [incomingCall, setIncomingCall] = useState<any>(null);

  useEffect(() => {
    if (!profile.uid) return;
    const q = query(collection(db, "calls"), where("receiverUid", "==", profile.uid), where("status", "==", "ringing"));
    const unsub = onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        const callData = snapshot.docs[0].data();
        if (profile.dndEnabled) {
          void updateCallSession(snapshot.docs[0].id, "rejected");
        } else {
          setIncomingCall({ id: snapshot.docs[0].id, ...callData });
        }
      } else {
        setIncomingCall(null);
      }
    });
    return () => unsub();
  }, [profile.uid, profile.dndEnabled]);

  useEffect(() => {
    if (incomingCall && !activeCall) {
      setActiveCall({ id: incomingCall.id, targetNumber: incomingCall.callerNumber, isIncoming: true, receiverNumber: incomingCall.receiverNumber });
    }
  }, [incomingCall]);

  // The ringing-query listener only starts the incoming alert. It must not hide an
  // active call when ringing advances to connecting; CallScreen watches the call
  // document itself and ends the UI on terminal states such as cancelled/timeout.

  const showToast = (message: string, type: "success" | "error" = "success") => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  const activeTemporaryNumber = profile.activeTemporaryNumber?.status === "active" && profile.activeTemporaryNumber.expiresAt > Date.now()
    ? profile.activeTemporaryNumber
    : null;
  const callerIdentities = [
    ...profile.virtualNumbers.filter(item => item.type === "primary" && item.status === "active").map(item => ({ number: item.number, type: "permanent" as const })),
    ...(activeTemporaryNumber ? [{ number: activeTemporaryNumber.number, type: "temporary" as const, expiresAt: activeTemporaryNumber.expiresAt }] : []),
  ];
  const ownedNumbers = [...profile.virtualNumbers.map(item => item.number), ...(activeTemporaryNumber ? [activeTemporaryNumber.number] : [])];

  const handleStartCall = async (number?: string, selectedCallerNumber?: string) => {
    if (!number) return;
    if (ownedNumbers.includes(number)) {
      showToast("You cannot call your own number.", "error");
      return;
    }
    try {
      const callerNum = callerIdentities.find(identity => identity.number === selectedCallerNumber)?.number || callerIdentities[0]?.number;
      if (!callerNum) throw new Error("No active calling number is available.");
      const callId = await startCallSession(profile.uid, callerNum, number, getOrCreateDeviceId());
      setActiveCall({ id: callId, targetNumber: number, isIncoming: false });
    } catch (err: any) {
      const message = err.message || "Unable to start the call.";
      setActiveCall({ id: "", targetNumber: number, isIncoming: false, initialState: message === "User is unavailable." ? "busy" : "failed", initialMessage: message });
    }
  };

  const startSimulatedCall = async (number: string) => {
    if (isOwnedVirtualNumber(number, profile.virtualNumbers)) {
      showToast("You cannot call your own number.", "error");
      return;
    }
    setSimulatedCall({ number, direction: "outgoing" });
  };

  const startIncomingSimulation = () => {
    setSimulatedCall({ number: "7000001", direction: "incoming" });
  };

  const endSimulatedCall = (result: SimulatedCallResult) => {
    const entry = simulatedHistoryEntry(simulatedCall?.number || "", result);
    setSimulatedCallHistory(history => [entry, ...history].slice(0, 20));
    setSimulatedCall(null);
  };

  const handleBlockContact = async (number: string, label: string) => {
    const result = await blockUser(profile.uid, number, label);
    const existingBlocks = profile.blockedUsersList || [];
    const blockedUsersList = existingBlocks.some((entry) => entry.number === number)
      ? existingBlocks
      : [...existingBlocks, result.entry];
    const blockedHashes = profile.blockedHashes?.includes(result.entry.uidHash)
      ? profile.blockedHashes
      : [...(profile.blockedHashes || []), result.entry.uidHash];
    onProfileUpdate({ blockedUsersList, blockedHashes });
    showToast("Caller blocked");
  };

  const handleUnblockContact = async (number: string) => {
    await unblockUser(profile.uid, number);
    onProfileUpdate({
      blockedHashes: (profile.blockedUsersList || []).filter((entry) => entry.number !== number).map((entry) => entry.uidHash),
      blockedUsersList: (profile.blockedUsersList || []).filter((entry) => entry.number !== number),
    });
    showToast("Caller unblocked");
  };

  const handleEndCall = () => {
    setActiveCall(null);
    setIncomingCall(null);
  };


  const activeTab = ["dialer", "contacts", "recharge", "profile"].includes(currentView) 
    ? (currentView as TabType) 
    : "dialer";

  return (
    <div className="flex flex-col h-full min-h-0 w-full bg-white relative overflow-hidden">
      
      {/* Toast Notification */}
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      {/* Modals */}
      {showEditProfile && <EditProfileModal profile={profile} onClose={() => setShowEditProfile(false)} onSuccess={(p) => { onProfileUpdate(p); setShowEditProfile(false); showToast("Profile updated!"); }} />}
      {showChangePin && <ChangePinModal profile={profile} onClose={() => setShowChangePin(false)} onSuccess={() => { setShowChangePin(false); showToast("PIN changed successfully!"); }} />}
      {showDevices && <DevicesModal profile={profile} onClose={() => setShowDevices(false)} onLogoutDevice={async (deviceSession) => {
        const id = deviceSession.sessionId;
        const newSessions = profile.sessions?.filter(s => s.sessionId !== id) || [];
        await updateDoc(doc(db, "users", profile.uid), { sessions: newSessions });
        onProfileUpdate({ sessions: newSessions });
        showToast("Device logged out successfully!");
      }} />}
      {showNumberChange && <NumberChangeRequestModal profile={profile} onClose={() => setShowNumberChange(false)} onRequest={() => { setShowNumberChange(false); showToast("Request submitted for review."); }} />}
      {showBlockedUsers && <BlockedUsersModal profile={profile} onClose={() => setShowBlockedUsers(false)} onUnblock={async (u) => {
          try {
            await unblockUser(profile.uid, u);
            onProfileUpdate({
              blockedHashes: profile.blockedHashes?.filter(h => h !== u.uidHash && h !== u.deviceHash),
              blockedUsersList: profile.blockedUsersList?.filter(x => x.number !== u.number),
            });
            showToast("Caller unblocked");
          } catch (error) {
            console.error("Unable to unblock caller", error);
            showToast("Unable to unblock caller", "error");
          }
      }} />}
      <AnimatePresence>
        {showNotificationSettings && <NotificationSettingsModal profile={profile} onClose={() => setShowNotificationSettings(false)} onSave={async (s) => { 
            await updateDoc(doc(db, "users", profile.uid), { notificationSettings: s }); 
            onProfileUpdate({ notificationSettings: s }); 
            setShowNotificationSettings(false); 
            showToast("Settings saved"); 
        }} />}
      </AnimatePresence>
      {reportNumber && <ReportModal targetNumber={reportNumber} onClose={() => setReportNumber(null)} onSubmit={async (category, description) => {
         const result = await reportUser(profile.uid, reportNumber, category, description);
         showToast(result.created ? "Report submitted" : "This report was already submitted.");
      }} />}
      {showHelloTune && <div className="absolute inset-0 z-[60]"><HelloTuneTab profile={profile} onClose={() => setShowHelloTune(false)} /></div>}

      {/* Main Content Area */}
      <div className="flex-1 min-h-0 w-full relative overflow-hidden flex flex-col">
        <AnimatePresence mode="wait">
        {currentView === "dialer" && (
          <motion.div key="dialer" variants={pageTransition} initial="initial" animate="animate" exit="exit" className="absolute inset-0 flex flex-col"><DialerTab profile={profile} onGoToProfile={() => setCurrentView("profile")} onCall={handleStartCall} callerIdentities={callerIdentities} recentCalls={simulatedCallHistory} onSimulateIncoming={startIncomingSimulation} /></motion.div>
        )}
        
        {currentView === "contacts" && (
          <motion.div key="contacts" variants={pageTransition} initial="initial" animate="animate" exit="exit" className="absolute inset-0 flex flex-col"><ContactsTab profile={profile} onCallInitiate={handleStartCall} onBlockContact={handleBlockContact} onUnblockContact={handleUnblockContact} onReportContact={setReportNumber} /></motion.div>
        )}

        {currentView === "recharge" && (
          <motion.div key="recharge" variants={pageTransition} initial="initial" animate="animate" exit="exit" className="absolute inset-0 flex flex-col"><PlanSelection profile={profile} onClose={() => setCurrentView("dialer")} onOpenHelloTune={() => setShowHelloTune(true)} /></motion.div>
        )}

        {currentView === "profile" && (
          <motion.div key="profile" variants={pageTransition} initial="initial" animate="animate" exit="exit" className="absolute inset-0 flex flex-col">
            <ProfileTab 
          profile={profile} 
          onOpenChangePin={() => setShowChangePin(true)} 
          onOpenEditProfile={() => setShowEditProfile(true)} 
          onOpenDevices={() => setShowDevices(true)} 
          onOpenNumberChange={() => setShowNumberChange(true)} 
          onOpenHelloTune={() => setShowHelloTune(true)} 
          onOpenBlockedUsers={() => setShowBlockedUsers(true)} 
          onOpenNotificationSettings={() => setShowNotificationSettings(true)} 
          onToggleDND={async (val) => {
             try {
               await updateDND(profile.uid, val);
               onProfileUpdate({ dndEnabled: val });
             } catch (error) {
               console.error("Unable to update call availability", error);
               showToast("Unable to update availability", "error");
             }
          }} 
          />
          </motion.div>
        )}

        </AnimatePresence>
      {activeCall && (
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} transition={{ duration: 0.2 }} className="absolute inset-0 z-50 bg-slate-900">
          <CallScreen 
            callId={activeCall.id}
            isIncoming={activeCall.isIncoming}
            targetNumber={activeCall.targetNumber}
            receiverNumber={activeCall.receiverNumber}
            initialState={activeCall.initialState}
            initialMessage={activeCall.initialMessage}
            onEndCall={handleEndCall}
          />
        </motion.div>
      )}
      {simulatedCall && <SimulatedCallScreen number={simulatedCall.number} direction={simulatedCall.direction} onEnd={endSimulatedCall} />}
      </div>

      {/* Bottom Navigation */}
      {currentView !== "call" && !activeCall && !simulatedCall && (
        <BottomNav 
          activeTab={activeTab} 
          onTabChange={(tab) => setCurrentView(tab)} 
        />
      )}
    </div>
  );
}
