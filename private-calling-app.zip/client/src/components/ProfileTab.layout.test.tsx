// @vitest-environment jsdom
import React from "react";
import { cleanup, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import ProfileTab from "./ProfileTab";

vi.mock("../firebase", () => ({ auth: { signOut: vi.fn() }, db: {} }));
vi.mock("firebase/auth", () => ({ deleteUser: vi.fn() }));
vi.mock("firebase/firestore", () => ({ doc: vi.fn(), deleteDoc: vi.fn(), updateDoc: vi.fn(), setDoc: vi.fn() }));
vi.mock("../services/secureApi", () => ({ secureApi: { pin: { revealOwn: { mutate: vi.fn() } } } }));

afterEach(cleanup);

const profile: any = {
  uid: "owner-uid", displayName: "Owner", email: "owner@example.invalid", photoURL: "", pinHash: "hashed",
  virtualNumbers: [{ number: "12345678", type: "primary", status: "active", createdAt: 1 }], createdAt: 1, isOnboarded: true,
};

function renderProfile() {
  return render(<ProfileTab profile={profile} onOpenChangePin={vi.fn()} onOpenEditProfile={vi.fn()} onOpenDevices={vi.fn()} onOpenNumberChange={vi.fn()} onOpenHelloTune={vi.fn()} onOpenBlockedUsers={vi.fn()} onOpenNotificationSettings={vi.fn()} onToggleDND={vi.fn()} />);
}

describe("Profile Virtual Number and Calling PIN containment", () => {
  it("stacks the two cards on Android widths and keeps each text/action row shrink-safe", () => {
    const { container } = renderProfile();
    const cards = Array.from(container.querySelectorAll("div")).find((element) => element.className.includes("min-[560px]:grid-cols-2"))!;
    const virtualCard = cards.children[0] as HTMLElement;
    const pinCard = cards.children[1] as HTMLElement;

    expect(cards.className).toContain("grid-cols-1");
    expect(cards.className).toContain("min-[560px]:grid-cols-2");
    expect(virtualCard.className).toContain("min-w-0");
    expect(pinCard.className).toContain("min-w-0");
    expect(screen.getByRole("button", { name: "Copy virtual number" }).className).toContain("shrink-0");
    expect(screen.getByRole("button", { name: "Reveal calling PIN" }).parentElement?.className).toContain("shrink-0");
  });

  it("keeps an active temporary number explicitly separate from the permanent virtual number", () => {
    render(<ProfileTab profile={{ ...profile, activeTemporaryNumber: { number: "7000001", status: "active", numberType: "temporary", entitlementId: "temp-1", planId: "7d-temp", activatedAt: 1, expiresAt: Date.now() + 60_000 } }} onOpenChangePin={vi.fn()} onOpenEditProfile={vi.fn()} onOpenDevices={vi.fn()} onOpenNumberChange={vi.fn()} onOpenHelloTune={vi.fn()} onOpenBlockedUsers={vi.fn()} onOpenNotificationSettings={vi.fn()} onToggleDND={vi.fn()} />);
    expect(screen.getAllByText("Virtual Number").length).toBeGreaterThan(0);
    expect(screen.getByText("Active Temporary Number")).toBeTruthy();
    expect(screen.getByText("700-0001")).toBeTruthy();
  });
});
