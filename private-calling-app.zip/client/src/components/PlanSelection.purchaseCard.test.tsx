// @vitest-environment jsdom
import React from "react";
import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { ActiveHelloTuneCard, activeRechargePlan, RechargePlanCard } from "./PlanSelection";

vi.mock("../services/secureApi", () => ({ secureApi: {} }));
vi.mock("./VipNumberSearch", () => ({ default: () => null }));
vi.mock("./HelloTuneTab", () => ({ AudioTrimmer: () => null }));

describe("Recharge purchase card", () => {
  it("keeps plan name, price, validity, benefit summary, chevron-ready compact card, and selection action together", () => {
    const onSelect = vi.fn();
    render(<RechargePlanCard plan={{ planId: "50d-freedom", planName: "50-Day Freedom", price: 17, validityValue: 50, validityUnit: "days", validity: "50 Days", benefits: ["1 Permanent 8-Digit Virtual Number", "Unlimited app-to-app voice calling"], categories: ["Recommended"], kind: "permanent", numberEntitlement: 1, temporaryNumberEntitlement: 0 }} onSelect={onSelect} />);
    const card = screen.getByRole("button");
    expect(card.className).toContain("rounded-[18px]");
    expect(screen.getByText("₹17")).toBeTruthy();
    expect(screen.getByText("50 Days")).toBeTruthy();
    expect(screen.getByText("1 Permanent 8-Digit Virtual Number")).toBeTruthy();
    fireEvent.click(card);
    expect(onSelect).toHaveBeenCalledTimes(1);
  });

  it("uses the catalog-derived active permanent plan first and falls back to the active temporary entitlement", () => {
    const temporary: any = { planId: "7d-temp", planName: "7-Day Temporary Number", price: 25, validity: "7 Days", benefits: ["1 temporary 7-digit receiving number"], entitlementExpiry: 2 };
    const permanent: any = { planId: "50d-freedom", planName: "50-Day Freedom", price: 17, validity: "50 Days", benefits: ["1 Permanent 8-Digit Virtual Number"], entitlementExpiry: 3 };
    expect(activeRechargePlan({ currentPlan: permanent, activeTemporaryEntitlements: [temporary] } as any)).toBe(permanent);
    expect(activeRechargePlan({ currentPlan: null, activeTemporaryEntitlements: [temporary] } as any)).toBe(temporary);
  });

  it("shows active HelloTune metadata from the verified profile pass and opens only its management surface", () => {
    const onManage = vi.fn();
    render(<ActiveHelloTuneCard profile={{ activeHelloTunePass: { planId: "plus", purchasedAt: 1, expiresAt: Date.now() + 86_400_000 }, helloTune: { name: "Selected clip", url: "/manus-storage/clip.wav" } } as any} onManage={onManage} />);
    expect(screen.getByText("HelloTune active")).toBeTruthy();
    expect(screen.getByText("Selected clip")).toBeTruthy();
    expect(screen.getByText(/Valid until/)).toBeTruthy();
    fireEvent.click(screen.getByText("Selected clip").closest("button")!);
    expect(onManage).toHaveBeenCalledTimes(1);
  });
});
