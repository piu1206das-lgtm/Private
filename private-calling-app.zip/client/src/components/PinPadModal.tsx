import React, { useState, useEffect, useRef } from "react";
import { X, Delete, Lock, ShieldAlert } from "lucide-react";
import { getPinCooldown, validatePinAndRecordAttempt } from "../services/backend";
import { motion } from "motion/react";
import { bottomSheetTransition, tapScale } from "../utils/animations";
import { hapticFeedback } from "../utils/haptics";

interface PinPadModalProps {
  callerUid: string;
  targetNumber: string;
  onSuccess: () => void;
  onCancel: () => void;
}

export default function PinPadModal({ callerUid, targetNumber, onSuccess, onCancel }: PinPadModalProps) {
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");
  const [attempts, setAttempts] = useState(0);
  const [cooldown, setCooldown] = useState(0);
  const [isVerifying, setIsVerifying] = useState(false);
  const isCancelledRef = useRef(false);

  const handleClose = () => {
    isCancelledRef.current = true;
    setPin("");
    setError("");
    setAttempts(0);
    onCancel();
  };

  useEffect(() => {
    let cancelled = false;
    getPinCooldown(callerUid, targetNumber).then(lockedUntil => {
      if (!cancelled && lockedUntil > Date.now()) {
        setCooldown(Math.ceil((lockedUntil - Date.now()) / 1000));
      }
    });
    return () => { cancelled = true; };
  }, [callerUid, targetNumber]);

  useEffect(() => {
    let timer: any;
    if (cooldown > 0) {
      timer = setInterval(() => setCooldown(c => c - 1), 1000);
    }
    return () => clearInterval(timer);
  }, [cooldown]);

  const handleKeyPress = (val: string) => {
    if (cooldown > 0 || isVerifying) return;
    setError("");
    hapticFeedback.medium();
    setPin(prev => {
      const newPin = prev.length < 4 ? prev + val : prev;
      if (newPin.length === 4) {
        verifyPin(newPin);
      }
      return newPin;
    });
  };

  const handleDelete = () => {
    if (cooldown > 0 || isVerifying) return;
    hapticFeedback.light();
    setPin(prev => prev.slice(0, -1));
  };

  const verifyPin = async (currentPin: string) => {
    setIsVerifying(true);
    try {
      const result = await validatePinAndRecordAttempt(callerUid, targetNumber, currentPin);
      if (isCancelledRef.current) return;
      if (result.success) {
        hapticFeedback.success();
        setTimeout(() => { if (!isCancelledRef.current) onSuccess(); }, 300); // slight delay for visual feedback
      } else {
        hapticFeedback.error();
        if (result.lockedUntil && result.lockedUntil > Date.now()) {
          setCooldown(Math.ceil((result.lockedUntil - Date.now()) / 1000));
          setError("Too many attempts. Locked for 15 minutes.");
        } else {
          setAttempts(previous => previous + 1);
          setError(result.error || "Incorrect PIN.");
        }
        setPin("");
      }
    } catch (err) {
      setError("Verification failed.");
      setPin("");
    } finally {
      setIsVerifying(false);
    }
  };

  return (
    <div className="absolute inset-0 z-50 flex flex-col justify-end">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm transition-opacity" onClick={handleClose}></motion.div>
      <motion.div variants={bottomSheetTransition} initial="initial" animate="animate" exit="exit" className="bg-white rounded-t-[32px] p-8 pb-12 shadow-2xl relative z-10">
        
        <div className="w-full flex justify-center mb-6">
          <div className="w-12 h-1.5 bg-slate-200 rounded-full"></div>
        </div>

        <button onClick={handleClose} aria-label="Close security PIN" className="absolute top-4 right-4 flex min-h-12 min-w-12 items-center justify-center rounded-full bg-slate-100 text-slate-500 transition-colors active:bg-slate-200">
          <X className="w-5 h-5" />
        </button>

        <div className="flex flex-col items-center mb-8">
          <div className={`w-14 h-14 rounded-full flex items-center justify-center mb-4 ${error ? 'bg-red-50 text-red-500' : 'bg-amber-50 text-amber-500'}`}>
            {error ? <ShieldAlert className="w-7 h-7" /> : <Lock className="w-7 h-7" />}
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mb-1">Enter Security PIN</h2>
          <p className="text-sm font-medium text-slate-500">To call {targetNumber.slice(0,4)}-{targetNumber.slice(4)}</p>
        </div>

        {/* PIN Indicators */}
        <motion.div animate={error ? { x: [-10, 10, -10, 10, 0] } : {}} transition={{ duration: 0.4 }} className="flex justify-center gap-4 mb-8">
          {[0, 1, 2, 3].map(i => (
            <div 
              key={i} 
              className={`w-4 h-4 rounded-full transition-all duration-300 ${pin.length > i ? 'bg-slate-800 scale-110' : 'bg-slate-200 scale-100'} ${error && pin.length === 0 ? 'bg-red-200' : ''}`}
            ></div>
          ))}
        </motion.div>

        <div className="h-6 flex justify-center mb-6">
          {error && <p className="text-sm font-bold text-red-500 animate-in slide-in-from-bottom-2">{error}</p>}
          {cooldown > 0 && !error && (
             <p className="text-sm font-bold text-red-500 animate-in slide-in-from-bottom-2">
               Try again in {Math.floor(cooldown / 60)}:{(cooldown % 60).toString().padStart(2, '0')}
             </p>
          )}
        </div>

        {/* Keypad */}
        <div className={`transition-opacity duration-300 ${cooldown > 0 ? 'opacity-30 pointer-events-none' : 'opacity-100'}`}>
          <div className="grid grid-cols-3 gap-y-4 gap-x-6 max-w-[280px] mx-auto w-full">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((num) => (
              <motion.button
                whileTap={tapScale}
                key={num}
                onClick={() => handleKeyPress(num)}
                className="w-full aspect-[1.1] rounded-full flex justify-center items-center active:bg-slate-100 transition-colors mx-auto ripple"
              >
                <span className="text-[32px] font-normal text-slate-800">{num}</span>
              </motion.button>
            ))}
            <div className="col-start-2">
              <motion.button
                whileTap={tapScale}
                onClick={() => handleKeyPress('0')}
                className="w-full aspect-[1.1] rounded-full flex justify-center items-center active:bg-slate-100 transition-colors mx-auto ripple"
              >
                <span className="text-[32px] font-normal text-slate-800">0</span>
              </motion.button>
            </div>
            <div className="col-start-3">
              <motion.button
                whileTap={tapScale}
                onClick={handleDelete}
                className="w-full aspect-[1.1] rounded-full flex justify-center items-center text-slate-400 active:bg-slate-100 transition-colors mx-auto ripple"
              >
                <Delete className="w-7 h-7" />
              </motion.button>
            </div>
          </div>
        </div>

      </motion.div>
    </div>
  );
}
