// @vitest-environment jsdom
import React from "react";
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import ProfileTab from "./ProfileTab";
import { secureApi } from "../services/secureApi";

vi.mock("../firebase", () => ({ auth: { signOut: vi.fn() }, db: {} }));
vi.mock("firebase/auth", () => ({ deleteUser: vi.fn() }));
vi.mock("firebase/firestore", () => ({ doc: vi.fn(), deleteDoc: vi.fn(), updateDoc: vi.fn(), setDoc: vi.fn() }));
vi.mock("../services/secureApi", () => ({ secureApi: { pin: { revealOwn: { mutate: vi.fn() } } } }));

afterEach(cleanup);

const profile: any = {
  uid: "owner-uid", displayName: "Owner", email: "owner@example.invalid", photoURL: "", pinHash: "hashed",
  virtualNumbers: [{ number: "12345678", type: "primary", status: "active", createdAt: 1 }], createdAt: 1, isOnboarded: true,
};

describe("Calling PIN visibility control", () => {
  it("starts masked, reveals only after the authenticated API response, and hides on a second tap", async () => {
    vi.mocked(secureApi.pin.revealOwn.mutate).mockResolvedValue({ pin: "0042" } as never);
    render(<ProfileTab profile={profile} onOpenChangePin={vi.fn()} onOpenEditProfile={vi.fn()} onOpenDevices={vi.fn()} onOpenNumberChange={vi.fn()} onOpenHelloTune={vi.fn()} onOpenBlockedUsers={vi.fn()} onOpenNotificationSettings={vi.fn()} onToggleDND={vi.fn()} />);

    expect(screen.getByText("••••••••")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "Reveal calling PIN" }));
    await waitFor(() => expect(screen.getByText("0042")).toBeTruthy());
    expect(secureApi.pin.revealOwn.mutate).toHaveBeenCalledWith({});
    fireEvent.click(screen.getByRole("button", { name: "Hide calling PIN" }));
    await waitFor(() => expect(screen.getByText("••••••••")).toBeTruthy());
  });
});
