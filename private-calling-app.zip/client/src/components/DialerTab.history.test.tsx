// @vitest-environment jsdom
import React from "react";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import DialerTab, { type RecentCall } from "./DialerTab";

vi.mock("../utils/haptics", () => ({ hapticFeedback: { light: vi.fn(), heavy: vi.fn() } }));
vi.mock("./PinPadModal", () => ({ default: () => null }));

afterEach(cleanup);

const profile: any = { uid: "owner", displayName: "Owner", photoURL: "", virtualNumbers: [] };
const calls: RecentCall[] = [
  { id: "incoming-1", name: "Aarav", number: "12345678", time: "10:42 AM", type: "incoming" },
  { id: "outgoing-1", name: "Meera", number: "76543210", time: "Yesterday", type: "outgoing" },
  { id: "missed-1", name: "Unknown", number: "7000001", time: "Mon", type: "missed" },
];

describe("DialerTab compact Call History", () => {
  it("renders dense rows with the required call metadata instead of large call cards", () => {
    render(<DialerTab profile={profile} onCall={vi.fn()} onGoToProfile={vi.fn()} recentCalls={calls} />);

    const list = screen.getByTestId("call-history-list");
    const rows = Array.from(list.querySelectorAll("button"));
    expect(rows).toHaveLength(3);
    expect(rows.every((row) => row.className.includes("h-[64px]"))).toBe(true);
    expect(screen.getByText("Aarav")).toBeTruthy();
    expect(screen.getByText("1234-5678")).toBeTruthy();
    expect(screen.getByText("10:42 AM")).toBeTruthy();
    expect(screen.getByText("Incoming")).toBeTruthy();
    expect(screen.getByText("Outgoing")).toBeTruthy();
    expect(screen.getByText("Missed")).toBeTruthy();
  });

  it("filters instantly by name or number without changing the supplied call history", () => {
    render(<DialerTab profile={profile} onCall={vi.fn()} onGoToProfile={vi.fn()} recentCalls={calls} />);
    const search = screen.getByRole("textbox", { name: "Search call history" });

    fireEvent.change(search, { target: { value: "meera" } });
    expect(screen.getByText("Meera")).toBeTruthy();
    expect(screen.queryByText("Aarav")).toBeNull();

    fireEvent.change(search, { target: { value: "7000001" } });
    expect(screen.getByText("Unknown")).toBeTruthy();
    expect(screen.queryByText("Meera")).toBeNull();

    fireEvent.change(search, { target: { value: "no match" } });
    expect(screen.getByText("No matching calls")).toBeTruthy();
    expect(calls).toHaveLength(3);
  });

  it("opens full call details only after a history row is tapped and can return the number to the Dialer", () => {
    const { container } = render(<DialerTab profile={profile} onCall={vi.fn()} onGoToProfile={vi.fn()} recentCalls={calls} />);
    expect(screen.queryByRole("dialog", { name: "Call details" })).toBeNull();

    fireEvent.click(screen.getByRole("button", { name: "Open call details for Aarav" }));
    expect(screen.getByRole("dialog", { name: "Call details" })).toBeTruthy();
    expect(screen.getByText("Call type")).toBeTruthy();
    expect(screen.getByText("Time / date")).toBeTruthy();

    fireEvent.click(screen.getByRole("button", { name: "Use number in Dialer" }));
    expect(screen.getByRole("button", { name: "Hide keypad" })).toBeTruthy();
    const numberDisplay = Array.from(container.querySelectorAll("h2")).find((heading) => heading.className.includes("font-mono"));
    expect(numberDisplay?.textContent).toBe("1234-5678");
  });
});
