/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState } from "react";
import { onAuthStateChanged, User as FirebaseUser } from "firebase/auth";
import { doc, onSnapshot, updateDoc } from "firebase/firestore";
import { auth, db, isConfigured } from "./firebase";
import Login from "./components/Login";
import Onboarding from "./components/Onboarding";
import MainLayout from "./components/MainLayout";
import { AppUser, UserProfile, DeviceSession } from "./types";
import { clearLegacyPinCache, getDeviceName, getOrCreateDeviceId } from "./utils/device";
import { mergeDeviceSession } from "./utils/sessions";
export default function App() {
  const [appUser, setAppUser] = useState<AppUser | null>(null);
  const [loading, setLoading] = useState(isConfigured);

  useEffect(() => {
    clearLegacyPinCache();
    // Check if Firebase is properly initialized
    if (!isConfigured || !auth) {
      setLoading(false);
      return;
    }

    let unsubscribeProfile: (() => void) | null = null;
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      unsubscribeProfile?.();
      unsubscribeProfile = null;
      if (currentUser) {
        const userDocRef = doc(db, "users", currentUser.uid);
        let sessionRegistered = false;
        unsubscribeProfile = onSnapshot(userDocRef, async (userDoc) => {
          if (!userDoc.exists()) {
            setAppUser({ authUser: currentUser, profile: null });
            setLoading(false);
            return;
          }
          const profile = userDoc.data() as UserProfile;
          setAppUser({ authUser: currentUser, profile });
          setLoading(false);
          if (sessionRegistered) return;
          sessionRegistered = true;
          const deviceId = getOrCreateDeviceId();
          const currentSession: DeviceSession = {
            sessionId: crypto.randomUUID(),
            deviceId,
            deviceName: getDeviceName(),
            lastActive: Date.now(),
          };
          const knownSessions = profile.sessions || [];
          if (knownSessions.length > 0 && !knownSessions.some(session => session.deviceId === deviceId)) {
            alert("New device login detected. Please review your active sessions in Profile settings.");
          }
          const updatedSessions = mergeDeviceSession(knownSessions, currentSession);
          try {
            await updateDoc(userDocRef, { isOnline: true, sessions: updatedSessions });
          } catch (error) {
            console.error("Failed to update online status & sessions", error);
          }
        }, (error) => {
          console.error("Error synchronizing user profile:", error);
          setAppUser({ authUser: currentUser, profile: null });
          setLoading(false);
        });
      } else {
        setAppUser(null);
        setLoading(false);
      }
    });

    return () => {
      unsubscribe();
      unsubscribeProfile?.();
    };
  }, []);

  // Set offline when window closes
  useEffect(() => {
    const handleBeforeUnload = () => {
      if (appUser?.profile) {
        // Best effort synchronous update (beacon preferred but updateDoc might fire if quick enough)
        updateDoc(doc(db, "users", appUser.profile.uid), { isOnline: false }).catch(() => {});
      }
    };
    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => window.removeEventListener("beforeunload", handleBeforeUnload);
  }, [appUser]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#FFC107] flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-10 h-10 border-4 border-black/10 border-t-black rounded-full animate-spin"></div>
          <p className="text-black font-bold">Loading App...</p>
        </div>
      </div>
    );
  }

  if (!isConfigured) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4 text-center">
        <div className="max-w-lg bg-white p-8 rounded-2xl border border-red-100 shadow-sm">
          <h1 className="text-xl font-bold text-red-600 mb-4">Firebase Not Configured</h1>
          <p className="text-slate-600 mb-6 text-left">
            It looks like Firebase hasn't been initialized properly. To fix this:
          </p>
          <ol className="text-sm text-slate-600 text-left list-decimal pl-5 space-y-2 mb-6">
            <li>Go to the <a href="https://console.firebase.google.com" target="_blank" rel="noreferrer" className="text-blue-600 hover:underline">Firebase Console</a>.</li>
            <li>Create a new project and add a Web App.</li>
            <li>Enable "Google" under Authentication Sign-in methods.</li>
            <li>Copy the <code>firebaseConfig</code> object.</li>
            <li>Open <code>src/firebase.ts</code> and replace the placeholder config with your actual values.</li>
          </ol>
          <p className="text-sm text-slate-500 bg-slate-50 p-4 rounded-lg">
            Once you update the configuration, the app will automatically refresh and you'll see the Login page.
          </p>
        </div>
      </div>
    );
  }

  // Handle routing based on auth & onboarding status
  if (!appUser) {
    return <Login />;
  }

  if (!appUser.profile || !appUser.profile.isOnboarded) {
    return <Onboarding user={appUser.authUser} onComplete={(profile) => setAppUser({ ...appUser, profile })} />;
  }

  // make sure to consider if you need authentication for certain routes
  return (
    <div className="bg-slate-100 min-h-[100dvh] flex justify-center items-center sm:p-4">
      <div className="w-full h-[100dvh] min-h-0 sm:h-[850px] sm:max-w-[400px] bg-white sm:rounded-[40px] shadow-2xl relative overflow-hidden flex flex-col sm:border-[8px] sm:border-[#1A1A1A]">
        <MainLayout 
          user={appUser.authUser} 
          profile={appUser.profile} 
          onProfileUpdate={(updated) => setAppUser({ ...appUser, profile: { ...appUser.profile!, ...updated } })}
        />
      </div>
    </div>
  );
}
