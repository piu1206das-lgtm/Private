import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

// FIREBASE CONFIGURATION
// Values extracted from the provided google-services.json
const firebaseConfig = {
  apiKey: "AIzaSyDkpHFS_vL1nST9rTTVlC9L5jDZlCfDVTc",
  authDomain: "water-reminder-1bca2.firebaseapp.com",
  projectId: "water-reminder-1bca2",
  storageBucket: "water-reminder-1bca2.firebasestorage.app",
  messagingSenderId: "157659376655",
  appId: "1:157659376655:android:90e6d40b4abaf12c02c77a" // Using Android App ID from config
};

export const isConfigured = true;

// Initialize Firebase
let app;
export let auth: ReturnType<typeof getAuth>;
export let googleProvider: GoogleAuthProvider;
export let db: ReturnType<typeof getFirestore>;
export let storage: ReturnType<typeof getStorage>;

try {
  if (isConfigured) {
    app = initializeApp(firebaseConfig);
    auth = getAuth(app);
    googleProvider = new GoogleAuthProvider();
    db = getFirestore(app);
    storage = getStorage(app);
  }
} catch (error) {
  console.error("Firebase initialization failed.", error);
}
