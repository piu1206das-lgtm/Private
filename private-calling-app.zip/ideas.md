# Design Direction: Existing App Preservation

## Ground-Truth Spec

The permanent website must preserve the uploaded private-calling app’s current Android-inspired product identity rather than replace it with a public marketing site. The existing compact mobile shell, amber accent, dark slate call screen, soft neutral surfaces, rounded interaction controls, bottom navigation, and contextual modal flows are the visual source of truth.

## Design Movement

**Android-native utility UI.** The hosted version should retain the familiar feel of a focused mobile calling utility while adapting cleanly to browser viewport sizes.

## Core Principles

1. Retain the existing app flow: authentication, onboarding, dialer, contacts, profile, and call state are product surfaces, not landing-page sections.
2. Preserve the yellow-amber signal color as the action accent and dark slate as the in-call surface.
3. Keep information dense but legible, with full virtual-number visibility and touch-friendly controls.
4. Use modest motion only for state changes, sheets, and call interactions; usability takes priority over ornament.

## Color Philosophy

Amber communicates immediate call action and account identity; white and soft slate preserve calm, privacy-oriented clarity; deep slate distinguishes the focused call state from normal app navigation. These colors must not be replaced by a generic gradient or unrelated brand palette.

## Layout Paradigm

The primary experience remains a centered phone-width application shell on wide screens and a full-height application canvas on small screens. Browser hosting is a distribution change, not a reason to convert the product into a conventional centered marketing grid.

## Signature Elements

1. Circular call controls with clear, high-contrast states.
2. 4-4 and 3-4 virtual-number formatting that never clips digits.
3. Android-style bottom navigation and bottom-sheet modal transitions.

## Interaction Philosophy

Every visible interaction should communicate state promptly: pressed buttons compress slightly, call actions lock while requests are in flight, and authorization/timeout status is explicit. Keyboard access and small-screen touch targets must stay functional.

## Animation

Use existing short spring and opacity transitions for app views and sheets. Keep visual transitions under 300ms where possible, avoid decorative looping motion except the existing ringing indication, and respect reduced-motion preferences.

## Typography System

Use the existing system-style sans-serif hierarchy: compact medium-weight titles, clear 14–16px body labels, and monospaced virtual-number/PIN treatments. Do not introduce decorative display fonts that dilute the Android-native utility tone.

## Brand Essence

**A privacy-first internet calling app for people who need separate, user-controlled virtual calling identities.**

Personality: **private, direct, dependable.**

## Brand Voice

Headlines and microcopy remain short, operational, and calm. Avoid generic marketing language.

Examples: “Use your 8-digit calling identity.” and “Temporary numbers receive calls only.”

## Wordmark & Logo

Retain the existing call/entry icon language as a simple amber-and-slate rounded call mark. It must remain a symbol-first app identity rather than a default-font wordmark.

## Signature Brand Color

**Signal Amber — #FFC107.**
